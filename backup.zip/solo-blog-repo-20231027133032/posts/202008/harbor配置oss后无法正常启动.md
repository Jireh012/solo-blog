title: harbor配置oss后无法正常启动
date: '2020-08-27 11:33:41'
updated: '2020-08-27 11:34:58'
tags: [harbor, docker]
permalink: /articles/2020/08/27/1598499221475.html
---
# harbor配置oss后无法正常启动

记录一次harbor配置oss后无法正常启动的，并解决的记录

![image.png](https://b3logfile.com/file/2020/08/image-781f99db.png)

配置oss后，发现registry容器无法正常启动（无限重启）

通过 `docker exec -it harbor-log bash` 命令进入harbor日志容器中查看详细的错误记录

进入容器 harbor-log后使用 `cat /var/log/docker/registry.log  `查看对应的registry容器日志

![image.png](https://b3logfile.com/file/2020/08/image-b7e3c809.png)

发现一直会报`Aug 27 10:57:56 172.27.0.1 registry[11332]: panic: Get http://harbor.oss-cn-hangzhou.aliyuncs.com/?delimiter=&marker=&max-keys=1&prefix=: dial tcp: lookup zayl-docker.oss-cn-hangzhou.aliyuncs.com on 127.0.0.11:53: read udp 127.0.0.1:40414->127.0.0.11:53: i/o timeout `的错误，看到其中有个53端口（dns服务），估计是无法正常获取到 `http://harbor.oss-cn-hangzhou.aliyuncs.com`的解析地址。而且这个dns服务 127.0.0.11:53，肯定不是正常的。

知道这个原因后，其他解决方案就是给docker配置dns就可以了，**以下为docker配置dns地址**。

编辑 ` /etc/docker/daemon.json` 文件，添加 `"dns": ["223.5.5.5", "223.6.6.6"]` 配置并保存。

范例：

```
{
    "registry-mirrors": ["http://f1361db2.m.daocloud.io"],
    "dns": ["223.5.5.5", "223.6.6.6"]  
}
```

最后重启docker服务，再重启docker-compose

```
systemctl restart docker

docker-compose down -v
docker-compose up -d
```

重启后，再次通过`docker ps`查询

![image.png](https://b3logfile.com/file/2020/08/image-1b72b294.png)

发现registry容器已经正常启动了

