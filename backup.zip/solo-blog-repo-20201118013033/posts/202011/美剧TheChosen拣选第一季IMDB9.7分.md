title: 美剧 The Chosen《拣选》第一季 IMDB9.7分
date: '2020-11-13 10:07:57'
updated: '2020-11-13 11:33:24'
tags: [美剧]
permalink: /articles/2020/11/13/1605233276889.html
---
# 美剧 The Chosen《拣选》第一季 IMDB9.7分

* 第一部关于耶稣生平的多季电视剧集
* 众筹一千万美元，创造了娱乐类众筹项目的最高纪录
* 首季IMDB评分高达9.7分，其人物塑造水准不输《王冠》、《纸牌屋》
  
  ![](https://b3logfile.com/file/2020/11/solofetchupload5804467397407878299-531814a5.jpeg)

## 第一集

> I Have Called You By Name / 我点名呼召了你
> Two brothers struggle with their tax debts to Rome while a woman in the Red Quarter wrestles with her demons
> 两兄弟为欠罗马的应税债务而挣扎，而红区的一名妇女与她的恶魔搏斗（Google Translate）

## 第二集

> Shabbat / 安息日
> Matthew validates Simon's claims with Praetor Quintus, Nicodemus investigates the miracle reported in the Red Quarter, and Mary receives surprise guests at her Shabbat dinner.
> 马修（Matthew）通过Praetor Quintus（昆图斯）验证了西蒙（Simon）的主张，尼哥底母（Nicodemus）调查了《红色区》（Red Quarter）报道的奇迹，玛丽（Mary）在安息日晚宴上受到了客人的惊讶。（Google Translate）

## 第三集

> Jesus Loves The Little Children / 耶稣喜爱小孩
> Jesus befriends and teaches the group of children who discover His camp on the outskirts of Capernaum
> 耶稣结识并教了一群在迦百农郊外发现他营地的孩子（Google Translate）

## 第四集

> The Rock On Which It Is Built / 建造在这磐石上
> With his life and family under threat from Rome, Simon spends one last night fishing in a desperate attempt to square his debts. Andrew spots a familiar face waiting for them on the shores of Galilee.
> 由于他的生活和家人受到罗马的威胁，西蒙昨晚度过了一次垂钓，以期尽力弥补债务。 安德鲁在加利利海岸发现了一张熟悉的面孔，等待着他们。（Google Translate）

## 第五集

> The Wedding Gift / 结婚礼物（Google Translate）
> Nicodemus interrogates John the Baptizer while Jesus and his students make their way to a wedding celebration in Cana. When the wine runs low, Mary asks her son to intervene on behalf of the bridegroom's family.
> 尼哥底母讯问施洗者约翰，而耶稣和他的学生则前往加纳举行婚礼庆典。 当酒用尽时，玛丽请她的儿子代表新郎的家人进行干预。（Google Translate）

## 第六集

> Indescribable Compassion / 难以形容的同情心（Google Translate）
> After witnessing the healing of a leper on the road to Capernaum, a woman forces her paralytic friend through the crowd to meet Jesus.
> 在目睹前往迦百农的路上麻风病人的康复之后，一名妇女强迫她瘫痪的朋友穿过人群与耶稣会面。（Google Translate）

## 第七集

> Invitations / 邀请
> Matthew struggles to reconcile the miracles he has witnessed with reality. Nicodemus meets with Jesus by night.
> 马修努力调和他亲眼目睹的奇迹与现实。 尼哥底母在夜间与耶稣会面。（Google Translate）

## 第八集

> I Am He / 我就是
> Jesus and His students complete their preparations and leave Capernaum for Samaria. Jesus meets with a suffering woman at Jacob's Well and announces that He is the Messiah.
> 耶稣和他的学生完成准备工作，离开迦百农去撒玛利亚。 耶稣在雅各布之井与一位受苦的妇女会面，并宣布他是弥赛亚。（Google Translate）



## 下载地址：

> 链接：https://pan.baidu.com/s/1Ot-cQQgCpZ6tKK1HV_74yQ
> 提取码：r3p5

