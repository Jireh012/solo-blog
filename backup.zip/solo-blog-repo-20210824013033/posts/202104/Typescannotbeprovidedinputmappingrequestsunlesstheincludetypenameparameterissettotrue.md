title: Types cannot be provided in put mapping requests, unless the include_type_name
  parameter is set to true
date: '2021-04-06 14:16:55'
updated: '2021-04-06 14:16:55'
tags: [ElasticSearch]
permalink: /articles/2021/04/06/1617689815461.html
---
ElasticSearch创建索引报错 **Types cannot be provided in put mapping requests, unless the include_type_name parameter is set to true**

原因是elasticsearch7.x版本不支持type（低版本写法）所致，所以在高版本使用type，需要传入include_type_name参数，值为true。

```
POST 192.168.5.101:9200/trouble_request_log/_doc/_mappings?include_type_name=true
```

```
{
    "_doc":{
        "properties":{
            "path":{
                "type":"text"
            },
            "query_string":{
                "type":"text"
            },
            "uid":{
                "type":"long"
            },
            "add_time":{
                "type":"date",
                "format":"yyyy-MM-dd HH:mm:ss || yyyy-MM-dd || epoch_millis"
            }
        }
    }
}
```

