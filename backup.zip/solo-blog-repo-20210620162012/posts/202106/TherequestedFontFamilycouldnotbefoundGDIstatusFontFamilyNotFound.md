title: 'The requested FontFamily could not be found [GDI+ status: FontFamilyNotFound]'
date: '2021-06-08 09:19:14'
updated: '2021-06-08 09:19:14'
tags: [jexus, asp.net, mono]
permalink: /articles/2021/06/08/1623115153847.html
---
因为平台需要，要将原来部署在Windows Server上的Asp.Net服务迁移到Linux上面。

为了方便直接用Jexus独立版的Docker镜像，省了中间Mono，Jexus相关环境的安装。

在登录的时候发现验证码不显示，查看后台日志，发现有报错

```
System.ArgumentException: The requested FontFamily could not be found [GDI+ status: FontFamilyNotFound]
  at System.Drawing.GDIPlus.CheckStatus (System.Drawing.Status status) [0x001ce] in <e6d393b11eca475db6e22ed1cbeb1518>:0 
  at System.Drawing.FontFamily..ctor (System.Drawing.Text.GenericFontFamilies genericFamily) [0x0004d] in <e6d393b11eca475db6e22ed1cbeb1518>:0 
  at (wrapper remoting-invoke-with-check) System.Drawing.FontFamily..ctor(System.Drawing.Text.GenericFontFamilies)
  at System.Drawing.FontFamily.get_GenericSansSerif () [0x00000] in <e6d393b11eca475db6e22ed1cbeb1518>:0 
  at System.Drawing.Font.CreateFont (System.String familyName, System.Single emSize, System.Drawing.FontStyle style, System.Drawing.GraphicsUnit unit, System.Byte charSet, System.Boolean isVertical) [0x00011] in <e6d393b11eca475db6e22ed1cbeb1518>:0 
  at System.Drawing.Font..ctor (System.String familyName, System.Single emSize, System.Drawing.FontStyle style, System.Drawing.GraphicsUnit unit, System.Byte gdiCharSet, System.Boolean gdiVerticalFont) [0x00011] in <e6d393b11eca475db6e22ed1cbeb1518>:0 
  at System.Drawing.Font..ctor (System.String familyName, System.Single emSize) [0x00000] in <e6d393b11eca475db6e22ed1cbeb1518>:0 
  at (wrapper remoting-invoke-with-check) System.Drawing.Font..ctor(string,single)
  at verify_code.ProcessRequest (System.Web.HttpContext context) [0x001ce] in <2b0616f0c0e340749a35e5c3bfc06084>:0 
  at System.Web.HttpApplication+<Pipeline>d__225.MoveNext () [0x008fd] in <a0cf28d1b51f4484bc8478653eeeba81>:0 
  at System.Web.HttpApplication.Tick () [0x00000] in <a0cf28d1b51f4484bc8478653eeeba81>:0
```

### 原因

`The requested FontFamily could not be found [GDI+ status: FontFamilyNotFound]`

这是Jexus容器中Ubuntu环境没有安装相应的字体环境造成的

### 解决

进入jexus容器当中

`docker exec -it jexus bash`

安装libgdiplus软件

```
apt-get -q update
apt-get -y -q install libgdiplus
```

