title: harbor中registry容器无法启动
date: '2020-08-08 09:35:36'
updated: '2020-08-08 09:35:36'
tags: [harbor, docker, Linux]
permalink: /articles/2020/08/08/1596850536051.html
---
# harbor中registry容器无法启动

![image.png](https://b3logfile.com/file/2020/08/image-a2d2d9fe.png)

之前docker中harbor突然消失，重新安装harbor后registry容器一直无法启动

**原因可能是harbor启动需要容器互相依赖启动**

## 解决方案：

**重新启动  果然重启治百病还是很有道理的**😏😏😏

`docker-compose down` **停止容器**

`docker-compose up -d` **加上** `-d` **按照顺序启动**

