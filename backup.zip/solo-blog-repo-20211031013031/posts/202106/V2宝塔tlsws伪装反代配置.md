title: V2宝塔tls+ws伪装反代配置
date: '2021-06-23 10:49:33'
updated: '2021-06-23 10:49:33'
tags: [proxy]
permalink: /articles/2021/06/23/1624416573387.html
---
V2宝塔tls+ws伪装反代配置

```
#PROXY-START/
location  ~* \.(php|jsp|cgi|asp|aspx)$
{
    proxy_pass https://centos.org;
    proxy_set_header Host centos.org;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header REMOTE-HOST $remote_addr;
}
location /
{
    proxy_pass https://centos.org;
    proxy_set_header Host centos.org;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header REMOTE-HOST $remote_addr;

    add_header X-Cache $upstream_cache_status;
	#Set Nginx Cache
}

location /ws_address
{	
      if ($http_upgrade != "websocket") { 
           return 404;
      }
      proxy_pass http://127.0.0.1:12345;
      proxy_http_version 1.1;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
      proxy_set_header Host $host;
      # Show real IP in v2ray access.log
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}
```

