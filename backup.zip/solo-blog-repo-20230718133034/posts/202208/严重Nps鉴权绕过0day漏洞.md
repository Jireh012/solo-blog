title: 【严重】Nps鉴权绕过0day漏洞
date: '2022-08-10 17:03:12'
updated: '2022-08-10 17:03:12'
tags: [nps]
permalink: /articles/2022/08/10/1660122191957.html
---
## 漏洞详情

Nps是一款轻量级、高性能、功能强大的内网穿透代理服务器。支持tcp、udp、socks5、http等几乎所有流量转发，可用来访问内网网站、本地支付接口调试、ssh访问、远程桌面，内网dns解析、内网socks5代理等等……，并带有功能强大的web管理端

在配置文件中的**auth_key**为注释状态的情况下，攻击者可以绕过鉴权，调用任意Api执行创建、查询、删除客户端、隧道等操作。

## 风险等级

**高风险**

## 漏洞风险

攻击者利用该漏洞调用任意 Api 执行创建、查询、删除客户端、隧道等操作，提供攻击者绕过防火墙入侵内网环境入口。

## 影响版本

NPS =< 0.26.10

## 修复建议

官方暂未发布漏洞的修复版本，临时修复的方案是设置复杂的auth_key

或使用我修复编译好的版本
下载地址：https://github.com/Jireh012/nps/releases/tag/v100.26.10

## 漏洞分析

![10fa13eabcc298c26cb23507dfb8574.jpg](https://b3logfile.com/file/2022/08/10fa13eabcc298c26cb23507dfb8574-fc48eb40.jpg)

在注释情况下**auth_key**获取到的值为`''`，导致对后续的md5Key解密时不生效，只要对时间戳进行md5加密传入**auth_key**即可校验通过

## 代码修复

```
	if configKey == "" {
		configKey = crypt.GetRandomString(128)
	}
```

在读取到配置auth_key即configKey为`''`时，随机生成一个key

