title: idea设置代码自动换行
date: '2021-09-07 17:03:23'
updated: '2021-09-07 17:03:23'
tags: [idea]
permalink: /articles/2021/09/07/1631005403706.html
---
![image.png](https://b3logfile.com/file/2021/09/image-0db4fd83.png)

在 Settings - Editor - General 在 **Soft - wrap these files** 处配置需要开启自动换行的文件类型

