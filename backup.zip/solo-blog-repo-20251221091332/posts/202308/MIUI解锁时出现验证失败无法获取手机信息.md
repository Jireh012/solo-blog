title: MIUI解锁时出现验证失败，无法获取手机信息
date: '2023-08-01 09:34:37'
updated: '2023-08-01 09:34:37'
tags: [miui]
permalink: /articles/2023/08/01/1690853676997.html
---
最近在解锁一部老手机红米3S的时候出现了这个问题

![image.png](https://b3logfile.com/file/2023/08/image-I3ToCNK.png)

## 解决方法

使用旧版miui解锁工具成功解决

所有旧版的下载地址：https://miuiver.com/miunlock/

后面使用5.5.224.24的版本成功解锁

https://miuirom.xiaomi.com/rom/u1106245679/5.5.224.24/miflash_unlock-5.5.224.24.zip



