title: '[转]Python反反爬虫 – Frida破解某盒子hkey反爬虫算法'
date: '2020-07-30 22:22:33'
updated: '2020-07-31 16:44:02'
tags: [Hook, Android, Crack]
permalink: /articles/2020/07/30/1596118953825.html
---
![](https://b3logfile.com/file/2020/07/5O203ZHMU5GUNQIKJYX55-70c8cf1c.png)

# [转]Python反反爬虫 – Frida破解某盒子hkey反爬虫算法

<div class="vditor-linkcard vditor-tooltipped vditor-tooltipped__n" aria-label="点击跳转到博客端访问原文 https://www.jysafe.cn/4353.air">
        <a href="https://www.jysafe.cn/4353.air" class="fn__flex" target="_blank">
            <span class="vditor-linkcard__image" style="background-image: url(&quot;https://thirdqq.qlogo.cn/g?b=oidb&k=fHgY8KqzfeElaJBPcAPTZQ&s=100&t=1574343121&quot;);"></span>
            <span class="vditor-linkcard__info">
                <span class="vditor-linkcard__title">
                    # 祭夜の咖啡馆
</span>
<span class="vditor-linkcard__abstract">教程, 记录, Android, 猿之力</span>
<span class="vditor-linkcard__site">本博文转自 [[记录]Python反反爬虫 – Frida破解某盒子hkey反爬虫算法]
</span>
</span>
</a>
</div>

## 前言

这盒子有个抽奖功能，但是中奖率感人~
故，hack！
用到的工具：

> 1.抓包软件：NetKeeper[安卓端]
> 2.jeb分析工具[PC端]
> 3.ida分析工具[PC端]
> 4.Frida [Python模块以及服务端]

## 分析处理

先抓个包包吧

![image.png](https://b3logfile.com/file/2020/07/image-c9bcb5a2.png)

主要请求部分如下：

```
POST /account/data_report/?type=13&time_=1595993115&heybox_id=17584182&imei=xxxxx&os_type=Android
&os_version=6.0&version=1.3.114&_time=1595993115&hkey=bd34ee4c62
&channel=heybox_yingyongbao HTTP/1.1
```

经过测试`hkey`会随`time_`值变动而变动

### jeb分析

搜寻`hkey`

![image.png](https://b3logfile.com/file/2020/07/image-87af33d6.png)

`v1`与`v2`的值来源似乎不好处理，

为了减少脑细胞与头发的消耗，可以尝试从`NDKTools->encode`方法入手。

但是，到达`encode`位置后（`Ctrl+双击`），

![image.png](https://b3logfile.com/file/2020/07/image-97a6c590.png)

啊，这得上ida了

### ida分析

进入ida的`encode`中，

![image.png](https://b3logfile.com/file/2020/07/image-050d1e7c.png)

![image.png](https://b3logfile.com/file/2020/07/image-2da1047d.png)

看似没什么大问题，来hook：

```
console.log("========Hook Start==========")
 
String.prototype.format = function () {
    var values = arguments;
    return this.replace(/\{(\d+)\}/g, function (match, index) {
        if (values.length > index) {
            return values[index];
        } else {
            return "";
        }
    });
}
 
var JNI_LOAD_POINTER = Module.getExportByName('libnative-lib.so', 'JNI_OnLoad'); // 首先拿到 JNI_OnLoad方法的地址
var BASE_ADDR = parseInt(JNI_LOAD_POINTER) - parseInt('0x1C6C'); // 用程序运行中JNI_OnLoad的绝对地址减去它的相对地址得到基址
 
 
// encode
Java.perform(function() {
    var hookpointer = '0x' + parseInt(BASE_ADDR + parseInt('0x1B00')).toString(16) // 获取要hook方法的地址
    var pointer = new NativePointer(hookpointer) // 根据方法地址构建NativePointer
    console.log('[encode] hook pointer: ', pointer)
    
    var arg0, arg1, arg2, arg3
    Interceptor.attach(pointer, {
            onEnter: function(args) {
                arg0 = args[0]
                arg1 = args[1]
                arg2 = args[2]
                arg3 = args[3]
                console.log('\n')
                console.log('=====> [encode] -> [方法调用前]')
                console.log('参数1: {0} => {1}'.format(arg0, Memory.readCString(arg0)))
                console.log('参数2: {0} => {1}'.format(arg1, Memory.readCString(arg1)))
                console.log('参数3: {0} => {1}'.format(arg2, Memory.readCString(arg2)))
                console.log('参数4: {0} => {1}'.format(arg3, Memory.readCString(arg3)))
                console.log('参数5: {0} => {1}'.format(args[4], Memory.readCString(args[4])))
                console.log('\n')
            },
            onLeave: function(retval) {
                console.log('\n')
                console.log('=====> [encode] -> [方法调用后]:')
                console.log('返回值: ', retval)
                console.log('参数1: {0} => {1}'.format(retval, Memory.readCString(retval)))
                console.log('\n')
            }
        }   
    )
})
```

但是，还是出了些问题：

![image.png](https://b3logfile.com/file/2020/07/image-a20bb4b8.png)

额，我不觉得肉眼能看出这是什么东西

既然程序处理了一些不能看的东西，那就尝试去找出能看的东西吧 ?

我觉得选择`MDString`比较好，因为可以看到什么东西被拿去算md5了。

hook MDString：

```
console.log("========Hook Start==========")
 
String.prototype.format = function () {
    var values = arguments;
    return this.replace(/\{(\d+)\}/g, function (match, index) {
        if (values.length > index) {
            return values[index];
        } else {
            return "";
        }
    });
}
 
var JNI_LOAD_POINTER = Module.getExportByName('libnative-lib.so', 'JNI_OnLoad'); // 首先拿到 JNI_OnLoad方法的地址
var BASE_ADDR = parseInt(JNI_LOAD_POINTER) - parseInt('0x1C6C'); // 用程序运行中JNI_OnLoad的绝对地址减去它的相对地址得到基址
 
// MDString
Java.perform(function() {
    var hookpointer = '0x' + parseInt(BASE_ADDR + parseInt('0x15C4')).toString(16) // 获取要hook方法的地址
    var pointer = new NativePointer(hookpointer) // 根据方法地址构建NativePointer
    console.log('[MDString] hook pointer: ', pointer)
    
    var arg0, arg1, arg2, arg3
    Interceptor.attach(pointer, {
            onEnter: function(args) {
                arg0 = args[0]
                arg1 = args[1]
                arg2 = args[2]
                console.log('\n')
                console.log('=====> [MDString] -> [方法调用前]')
                console.log('参数1: {0} => {1}'.format(arg0, Memory.readCString(arg0)))
                console.log('\n')
            },
            onLeave: function(retval) {
                console.log('\n')
                console.log('=====> [MDString] -> [方法调用后]:')
                console.log('返回值: ', retval)
                console.log('返回: {0} => {1}'.format(retval, Memory.readCString(retval)))
                console.log('参数1: {0} => {1}'.format(arg0, Memory.readCString(arg0)))
                console.log('\n')
            }
        }   
    )
})
```

输出：

![image.png](https://b3logfile.com/file/2020/07/image-1cf74634.png)

可以发现，返回值正是将`/game/all_recommend/bfhdkud_time=1596004491`进行`MD5`加密：

![image.png](https://b3logfile.com/file/2020/07/image-74bc107d.png)

结合抓包到的请求，可以得到`NDKTOOL->encode`的原理：

由路径`/game/all_recommend`与时间戳`1596004491`以及`/bfhdkud_time=`

拼接成`/game/all_recommend/bfhdkud_time=1596004491`算出32位 小写md5 `837444501881f2af92b9cc0f0a9505fc`

## 结论

hkey的处理流程:

![image.png](https://b3logfile.com/file/2020/07/image-ab0c22ed.png)

注：Hook代码编写，参考：[Python反反爬虫 – Frida破解某安卓社区token反爬虫](https://www.jysafe.cn/go.html?url=https://www.jianshu.com/p/0e4f2dc0e919)

