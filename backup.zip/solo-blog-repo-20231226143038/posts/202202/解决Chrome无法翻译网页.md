title: 解决Chrome无法翻译网页
date: '2022-02-17 09:15:13'
updated: '2022-02-17 09:16:21'
tags: [chrome, hosts]
permalink: /articles/2022/02/17/1645060512804.html
---
下载打开Host工具，添加如下host解析(注意要勾选 启用)

```
203.208.40.66 translate.google.com
203.208.40.66 translate.googleapis.com
```

![image.png](https://b3logfile.com/file/2022/02/image-07d14e4f.png)

添加后，重启Chrome浏览器即可

### Host工具下载

[Host.7z](https://b3logfile.com/file/2022/02/Host-32a9c7f4.7z)

