title: Centos安装autossh
date: '2025-09-04 09:16:25'
updated: '2025-09-04 09:16:25'
tags: [Linux]
permalink: /articles/2025/09/04/1756948584990.html
---
```bash
yum install wget gcc make
wget https://www.harding.motd.ca/autossh/autossh-1.4g.tgz
tar -xf autossh-1.4g.tgz
cd autossh-1.4g
./configure
make
make install
```

