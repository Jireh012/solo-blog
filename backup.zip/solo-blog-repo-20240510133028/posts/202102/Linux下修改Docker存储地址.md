title: Linux下修改Docker存储地址
date: '2021-02-24 14:51:22'
updated: '2021-02-24 14:55:48'
tags: [Docker]
permalink: /articles/2021/02/24/1614149482692.html
---
Docker默认使用的是 **/var/lib/docker** 目录，基本上这个分区空间会比其他空间小，所以一开始设置Docker存储的地址是很有必要的。

Docker空间地址可以通过**daemon.json**文件来进行修改

```
vim /etc/docker/daemon.json
```

在这个配置文件中，插入如下配置

```
"graph": "/data2/docker"
```

完整配置（包含镜像仓库配置）

```
{"registry-mirrors": ["http://f1361db2.m.daocloud.io","https://docker.mirrors.ustc.edu.cn"],
 "insecure-registries": [
    "192.168.5.101:19820"
  ],
  "graph": "/data2/docker"
}
```

插入完成后保存退出

如果之前已经创建了容器，需要迁移至新路径的，执行以下命令

```
cp -ra /var/lib/docker/* /data2/docker/. 
```

重启Docker服务就配置完成了

```
systemctl restart docker
```

重启后可以通过 docker info 命令，查询是否配置成功

```
docker info | grep Dir
```

![image.png](https://b3logfile.com/file/2021/02/image-95d50ec1.png)

