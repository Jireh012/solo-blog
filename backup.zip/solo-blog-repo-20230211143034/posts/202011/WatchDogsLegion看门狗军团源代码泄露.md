title: '《Watch Dogs Legion》(看门狗 : 军团) 源代码泄露'
date: '2020-11-05 17:14:13'
updated: '2020-11-11 11:22:09'
tags: [Hacker, Game]
permalink: /articles/2020/11/05/1604567653048.html
---
# 《Watch Dogs Legion》(看门狗 : 军团) 源代码泄露

![看门狗军团科技点数怎么收集 科技点数收集方法介绍](https://b3logfile.com/file/2020/11/solofetchupload2688893823838419556-dd205a97.jpeg)

上个月，勒索软件黑帮 Egregor  宣称获得了知名游戏公司育碧和 Crytek 的内部数据。本周，Egregor 在其暗网网站上公开了育碧刚刚上市的游戏《Watch Dogs Legion》【看门狗 : 军团】的源代码，其容量高达 558GB，Egregor 放出的是一个种子文件。如果文件是真实的，如此规模的泄露是史无前例的。
以下为Egregor宣称：

> This developer if nominated not just for Hole of the Month. But also for the Clown of the Month Award.
> 
> We found source codes in free access in the main network. Passwords in the doc files without any protection,
> 
> all the employees and developers data and personal information, contract, game engines and a lot of more.
> 
> Guys, if the goal of the last mission in your game about hackers was the hack of your company, we’ve done it. There’s our prize?

> The game WATCH DOGS: LEGION was completely downloaded from your company servers.

> There’s a possibility that soon we will make a present to all fans. We will compile and upload the game to public access.

> The games of such level should be distributed freely. Nobody should take money for this.

育碧在一份声明中[表示](https://www.rockpapershotgun.com/2020/11/04/watch-dogs-legion-source-code-leaked-by-hackers-reports-claim/))它已经知道此事正对此展开调查。

> 想要种子文件，请关注原帖，并留言
> 看具体情况放出种子文件

---

> 既然有人要，那我就放出来把
> [ubi.7z](https://b3logfile.com/file/2020/11/ubi-cb25d933.7z)
> Passsword for archive: !I60j=3$"dC2c3,bFv5k

---

> 我下载完了😏 ，文件太大了，我也没有解压后，在打分包，直接是在原来的包上再打分包了
> 
> 链接：https://pan.baidu.com/s/1t3GwEy5TucbnNXRc3CkwIQ
> 提取码：50gh
> 复制这段内容后打开百度网盘手机App，操作更方便哦--来自百度网盘超级会员V3的分享

