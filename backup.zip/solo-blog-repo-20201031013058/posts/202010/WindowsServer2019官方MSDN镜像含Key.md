title: Windows Server 2019 官方 MSDN 镜像（含Key）
date: '2020-10-28 16:16:32'
updated: '2020-10-28 16:20:01'
tags: [Windows_Server]
permalink: /articles/2020/10/28/1603872992354.html
---
# Windows Server 2019 官方 MSDN 镜像（含Key）

> 文件：cn_windows_server_2019_x64_dvd_4de40f33.iso
> SHA：1cfa339cdbb4a1a4162bed38218b88ee376867b4f
> 文件大小：4.74GB
> 发布时间：2018-11-16
> 下载地址：https://pan.baidu.com/s/1NX_VG9kI2kE7NXiqCmQWLA
> 提取码：myi0

## Key

> Windows Server 2019 Standard 标准版
> [Key]：N69G4-B89J2-4G8F4-WWYCC-J464C
> 2020年10月28日 16:18:27 【亲测有效】

> Windows Server 2019 Datacenter 数据中心版
> [Key]：WMDGN-G9PQG-XVVXX-R3X43-63DFG
> 2020年10月28日 16:20:07 【亲测有效】


