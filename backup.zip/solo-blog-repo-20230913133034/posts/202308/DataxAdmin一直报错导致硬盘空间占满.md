title: Datax-Admin一直报错导致硬盘空间占满
date: '2023-08-07 17:45:19'
updated: '2023-08-07 17:45:19'
tags: [datax]
permalink: /articles/2023/08/07/1691401519359.html
---
最一台数据同步的linux一直硬盘空间爆满，发现datax-admin的日志文件非常大，清理后过了一两天再次服务器空间爆满

最好将日志文件下载过来，排查一下

发现日志当中都是一直重复报json解析时候的一个错误

```
2023-07-06 00:00:25,120 ERROR [http-nio-9527-exec-21] c.w.d.admin.core.util.JacksonUtil [JacksonUtil.java : 86] Illegal unquoted character ((CTRL-CHAR, code 26)): has to be escaped using backslash to be included in string value
 at [Source: (String)"[{"logId":13241,"logDateTim":1685950677000,"executeResult":{"code":500,"msg":"block strategy effectCover Early [job running, killed]","content":null}}]"; line: 1, column: 78] (through reference chain: java.util.ArrayList[0]->com.wugui.datatx.core.biz.model.HandleCallbackParam["executeResult"]->com.wugui.datatx.core.biz.model.ReturnT["msg"])
com.fasterxml.jackson.databind.JsonMappingException: Illegal unquoted character ((CTRL-CHAR, code 26)): has to be escaped using backslash to be included in string value
```

估计是Datax数据同步任务执行中，执行结果中包含部分特殊ASCII码，使用JacksonUtil解析时就会报这个错误

## 解决方法

在 **datax-admin/src/main/java/com/wugui/datax/admin/core/util/JacksonUtil.java**中添加一行

![1691401466050.png](https://b3logfile.com/file/2023/08/1691401466050-e6p6HQG.png)


```
objectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS,true);
```

