title: Centos安装Oracle客户端
date: '2022-06-24 17:11:24'
updated: '2022-06-24 17:11:24'
tags: [oracle]
permalink: /articles/2022/06/24/1656061883986.html
---
## 下载rpm软件包

官方下载地址：https://www.oracle.com/database/technologies/instant-client/linux-x86-64-downloads.html

需要**oracle-instantclient-basic**和**oracle-instantclient-sqlplus**这两个软件包

https://download.oracle.com/otn_software/linux/instantclient/216000/oracle-instantclient-basic-21.6.0.0.0-1.x86_64.rpm
https://download.oracle.com/otn_software/linux/instantclient/216000/oracle-instantclient-sqlplus-21.6.0.0.0-1.x86_64.rpm

## 安装

```
rpm -ivh oracle-instantclient-basic-21.6.0.0.0-1.x86_64.rpm 
rpm -ivh oracle-instantclient-sqlplus-21.6.0.0.0-1.x86_64.rpm
```

## 配置环境变量

```
vim /etc/profile
```

将配置添加到末尾

```
export ORACLE_HOME=/usr/lib/oracle/21.6/client64
export TNS_ADMIN=/usr/lib/oracle/21.6/client64
export LD_LIBRARY_PATH=/usr/lib/oracle/21.6/client64/lib
export ORABIN=/usr/lib/oracle/21.6/client64/bin
export PATH=$PATH:$ORABIN
export PATH=$ORACLE_HOME:$PATH
export PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin
```

更新环境变量

```
source /etc/profile
```

到这里Oracle的客户端 instantclient 就安装完成

## 连接

```
sqlplus C##SREPF/SREPF_zj135@127.0.0.1:32711/ORCLCDB
```

