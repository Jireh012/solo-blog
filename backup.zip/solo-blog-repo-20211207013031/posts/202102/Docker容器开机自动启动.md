title: Docker容器开机自动启动
date: '2021-02-24 09:21:52'
updated: '2021-02-24 09:21:52'
tags: [Docker]
permalink: /articles/2021/02/24/1614129712602.html
---
在创建容器的时候加入`--restart=always`参数，例如下

```
docker run --restart=always --name mssql --net=host \
-e 'ACCEPT_EULA=Y' -e 'MSSQL_PID=HMWJ3-KY3J2-NMVD7-KG4JR-X2G8G' \
-e 'SA_PASSWORD=123456' -v /data2/docker_volume/mssql2019:/var/opt/mssql -d \
192.168.5.101:19820/mssql/server:2019-latest
```

如果在创建容器的时候没有指定该参数，也可用通过**update**命令来添加该参数，例如如下

```
docker update --restart=always mssql
```

