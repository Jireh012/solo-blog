title: BladeX框架deploy脚本执行报错问题
date: '2020-07-28 15:01:58'
updated: '2020-07-28 15:01:58'
tags: [BladeX, Linux, Shell]
permalink: /articles/2020/07/28/1595919718622.html
---
# BladeX框架deploy脚本执行报错问题

在部署过程中，在Windows开发电脑上上传文件到Linux生产服务器中，执行deploy.sh脚本的时候报错。

报错如下：

```
syntax error near unexpected token `$'\r''
```

原因是Windows上编码和Linux(Unix)上不一致，而上传复制的时候sh脚本中又带有这样的编码格式，所以会导致sh脚本执行报错。

解决方案有好几种：

1. 使用sed工具 通过执行 `sed -i 's/\r//g' deploy.sh` 删除windows下多余的回车符。
2. `dos2unix `工具 安装`dos2unix `工具`apt install dos2unix`后，在执行`dos2unix deploy.sh`直接将文件转换成unix格式。
3. `tr -d '\r'`跟第一种方式同理，即删除多余回车符

其他还有好几种，但是觉得有些麻烦，不如以上3种方便，就不列举了。

