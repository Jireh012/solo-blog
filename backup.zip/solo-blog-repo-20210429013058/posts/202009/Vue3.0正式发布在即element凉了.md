title: Vue3.0正式发布在即，element凉了？
date: '2020-09-16 11:23:24'
updated: '2020-09-16 11:23:24'
tags: [日记, Vue, 前端]
permalink: /articles/2020/09/16/1600226604837.html
---
# Vue3.0正式发布在即，element凉了？

![image.png](https://b3logfile.com/file/2020/09/image-0e0ae909.png)

Vue3.0在今年第三季度正式发布。

但是element-ui据目前居然停更了4个月，要凉的赶脚么。

![image.png](https://b3logfile.com/file/2020/09/image-272680ae.png)

8/23、9/13只是更新说明，其他的都没有更新。

![image.png](https://b3logfile.com/file/2020/09/image-886fee4a.png)

提交最多的大佬也没更新了

根据网上消息，element核心团队都离职了，=。 =  不知道是不是阿里收购饿了么的关系。

现在就看vue3.0出了，会不会还是这样没有动静。毕竟隔壁ant都对3.0做兼容化处理了。





