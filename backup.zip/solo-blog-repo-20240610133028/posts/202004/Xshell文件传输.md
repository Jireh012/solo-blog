title: Xshell文件传输
date: '2020-04-07 15:30:03'
updated: '2020-04-07 15:30:03'
tags: [Linux, Xshell]
permalink: /articles/2020/04/07/1586244603053.html
---
# Xshell文件传输

使用 `yum` 或者 `apt-get install` 安装`lrzsz`软件包
`[root@VM_0_7_centos ~]# yum install -y lrzsz`

## 上传
直接在命令窗口键入 `rz`

![image.png](https://img.hacpai.com/file/2020/04/image-451343ed.png)

![image.png](https://img.hacpai.com/file/2020/04/image-e5cad54e.png)

## 下载

直接在命令窗口键入 `sz 文件路径`

例如：
`sz /etc/hosts`

![image.png](https://img.hacpai.com/file/2020/04/image-e4b79081.png)





