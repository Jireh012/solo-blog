title: VisualStudio发布应用时未能创建默认证书
date: '2020-11-16 10:15:31'
updated: '2020-11-16 10:15:31'
tags: [问题]
permalink: /articles/2020/11/16/1605492931586.html
---
在项目发布应用时发现出现 `未能创建默认证书。正在中止发布`错误。

Bd上查询了下，找到以下方案 https://blog.csdn.net/qq_40993412/article/details/95041047。

![image.png](https://b3logfile.com/file/2020/11/image-f12bcfa8.png)

但是自己的电脑上菜单中没有找到 Microsoft Office下的**VBA工程的数字证书工具**

![image.png](https://b3logfile.com/file/2020/11/image-6506c32a.png)

---

这个**VBA工程的数字证书工具 | SELFCERT.EXE**是在Office安装的时候就会自动安装，但是通过Everything查询又检索不到，后来在Office的安装路径下面找到了这个文件。

![image.png](https://b3logfile.com/file/2020/11/image-923f3e70.png)

Office安装路径可以通过Wold，Ppt，Excel这些快捷方式查询。

![image.png](https://b3logfile.com/file/2020/11/image-f9275e3b.png)

在打开目录查找**SELFCERT.EXE**，后面的步骤跟 https://blog.csdn.net/qq_40993412/article/details/95041047 一致





