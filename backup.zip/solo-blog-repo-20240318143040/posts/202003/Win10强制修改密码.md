title: Win10强制修改密码
date: '2020-03-25 17:37:26'
updated: '2020-03-25 17:37:36'
tags: [Win10]
permalink: /articles/2020/03/25/1585129046068.html
---
# Win10强制修改密码

此修改方法适用于设置开机自动登录，忘记了管理员密码的环境。

使用管理打开cmd或者powershell 输入一下命令：

```
net user  administrator password
```
其中 password是你修改后的密码
