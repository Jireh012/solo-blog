title: Unity项目导出Xcode MapFileParser编译报错解决方法
date: '2020-03-09 21:08:01'
updated: '2020-03-09 21:08:01'
tags: [开发小记, Unity]
permalink: /articles/2020/03/09/1583759281185.html
---
在 Unity 项目导出 Xcode，在 Xcode 中编译是可能会出现 MapFileParser.sh 相关提示的错误

这是因为 MapFileParser.sh 文件的读写权限不够而导致的。

<font color=red >
<strong> 解决方法： </strong>
<br/>
<br/>
1. 打开终端，在终端中进入项目文件的根目录。<br/>
例：cd /Users/hack/Public/Share/IOST1.0<br/>
2. 使用 chmod 命令对 MapFileParser.sh 进行权限设置 777.<br/>
命令如下：sudo chmod 777 MapFileParser.sh</font>
