title: '#1071 - Specified key was too long; max key length is 767 bytes'
date: '2020-12-02 15:12:08'
updated: '2020-12-02 15:12:08'
tags: [Mysql, Bug]
permalink: /articles/2020/12/02/1606893127977.html
---
在测试xpay的时候，遇到初始化数据库错误的情况
`#1071 - Specified key was too long; max key length is 767 bytes`

提示是字段的类型的大小超出了767字节，发现自己是用了Mysql6.5的版本

### 问题原因

> 在MySQL版本5.6（及更早版本）中，InnoDB表的[前缀限制](http://dev.mysql.com/doc/refman/5.1/en/create-index.html)为767个字节。MyISAM表的长度为1,000字节。在MySQL 5.7及更高版本中，此限制已增加到3072字节。

> 您还必须注意，如果在以utf8mb4编码的大char或varchar字段上设置索引，则必须将767字节（或3072字节）的最大索引前缀长度除以4，得到191。这是因为utf8mb4字符的最大长度为四个字节。对于utf8字符，它将是三个字节，导致最大索引前缀长度为254。

哈，只能升级版本了。

