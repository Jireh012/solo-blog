title: 'System.Net.Sockets.SocketException (0x80004005): 由于系统缓冲区空间不足或队列已满，不能执行套接字上的操作'
date: '2021-10-29 17:22:31'
updated: '2021-10-29 17:22:31'
tags: [Bug]
permalink: /articles/2021/10/29/1635499351468.html
---
今天服务突然出现异常，服务端调用其他接口出现错误

```
System.Net.Sockets.SocketException (0x80004005): 由于系统缓冲区空间不足或队列已满，不能执行套接字上的操作
```

最后的解决办法是，设置动态端口的范围

```
netsh int ipv4 set dynamicport tcp start=10000 num=30000
```

https://support.microsoft.com/en-us/help/929851/the-default-dynamic-port-range-for-tcp-ip-has-changed-in-windows-vista

