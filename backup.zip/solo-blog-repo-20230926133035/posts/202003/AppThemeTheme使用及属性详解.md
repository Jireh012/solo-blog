title: AppTheme Theme使用及属性详解
date: '2020-03-10 10:00:10'
updated: '2020-03-10 10:00:33'
tags: [Android, 开发小记]
permalink: /articles/2020/03/10/1583805610467.html
---
<pre class="EnlighterJSRAW" data-enlighter-language="xml" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">&lt;style name=&#34;AppTheme&#34; parent=&#34;Theme.AppCompat.Light.NoActionBar&#34;&gt;
    &lt;!--Appbar背景色，应用的主要色调，actionBar默认使用该颜色--&gt;
    &lt;item name=&#34;android:colorPrimary&#34;&gt;@color/material_animations_primary&lt;/item&gt;
    &lt;!--状态栏颜色，应用的主要暗色调，statusBarColor默认使用该颜色--&gt;
    &lt;item name=&#34;android:colorPrimaryDark&#34;&gt;@color/material_animations_primary_dark&lt;/item&gt;
    &lt;!--状态栏颜色，默认使用colorPrimaryDark--&gt;
    &lt;item name=&#34;android:statusBarColor&#34;&gt;@color/material_animations_primary_dark&lt;/item&gt;
    &lt;!--页面背景色--&gt;
    &lt;item name=&#34;android:windowBackground&#34;&gt;@color/light_grey&lt;/item&gt;
    &lt;!--底部导航栏颜色--&gt;
    &lt;item name=&#34;android:navigationBarColor&#34;&gt;@color/navigationColor&lt;/item&gt;
    &lt;!--应用的主要文字颜色，actionBar的标题文字默认使用该颜色--&gt;
    &lt;item name=&#34;android:textColorPrimary&#34;&gt;@android:color/black&lt;/item&gt;
    &lt;!--ToolBar上的Title颜色--&gt;
    &lt;item name=&#34;android:textColorPrimaryInverse&#34;&gt;@color/text_light&lt;/item&gt;
    &lt;!--应用的前景色，ListView的分割线，switch滑动区默认使用该颜色--&gt;
    &lt;item name=&#34;android:colorForeground&#34;&gt;@color/colorForeground&lt;/item&gt;
    &lt;!--应用的背景色，popMenu的背景默认使用该颜色--&gt;
    &lt;item name=&#34;android:colorBackground&#34;&gt;@color/colorForeground&lt;/item&gt;
    &lt;!--一般控件的选种效果默认采用该颜色--&gt;
    &lt;item name=&#34;android:colorAccent&#34;&gt;@color/colorAccent&lt;/item&gt;
    &lt;!--控件选中时的颜色，默认使用colorAccent--&gt;
    &lt;item name=&#34;android:colorControlActivated&#34;&gt;@color/colorControlActivated&lt;/item&gt;
    &lt;!--各个控制控件的默认颜色--&gt;
    &lt;item name=&#34;android:colorControlNormal&#34;&gt;@color/colorControlNormal&lt;/item&gt;
    &lt;!--Button，textView的文字颜色--&gt;
    &lt;item name=&#34;android:textColor&#34;&gt;@color/text_dark&lt;/item&gt;
    &lt;!--RadioButton checkbox等控件的文字--&gt;
    &lt;item name=&#34;android:textColorPrimaryDisableOnly&#34;&gt;@color/text_dark&lt;/item&gt;
    &lt;!--默认按钮的背景颜色--&gt;
    &lt;item name=&#34;android:colorButtonNormal&#34;&gt;@color/text_dark&lt;/item&gt;
    &lt;!--控件按压时的色调--&gt;
    &lt;item name=&#34;android:colorControlHighlight&#34;&gt;@color/colorControlHighlight&lt;/item&gt;


     &lt;!--title 标题栏字体设置--&gt;
    &lt;item name=&#34;android:titleTextAppearance&#34;&gt;@style/MaterialAnimations.TextAppearance.Title&lt;/item&gt;


    &lt;item name=&#34;android:windowContentTransitions&#34;&gt;true&lt;/item&gt;
    &lt;item name=&#34;android:windowAllowEnterTransitionOverlap&#34;&gt;false&lt;/item&gt;
    &lt;item name=&#34;android:windowAllowReturnTransitionOverlap&#34;&gt;false&lt;/item&gt;
&lt;/style&gt;</pre>

![](http://images2015.cnblogs.com/blog/1001760/201703/1001760-20170324122648283-2094267376.png)
