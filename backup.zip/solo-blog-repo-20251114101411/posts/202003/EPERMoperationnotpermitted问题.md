title: 'EPERM: operation not permitted问题'
date: '2020-03-10 10:07:38'
updated: '2020-03-10 10:07:38'
tags: [npm, 前端, 开发小记]
permalink: /articles/2020/03/10/1583806058271.html
---
前端项目当中先用了 npm Install 安装相关依赖的时候报错了，后来才看到推荐用 yarn 方式来安装依赖，但是之后在安装的时候遇到可错误， 提示错误如下： error An unexpected error occurred: “EPERM: operation not permitted, scandir xxxxxxxxxxxx，找了相关的资料，估计首次使用 npm 安装依赖报错的问题，造成 yarn 访问依赖文件夹出错，尝试用** npm cache clean -force** 清楚后，再次 yarn install 成功解决问题。
