title: 'Application: Failed to retrieve application JMX service URL'
date: '2021-09-01 09:04:31'
updated: '2021-09-01 09:04:31'
tags: [idea]
permalink: /articles/2021/09/01/1630458271161.html
---
日志中 Application: Failed to retrieve application JMX service URL 报错解决方法

![image.png](https://b3logfile.com/file/2021/09/image-5214e245.png)

关闭 JMX探针即可消除该错误



