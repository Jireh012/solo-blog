title: Solo 集成 Valine 评论系统
date: '2020-11-06 17:48:14'
updated: '2020-11-11 12:28:34'
tags: [Solo, Valine]
permalink: /articles/2020/11/06/1604656094535.html
---
# Solo 集成 Valine 评论系统

## 前言

新版的Solo移除的评论功能，虽然新版4.3.1版本可以引入 [Gitalk](https://github.com/gitalk/gitalk)（[引入文档](https://ld246.com/article/1594988019287)），但是Gitalk使用的Github的issues，在使用的过程中还是有不少的缺点。

### Gitalk缺点

1. 配置Gitalk，Github OAuth相关敏感信息会暴露出来
2. 因为是使用Github，所以经常由于网络问题，导致不稳定
3. 如果初次接入Gitalk，需要给之前写的每一篇文章初始化一次（嗯... 假如你写了200篇  那要被搞死）
4. 因为使用了Github issues，所以在[Issues](https://github.com/issues)中会显示你所有的Issues，会导致正常项目的Issues夹杂在你那200篇文章的Issues中，影响你的正常使用（嗯... 除非另外注册一个账户，专门给Gitalk使用）

---

## Valine

因为以上的各种因素，所以也找各种替代方案。然后就有了**Valine**的解决方案。有用过Hexo的应该会比较熟悉吧，然后在Solo中引入也是非常方便的。

### Leancloud

因为Valine评论系统评论是放在Leancloud上面的,所以首先你需要Leancloud的账号，[国内版](https://leancloud.cn)的还需要实名才能使用，[国际版](https://leancloud.app)的不需要实名（但是需要翻墙访问）

![image.png](https://b3logfile.com/file/2020/11/image-ab99a46f.png)

[国内版](https://leancloud.cn)   [国际版](https://leancloud.app)  如果没有Leancloud账号的到如下两个地址注册  [国内版注册地址](https://leancloud.cn/dashboard/login.html#/signup)   [国际版注册地址](https://console.leancloud.app/login.html#/signup)

**注册完成后登陆控制台**

#### 创建应用

![image.png](https://b3logfile.com/file/2020/11/image-8560876b.png)

**选择创建应用**

![image.png](https://b3logfile.com/file/2020/11/image-84bcba1b.png)

应用名称 `Solo-Blog-Talk` ，计价方案选择**开发版**

#### 实名认证

如果第一次注册或者没有实名认证的需要先实名认证，不然无法使用

实名认证地址：https://leancloud.cn/dashboard/settings.html#/setting/realname

#### 获取AppId和AppKey

![image.png](https://b3logfile.com/file/2020/11/image-d569884d.png)

在控制台进入应用，在**设置—应用Keys**中复制获取**AppId**和**AppKey**

#### 设置安全域名

![image.png](https://b3logfile.com/file/2020/11/image-f9bf6e19.png)

在**设置—安全中心**里的Web安全域名文本框中填入Blog的域名地址，我的Blog域名是`www.lyile.cn`，所以就填入`https://www.lyile.cn`**( 需要带上https://** **或者http://** **）**

到此，Leancloud侧的相关设置完成。接下来在SoloBlog中引入Valine

### Solo引入Valine

进入Solo 后台，在工具 - 偏好设定 - 信息配置中配置页头和页尾

#### 页头

![image.png](https://b3logfile.com/file/2020/11/image-88c1b5b3.png)

```
<script src='https://cdn.jsdelivr.net/npm/valine@1/dist/Valine.min.js'></script>
```

#### 页尾

```
<script>
        new Valine({
            el: '#vcomments',
            appId: '这里填Leancloud获取到的AppId',
            appKey: '这里填Leancloud获取到的AppKey'
        })
</script>
```

#### 签名档

**工具 - 偏好设定 - 签名档**

在你所使用的签名档中加入

```
<hr>
<div id="vcomments"></div>
```

## End

进行如上配置后，然后所有的文章就都会加上Valine评论系统了，不需要像Gitalk一个个初始化了

![image.png](https://b3logfile.com/file/2020/11/image-4dc91949.png)

