title: oracle invalid common user or role name
date: '2021-06-24 13:35:44'
updated: '2021-06-24 13:35:58'
tags: [oracle]
permalink: /articles/2021/06/24/1624512944354.html
---
oracle创建用户时报错

```
invalid common user or role name
```

原因新版12c在CDB中用户得以C##开头

```
create user c##SREPlatform identified by SREPlatform$112233;
```

