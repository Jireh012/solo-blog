title: Android解锁system分区新姿势
date: '2021-08-25 14:21:42'
updated: '2021-08-25 14:21:42'
tags: [adb]
permalink: /articles/2021/08/25/1629872502831.html
---
直接在HttpCanary中有使用到**Syslock**工具来解锁手机的system分区，但是syslock仅支持MIUI系统。

所以这次分享个近期发现的方法，通过ADB工具来解锁，需要**Root**

#### 使用方法

1. adb root
2. adb disable-verity

##### 重新上锁

1. adb root
2. adb enable-verity



