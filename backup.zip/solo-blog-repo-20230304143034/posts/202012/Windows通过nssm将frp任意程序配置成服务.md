title: Windows通过nssm将frp（任意程序）配置成服务
date: '2020-12-01 16:28:24'
updated: '2020-12-01 16:28:24'
tags: [Windows, frp, nssm]
permalink: /articles/2020/12/01/1606811304022.html
---
之前有用winsw配置frp的服务，但是最后没有成功，所以后来用nssm配置服务了，毕竟之前有成功过。

## nssm介绍

> nssm是一个服务助手，它并不糟糕。srvany和其他服务帮助程序很糟糕，因为它们不能处理作为服务运行的应用程序的故障。如果您使用这样的程序，您可能会看到一个服务被列为已启动，而实际上应用程序已经死亡。nssm监视正在运行的服务，如果服务终止，将重新启动它。有了nssm，您就知道如果一个服务说它正在运行，它就真的在运行。或者，如果您的应用程序运行良好，您可以配置nssm以免除重新启动它的所有责任，并让Windows负责恢复操作。
> 为什么它的应用程序不能像它的进程日志那样运行。
> nssm还具有图形化的服务安装和删除功能。在2.19版本之前，它确实很糟糕。现在好多了。

nssm也可以将任何exe配置成服务，比如在windows上配置gitea为服务等等。

## 必要的工具

* nssm
* frp（frps、frpc）【你所需要配置成服务的程序】
  bat，cmd，exe这些都是可以的

## nssm下载

[nssm2.24.zip](https://b3logfile.com/file/2020/12/nssm2.24-9d5f7f8a.zip)

## 使用说明/配置步骤

1. 下载nssm
2. 根据自己电脑的平台架构，将压缩包下32/64位nssm.exe文件解压至任意文件夹。
3. 在nssm.exe所在目录下shift+右键，选择在此处打开powershell或命令窗口，或者直接用上述工具定位至nssm.exe所在目录
4. 输入 `nssm install frps`，frps即注册服务的名称，此处为自定义 即`nssm install {服务名}`
5. 配置如下参数
   ![image.png](https://b3logfile.com/file/2020/12/image-5be02064.png)
   Path为应用程序文件，即需要配置成服务程序的地址
   Startup directory为启动文件夹，**该选项只要选择Path后即自动配置**
   Arguments为启动参数，frps需要配置启动参数所以这里配置为`-c frps.ini`
6. 配置完成后，点击Install service,即可完成配置
   ![image.png](https://b3logfile.com/file/2020/12/image-6991683d.png)
7. 创建后使用`nssm start frps`启动服务即可
   ![image.png](https://b3logfile.com/file/2020/12/image-7cacd43d.png)

### 其他命令

* 启动服务：`nssm start <servicename>`
* 停止服务： `nssm stop <servicename>`
* 重启服务: `nssm restart <servicename>`
* 编辑服务参数: `nssm edit <servicename>`
* 删除服务：`nssm remove <servicename>`

