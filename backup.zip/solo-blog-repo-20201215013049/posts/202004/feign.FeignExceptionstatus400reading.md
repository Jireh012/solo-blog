title: 'feign.FeignException: status 400 reading '
date: '2020-04-15 11:24:02'
updated: '2020-04-15 11:24:02'
tags: [开发小记]
permalink: /articles/2020/04/15/1586921042576.html
---
# feign.FeignException: status 400 reading 

问题是一个`@RequestParam`注解的参数，里面带数据过长导致的

用`@RequestBody`封装下解决
