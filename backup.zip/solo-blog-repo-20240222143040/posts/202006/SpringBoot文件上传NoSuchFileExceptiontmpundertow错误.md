title: 'SpringBoot文件上传NoSuchFileException: /tmp/undertow错误'
date: '2020-06-13 10:40:51'
updated: '2020-06-13 10:41:07'
tags: [Java, Spring]
permalink: /articles/2020/06/13/1592016051139.html
---
# SpringBoot文件上传NoSuchFileException: /tmp/undertow错误

```
Failed to parse multipart servlet request; 
nested exception is java.lang.RuntimeException: java.nio.file.NoSuchFileException: 
/tmp/undertow.3701241699676381582.32711/undertow1504003900571732622upload
```

SpringBoot文件上传接口，有时会报这个错误,但是服务重启后又不会出现这个问题。

---
原因是服务会自动在/temp下载创建一个临时文件夹，用于文件上传。但是系统经常会删除这里的文件夹，所以就会造成上面文件夹找不到的错误。

可以通过制定文件上传临时文件夹的路径，这样系统就不会自动删除了，或者去重启这个服务，再次去生成文件这样也可以。

## 指定临时文件夹路径

有两种方式，一种是在java启动命令中加入这个参数

` -java.tmp.dir=/data/upload_tmp`

或者在Spring配置文件中配置

```
spring:
  http:
    multipart:
      location: /data/upload_tmp
```
