title: 安装calico客户端工具calicoctl
date: '2021-12-01 16:48:04'
updated: '2021-12-01 16:48:04'
tags: [calico, k8s]
permalink: /articles/2021/12/01/1638348484646.html
---
### 下载对应版本的calicoctl

```
wget https://github.com/projectcalico/calicoctl/releases/download/v3.21.0/calicoctl -O /usr/bin/calicoctl
```

### 加上执行权限

```
chmod +x /usr/bin/calicoctl
```

### 添加calicoctl配置文件

```
DATASTORE_TYPE=kubernetes KUBECONFIG=~/.kube/config calicoctl get nodes
```

---

### 测试

```
[root@VM-0-2-centos ~]# calicoctl get node
NAME         
k8s-master   
k8s-pod-01   
k8s-pod-02
```
