title: Windows环境下Docker部署Oracle
date: '2022-08-24 11:19:51'
updated: '2022-08-24 11:19:51'
tags: [oracle, Docker]
permalink: /articles/2022/08/24/1661311191697.html
---
## 创建容器

```
docker run -d -p 1521:1521 --name oracle11g registry.cn-hangzhou.aliyuncs.com/helowin/oracle_11g
```

> 在我电脑上因为使用了**WSL 2**，导致发现容器一直启动不成功，报**Exited 139**
> 需要在用户文件夹【%userprofile%】下创建一个 .wslconfig 文件
> 文件内容如下
> 
> ```
> [wsl2]
> kernelCommandLine = vsyscall=emulate
> ```
> 
> 创建完成后cmd中执行**wsl --shutdown**，然后重启Docker再运行oracle容器即可

## 配置oracle

执行命令进入容器

```
docker exec -it oracle11g /bin/bash
```

使用root用户

```
su root
#root密码是： helowin
```

### 配置环境变量

```
vi /etc/profile
```

在末尾加入

```
export ORACLE_HOME=/home/oracle/app/oracle/product/11.2.0/dbhome_2
export ORACLE_SID=helowin
export PATH=$ORACLE_HOME/bin:$PATH
```

执行如下命令

```
source /etc/profile #更新环境变量
ln -s $ORACLE_HOME/bin/sqlplus /usr/bin #创建软连接
```

### oracle用户配置

切换回oracle用户

```
su - oracle
```

连接Oracle

```
sqlplus /nolog
conn /as sysdba
```

用户配置

```
alter user system identified by system;
alter user sys identified by sys;
# 设置密码永不过期
ALTER PROFILE DEFAULT LIMIT PASSWORD_LIFE_TIME UNLIMITED;
```

## 连接Oracle

![image.png](https://b3logfile.com/file/2022/08/image-d54b79e9.png)

**服务名为：helowin**

