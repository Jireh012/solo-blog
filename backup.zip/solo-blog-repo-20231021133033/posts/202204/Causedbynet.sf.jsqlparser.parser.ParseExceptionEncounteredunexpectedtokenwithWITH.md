title: 'Caused by: net.sf.jsqlparser.parser.ParseException: Encountered unexpected
  token: "with" "WITH"'
date: '2022-04-01 17:51:46'
updated: '2022-04-01 17:51:46'
tags: [mybatis-plus]
permalink: /articles/2022/04/01/1648806706513.html
---
同事写了个SQL遇到了这个问题，帮他解决了下

```
xxxxx group by name with ROLLUP
```

原因是框架中，有用到多租户的功能，Mybatis-plus 会 进行数据权限的过滤。要对该条sql，进行租户放行。

在Mapper上添加注解,解决

```
@SqlParser(filter=true)`
```

