title: Win10微软输入法快速输入时间
date: '2021-03-05 18:13:10'
updated: '2021-03-05 18:13:10'
tags: [Win10, 输入法]
permalink: /articles/2021/03/05/1614939189930.html
---
之前在用QQ拼音的时候输入**sj**会自动输入当前的日期时间如：**2021年03月05日 17:48:02**，但是后来为了某些原因不用QQ拼音的，改用Win10自带的微软拼音，输入法默认打入 **sj** 时只会输出 **17点49分**，这就很蛋疼了，毕竟我需要的是比较全的时间格式。

经过一番研究，发现微软拼音输入法自带可以自定义短语，废话不多说，干起来。

### 操作步骤

1. 首先点击语言，在弹出框中选择 **语言首选项**
   ![image.png](https://b3logfile.com/file/2021/03/image-5b623568.png)
2. 在语言设置中选择中文，点击选择后出现的**选项**
   ![image.png](https://b3logfile.com/file/2021/03/image-2aa7833d.png)
3. 选择**微软拼音**，点击选择后出现的**选项**
   ![image.png](https://b3logfile.com/file/2021/03/image-f0db443a.png)
4. 在**微软拼音**设置界面中，选择**词库和自学习**
   ![image.png](https://b3logfile.com/file/2021/03/image-9fdcf1f5.png)
5. 在随后的设置节目中打开**用户定义的短语**（如果没开的话），再点击**添加或编辑自定义短语**
   ![image.png](https://b3logfile.com/file/2021/03/image-56ae0bbd.png)
6. 在用户自定页面中，选择**添加**
   ![image.png](https://b3logfile.com/file/2021/03/image-2725ceae.png)
7. 最后配置以下信息
   ![image.png](https://b3logfile.com/file/2021/03/image-8ca7172f.png)
   
   示例：
   
   ```
   // 2021-03-05 18:10:03
   %yyyy%-%MM%-%dd% %HH%:%mm%:%ss%
   // 2021年03月05日 18:09:59
   %yyyy%年%MM%月%dd%日 %HH%:%mm%:%ss%
   ```

OK，配置在输入 **sj**，候选词条就会出现所配置的时间格式啦
![image.png](https://b3logfile.com/file/2021/03/image-424c001f.png)

