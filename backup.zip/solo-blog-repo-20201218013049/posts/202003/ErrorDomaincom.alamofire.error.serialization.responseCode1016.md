title: Error Domain=com.alamofire.error.serialization.response Code=-1016
date: '2020-03-09 21:47:32'
updated: '2020-03-09 21:47:32'
tags: [开发小记, IOS]
permalink: /articles/2020/03/09/1583761652267.html
---
今天在搞项目的时候发现，使用 AFNetwork 第三方库，Post 数据获取不过来。


报 Error Domain=com.alamofire.error.serialization.response Code=-1016 错误。


查了大量资料，据说是 AFNetwork 的解析格式不完全，所以需要在 AF 的源文件 AFURLResponseSerialization.m 中修改代码就能解决。


在代码中搜索 **acceptableContentTypes** ，在后面的代码中添加，所需要的格式。公司里面做服务器的，他用的是"text/plain"，所以我就在最后面添加上去就 OK 了。


 


<pre class="EnlighterJSRAW" data-enlighter-language="null">self.acceptableContentTypes = [NSSet setWithObjects:@&#34;application/json&#34;, @&#34;text/json&#34;, @&#34;text/javascript&#34;,@&#34;text/html&#34;,@&#34;text/plain&#34;, nil];</pre>
