title: Android获取当前子网掩码地址（亲测可用）
date: '2021-01-27 17:08:41'
updated: '2021-01-27 17:08:41'
tags: [Android]
permalink: /articles/2021/01/27/1611738521296.html
---
Android获取当前子网掩码地址（亲测可用），现在网上好多都是通过`DhcpInfo`来获取，但是通过这种方法有Bug，很多人用`DhcpInfo`的方式都是获取不到，都是为`0.0.0.0`。

以下为可用的方法

```
public static String getIpAddrMask() {
        try {
            Enumeration<NetworkInterface> networkInterfaceEnumeration = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaceEnumeration.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaceEnumeration.nextElement();
                if (!networkInterface.isUp()) {
                    continue;
                }

                for (InterfaceAddress interfaceAddress : networkInterface.getInterfaceAddresses()) {
                    if (interfaceAddress.getAddress() instanceof Inet4Address) {
                        return calcMaskByPrefixLength(interfaceAddress.getNetworkPrefixLength());
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return "get-error";
    }

    public static String calcMaskByPrefixLength(int length) {

        int mask = 0xffffffff << (32 - length);
        int partsNum = 4;
        int bitsOfPart = 8;
        int[] maskParts = new int[partsNum];
        int selector = 0x000000ff;

        for (int i = 0; i < maskParts.length; i++) {
            int pos = maskParts.length - 1 - i;
            maskParts[pos] = (mask >> (i * bitsOfPart)) & selector;
        }

        String result = "";
        result = result + maskParts[0];
        for (int i = 1; i < maskParts.length; i++) {
            result = result + "." + maskParts[i];
        }
        return result;
    }
```

##### 结果

```
I/System.out: 192.168.232.2
I/System.out: 255.255.248.0
I/System.out: 192.168.232.0/21
```

