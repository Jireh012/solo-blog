title: 安卓WebView同步Cookie及后续免登陆
date: '2020-03-10 10:01:18'
updated: '2020-03-10 10:01:18'
tags: [Android, 开发小记]
permalink: /articles/2020/03/10/1583805678233.html
---
最新项目中需要嵌入几个 H5 的界面，APP 的登入功能也放在 H5 端，第一次登入后，后续可以免登陆。使用 WebView 实现以上简单功能当中出现的问题和解决方法。

首先声明一个 WebView

<pre class="EnlighterJSRAW" data-enlighter-language="java" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">private WebView mWebView;</pre>

在定义两个 Url 变量，一个是登陆的 一个是登陆之后的

<pre class="EnlighterJSRAW" data-enlighter-language="java" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">public static final String ENTRANCE_URL_LOGIN = &#34;http://xxx.xxx.xxx.xxx/trouble/admin_login.aspx&#34;; //登陆url

public static final String ENTRANCE_URL_HOME = &#34;http://xxx.xxx.xxx.xxx/trouble/manager/index.aspx&#34;; //登陆后调整的url
</pre>

在 onCreate 中创建

<pre class="EnlighterJSRAW" data-enlighter-language="null" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">@SuppressLint(&#34;JavascriptInterface&#34;)
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login_web_view);
    CookieSyncManager.createInstance(this);
    CookieManager cookieManager = CookieManager.getInstance();
    String CookieStr = cookieManager.getCookie(ENTRANCE_URL_HOME); //获取cookie
    mWebView = (WebView) findViewById(R.id.webview);
    WebSettings webSettings = mWebView.getSettings();
    SharedPreferences cookid = getSharedPreferences(&#34;UserConfiguration&#34;,MODE_PRIVATE);//存储Cookie信息

    webSettings.setJavaScriptEnabled(true);//打开js支持
    /**
     * 打开js接口給H5调用，参数1为本地类名，参数2为别名；h5用window.别名.类名里的方法名才能调用方法里面的内容，例如：window.android.back();
     * */
    mWebView.addJavascriptInterface(new JsInteration(), &#34;JSInterface&#34;);
    mWebView.setWebViewClient(new WebViewClient());
    mWebView.setWebChromeClient(new WebChromeClient());

    // 开启Javascript脚本
    webSettings.setJavaScriptEnabled(true);
    // 判断Cookie是否存在
    if(TextUtils.isEmpty(CookieStr)) {
        mWebView.loadUrl(ENTRANCE_URL_LOGIN);
    } else{
        //同步Cookie给WebView
        syncCookie(ENTRANCE_URL_HOME,CookieStr);
        mWebView.loadUrl(ENTRANCE_URL_HOME);
    }
    //使用SharedPreferences存储
    SharedPreferences.Editor editor =cookid.edit();
    editor.putString(&#34;cookid&#34;,cookieManager.getCookie(ENTRANCE_URL_HOME));
    editor.commit();
    Log.d(TAG, &#34;onCreate cookie:&#34; + CookieStr);
}</pre>

以上有加 JS 支持，要是没用可以删掉。

syncCookie 同步 Cookie 方法

<pre class="EnlighterJSRAW" data-enlighter-language="java" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">/**
    * 将cookie同步到WebView
    * @param url WebView要加载的url
    * @param cookie 要同步的cookie
    * @return true 同步cookie成功，false同步cookie失败
    * @Author JPH
    */
   public static boolean syncCookie(String url,String cookie) {
           if (Build.VERSION.SDK_INT &lt; Build.VERSION_CODES.LOLLIPOP) {
               CookieSyncManager.createInstance(context);
           }
       CookieManager cookieManager = CookieManager.getInstance();
       cookieManager.setCookie(url, cookie);//如果没有特殊需求，这里只需要将session id以&#34;key=value&#34;形式作为cookie即可
       String newCookie = cookieManager.getCookie(url);
       return TextUtils.isEmpty(newCookie)?false:true;
   }</pre>

布局文件

<pre class="EnlighterJSRAW" data-enlighter-language="xml" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">&lt;?xml version=&#34;1.0&#34; encoding=&#34;utf-8&#34;?&gt;
&lt;LinearLayout xmlns:android=&#34;http://schemas.android.com/apk/res/android&#34;
              android:layout_width=&#34;fill_parent&#34;
              android:layout_height=&#34;fill_parent&#34;
              android:orientation=&#34;vertical&#34; &gt;

    &lt;WebView
            android:id=&#34;@+id/webview&#34;
            android:layout_width=&#34;fill_parent&#34;
            android:layout_height=&#34;fill_parent&#34;
            android:layout_weight=&#34;9&#34;
            /&gt;

&lt;/LinearLayout&gt;</pre>

到这里就可以实现基本的功能
