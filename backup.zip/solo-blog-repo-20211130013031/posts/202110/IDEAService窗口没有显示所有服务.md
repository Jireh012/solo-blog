title: IDEA Service窗口没有显示所有服务
date: '2021-10-21 10:13:00'
updated: '2021-10-21 10:13:00'
tags: [idea]
permalink: /articles/2021/10/21/1634782380425.html
---
编辑项目根目录 .idea — workspace.xml 文件，找到 **RunDashboard** 替换成如下代码，然后重启即可

```
<component name="RunDashboard">
    <option name="configurationTypes">
      <set>
        <option value="SpringBootApplicationConfigurationType" />
      </set>
    </option>
    <option name="ruleStates">
      <list>
        <RuleState>
          <option name="name" value="ConfigurationTypeDashboardGroupingRule" />
        </RuleState>
        <RuleState>
          <option name="name" value="StatusDashboardGroupingRule" />
        </RuleState>
      </list>
    </option>
</component>
```

