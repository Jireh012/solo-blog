title: 'bash: /dev/fd/63: No such file or directory'
date: '2025-06-21 14:55:12'
updated: '2025-06-21 14:55:53'
tags: [Linux]
permalink: /articles/2025/06/21/1750488912797.html
---
在部署1panel时提示需要安装docker，执行官方给的`bash <(curl -sSL https://linuxmirrors.cn/docker.sh)`时会报这个`bash: /dev/fd/63: No such file or directory`错误

### 解决方法

修改原来的命令

```
bash -c "$(curl -sSL https://linuxmirrors.cn/docker.sh)"
```

基本适用与所有该报错导致的问题

