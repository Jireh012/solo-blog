title: Nginx禁止GoogleBot抓取
date: '2021-04-08 15:35:32'
updated: '2021-04-08 15:35:32'
tags: [nginx]
permalink: /articles/2021/04/08/1617867332616.html
---
在配置文件中加入如下代码：

```
if ($http_user_agent ~* "Googlebot")
{
	return 503;
}
```



