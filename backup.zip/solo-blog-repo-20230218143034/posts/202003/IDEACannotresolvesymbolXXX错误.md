title: IDEA Cannot resolve symbol XXX 错误
date: '2020-03-24 16:47:59'
updated: '2020-03-24 16:47:59'
tags: [开发小记]
permalink: /articles/2020/03/24/1585039679878.html
---
# IDEA Cannot resolve symbol XXX 错误

Cloud子模块controller突然无法找到entity,vo,dto,service。 一脸懵逼

最后用 File菜单中 **Invalidate Caches - Invalidate and restart**（ 清除缓存并重启 ）一下解决

不过缺点就是本地的Local history的记录会清空。




