title: windows远程桌面不能复制修复
date: '2021-01-20 16:17:56'
updated: '2021-01-20 16:17:56'
tags: [Windows]
permalink: /articles/2021/01/20/1611130676211.html
---
修复windows远程桌面不能复制问题，在远程端执行以下步骤

1. 将rdpclip.exe进程杀死（如果存在）
2. 运行rdpclip.exe

### 一键傻瓜式脚本：

[一键修复不能复制问题.7z](https://b3logfile.com/file/2021/01/一键修复不能复制问题-24a11be0.7z)

