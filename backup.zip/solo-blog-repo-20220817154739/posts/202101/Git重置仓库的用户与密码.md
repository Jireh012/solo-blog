title: Git重置仓库的用户与密码
date: '2021-01-12 17:04:52'
updated: '2021-01-12 17:04:52'
tags: [Git]
permalink: /articles/2021/01/12/1610442291930.html
---
## Git重置仓库的用户与密码

```
git config --system --unset credential.helper
git config --global credential.helper store
```

