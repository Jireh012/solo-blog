title: Error running Application. Command line is too long.
date: '2021-09-01 09:33:52'
updated: '2021-09-01 09:33:52'
tags: [idea]
permalink: /articles/2021/09/01/1630460032162.html
---
运行项目时报错

> Error running 'Application'
> Error running Application. Command line is too long.
> Shorten the command line via JAR manifest or via a classpath file and rerun.

#### 解决方法：

你可以直接在日志中选择

![image.png](https://b3logfile.com/file/2021/09/image-7e9ebf15.png)

或者打开应用运行配置

![image.png](https://b3logfile.com/file/2021/09/image-38bb34a6.png)

选择 JAR manifest 或者 classpath file，**推荐选择classpath file**

