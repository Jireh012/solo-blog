title: '7za: command not found'
date: '2021-06-22 16:22:44'
updated: '2021-06-22 16:22:44'
tags: [Linux]
permalink: /articles/2021/06/22/1624350164540.html
---
7z环境没有安装

使用命令安装7z相关环境

```
apt-get install p7zip p7zip-full p7zip-rar
```

