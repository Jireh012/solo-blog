title: exe4j中引入lib类库文件夹不生效问题
date: '2020-12-15 16:01:02'
updated: '2020-12-15 16:01:02'
tags: [exe4j, Java]
permalink: /articles/2020/12/15/1608019261863.html
---
![image.png](https://b3logfile.com/file/2020/12/image-259b6084.png)

使用maven打包，或者第三方类库是在/lib文件夹中的，在通过exe4j配置中添加lib文件夹，封装exe后无法启动，提示`Caused by: java.lang.ClassNotFoundException`错误。

### 解决方法

![image.png](https://b3logfile.com/file/2020/12/image-5a70fe38.png)

在选择type的时候不要选择**JAR in EXE mode**，要选择**Regular mode**。

![image.png](https://b3logfile.com/file/2020/12/image-f2125ccc.png)

选择完，重新进行封装后，正常运行。





