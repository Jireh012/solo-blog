title: v2ray转发mtp配置
date: '2020-09-27 09:02:56'
updated: '2020-09-27 09:02:56'
tags: [proxy]
permalink: /articles/2020/09/27/1601168576136.html
---
```
{
  "policy": {
    "levels": {
      "0": {
        "uplinkOnly": 0
      }
    }
  },
  "dns": {
    "servers": [
      "1.1.1.1"
    ]
  },
  "outboundDetour": [
    {
      "tag": "tg-out",
      "protocol": "mtproto",
      "settings": {},
      "proxySettings": {
        "tag": "v2-out"
      }
    }
  ],
  "inbound": {
    "tag": "tg-in",
    "port": 56789,//这个是MTP代理的端口
    "protocol": "mtproto",
    "settings": {
      "users": [
        {
          "secret": "ed2da9d2251cbb4835f18659780cc126"//这个是mtp代理的密码，格式是32位的使用阿拉伯数字和字母abcdef组成的密码
        }
      ]
    }
  },
  "log": {
    "loglevel": "debug"
  },
  "routing": {
    "strategy": "rules",
    "settings": {
      "domainStrategy": "IPIfNonMatch",
      "rules": [
        {
          "type": "field",
          "inboundTag": [
            "tg-in"
          ],
          "outboundTag": "tg-out"
        }
      ]
    }
  },
  "outbound": {
    "tag":"v2-out",
    "sendThrough": "0.0.0.0",
    "mux": {
      "enabled": false,
      "concurrency": 8
    },
    "protocol": "vmess",
    "settings": {
      "vnext": [
        {
          "address": "xxxxxxxxxxxxxx",//v2ray服务器的地址
          "port": 443,//v2ray服务器的端口
          "users": [
            {
              "id": "abc6cd5b-30dc-4ad4-aad0-d575308b9a20",//你的uuid
              "alterId": 2,
              "security": "auto",
              "level": 2
            }
          ],
          "remark": "NodeName"
        }
      ]
    },
    "streamSettings": { 
                "network": "ws", 
                "security": "tls", 
                "tlsSettings": { 
                    "serverName": "xxxxxxxx" 
                }, 
                "wsSettings": { 
                    "path": "/xxxxx", 
                    "headers": { 
                        "Host": "xxxxxxxx" 
                    } 
                } 
            }, 
            "mux": { 
                "enabled": true 
            } 
  }
}
```

