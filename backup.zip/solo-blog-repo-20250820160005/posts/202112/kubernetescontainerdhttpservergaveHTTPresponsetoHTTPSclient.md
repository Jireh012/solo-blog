title: 'kubernetes containerd http: server gave HTTP response to HTTPS client'
date: '2021-12-02 09:49:15'
updated: '2021-12-02 09:49:15'
tags: [k8s, containerd, kubernetes]
permalink: /articles/2021/12/02/1638409755466.html
---
在kubernetes中使用containerd容器服务获取私有仓库的镜像的时候报错

```
`https://xxxxxxx/v2/xxxx/xxxx/manifests/sha256:xxxx: http: server gave HTTP response to HTTPS client`
```

原因是因为私有仓库没有配置https还是http，但是容器获取镜像是通过https的。

### 解决方案

如果你的k8s采用的是docker方案，就只需要在docker的配置文件当中添加 **insecure-registries** 参数即可

如果跟我一样是用的containerd方案，就需要在 **/etc/containerd/config.toml** 配置文件中当中添加修改如下配置，修改其中`<host>`为仓库地址，`<port>`为端口地址

```
[plugins."io.containerd.grpc.v1.cri".registry]
      [plugins."io.containerd.grpc.v1.cri".registry.mirrors]
        [plugins."io.containerd.grpc.v1.cri".registry.mirrors."docker.io"]
          endpoint = ["https://registry.cn-hangzhou.aliyuncs.com"]
        [plugins."io.containerd.grpc.v1.cri".registry.mirrors."<host>:<port>"]
          endpoint = ["http://<host>:<port>"]
      [plugins."io.containerd.grpc.v1.cri".registry.configs]
        [plugins."io.containerd.grpc.v1.cri".registry.configs."<host>:<port>".tls]
          insecure_skip_verify = true
```



