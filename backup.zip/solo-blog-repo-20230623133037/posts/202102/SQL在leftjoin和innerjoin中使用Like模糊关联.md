title: SQL 在left join和inner join中使用Like模糊关联
date: '2021-02-06 11:04:38'
updated: '2021-02-06 11:04:38'
tags: [SQL]
permalink: /articles/2021/02/06/1612580677948.html
---
SQL 在left join和inner join中使用Like模糊关联

```sql
select * from aaa a
LEFT JOIN bbb b on b.field like '%'+a.field +'%'
```

