title: selenium报session not created from tab crashed异常
date: '2021-01-08 09:54:22'
updated: '2021-01-08 09:54:22'
tags: [Java, selenium]
permalink: /articles/2021/01/08/1610070862654.html
---
使用无头浏览器模式`--headless`报了这个错误,这个模式可以隐藏窗口，应该是标签没有创建成功

在开发机上运行的时候，没有报这个错误，但是编译打包在需要执行的服务器上执行的时候就报了这个错误。

```
session not created from tab crashed
  (Session info: headless chrome=87.0.4280.88)
Build info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:17:03'
System info: host: 'host', ip: '192.168.5.102', os.name: 'Windows Server 2008 R2', os.arch: 'x86', os.version: '6.1', java.version: '1.8.0_221'
Driver info: driver.version: ChromeDriver
remote stacktrace: Backtrace:
	Ordinal0 [0x0133C0C3+3326147]
	Ordinal0 [0x01220851+2164817]
	Ordinal0 [0x010A7140+618816]
	Ordinal0 [0x0109BC40+572480]
	Ordinal0 [0x0109BA18+571928]
	Ordinal0 [0x0109B0C1+569537]
	Ordinal0 [0x0109A421+566305]
	Ordinal0 [0x0109A815+567317]
	Ordinal0 [0x0109A135+565557]
	Ordinal0 [0x010A38B1+604337]
	Ordinal0 [0x0109A0F1+565489]
	Ordinal0 [0x0109AEA2+568994]
	Ordinal0 [0x0109A421+566305]
	Ordinal0 [0x0109A815+567317]
	Ordinal0 [0x0109A135+565557]
	Ordinal0 [0x0109F808+587784]
	Ordinal0 [0x0109F857+587863]
	Ordinal0 [0x0109A0F1+565489]
	Ordinal0 [0x0109AEA2+568994]
	Ordinal0 [0x0109A421+566305]
	Ordinal0 [0x0109A815+567317]
	Ordinal0 [0x0109A135+565557]
	Ordinal0 [0x010A1D2C+597292]
	Ordinal0 [0x0109A0F1+565489]
	Ordinal0 [0x0109AEA2+568994]
	Ordinal0 [0x0109A421+566305]
	Ordinal0 [0x0109A815+567317]
	Ordinal0 [0x0109A135+565557]
	Ordinal0 [0x0109FE62+589410]
	Ordinal0 [0x0109A0F1+565489]
	Ordinal0 [0x0109AEA2+568994]
	Ordinal0 [0x0109A421+566305]
	Ordinal0 [0x0109A815+567317]
	Ordinal0 [0x0109A135+565557]
	Ordinal0 [0x0109F075+585845]
	Ordinal0 [0x0109A0F1+565489]
	Ordinal0 [0x0109AEA2+568994]
	Ordinal0 [0x0109A421+566305]
	Ordinal0 [0x0109A815+567317]
	Ordinal0 [0x0109A135+565557]
	Ordinal0 [0x01096776+550774]
	Ordinal0 [0x0109A0F1+565489]
	Ordinal0 [0x01099F13+565011]
	Ordinal0 [0x01099D07+564487]
	Ordinal0 [0x010A82C0+623296]
	Ordinal0 [0x01046BDD+224221]
	Ordinal0 [0x01045CAC+220332]
	Ordinal0 [0x0104189B+202907]
	Ordinal0 [0x01023DF4+81396]
	Ordinal0 [0x01024DEE+85486]
	Ordinal0 [0x01024D79+85369]
	Ordinal0 [0x012385DC+2262492]
	GetHandleVerifier [0x014C2874+1487204]
	GetHandleVerifier [0x014C23CD+1486013]
	GetHandleVerifier [0x014CA368+1518680]
	GetHandleVerifier [0x014C2F4E+1488958]
	Ordinal0 [0x0122ED0D+2223373]
	Ordinal0 [0x0123A12B+2269483]
	Ordinal0 [0x0123A26F+2269807]
	Ordinal0 [0x0124ECB8+2354360]
	BaseThreadInitThunk [0x7600343D+18]
	RtlInitializeExceptionChain [0x76FD9802+99]
	RtlInitializeExceptionChain [0x76FD97D5+54]
```

### 解决方法

在初始化ChromeDriver的时候加上
`chromeOptions.addArguments("--no-sandbox");`
`chromeOptions.addArguments("--disable-dev-shm-usage");`

这将强制Chrome使用该`/tmp`目录。尽管这可能会减慢执行速度，因为将使用磁盘而不是内存。

完整示例：

```
		    // ChromeOptions
                    ChromeOptions chromeOptions = new ChromeOptions();
                    // 设置后台静默模式启动浏览器
                    chromeOptions.addArguments("--no-sandbox");
                    chromeOptions.addArguments("--headless");
		    chromeOptions.addArguments("--disable-dev-shm-usage");
                    WebDriver driver = new ChromeDriver(chromeOptions);
```


