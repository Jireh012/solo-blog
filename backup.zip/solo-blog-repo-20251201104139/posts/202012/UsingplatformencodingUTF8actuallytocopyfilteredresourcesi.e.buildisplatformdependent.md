title: Using platform encoding (UTF-8 actually) to copy filtered resources, i.e. build
  is platform dependent!
date: '2020-12-11 10:20:17'
updated: '2020-12-11 10:20:17'
tags: [开发小记, Maven, Java]
permalink: /articles/2020/12/11/1607653217353.html
---
Maven项目编译的时候报了告警，抱着有强迫症的精神，解决这个告警

`Using platform encoding (UTF-8 actually) to copy filtered resources, i.e. build is platform dependent! `

### 解决方案

在项目根目录**pom.xml**文件中的**properties**标签下面加入`<project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>`

示例：

```
<properties>
        <maven.compiler.source>8</maven.compiler.source>
        <maven.compiler.target>8</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
</properties>
```

