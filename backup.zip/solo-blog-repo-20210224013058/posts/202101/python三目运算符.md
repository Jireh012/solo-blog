title: python三目运算符
date: '2021-01-20 10:17:18'
updated: '2021-01-20 10:17:18'
tags: [python]
permalink: /articles/2021/01/20/1611109038173.html
---
> python三目运算符,如果data=1那么赋值888，否则为999

```python
data = 1
data = data == 1 and 888 or 999
```

