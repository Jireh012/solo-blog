title: Centos使用Docker部署Searx
date: '2020-10-10 17:18:29'
updated: '2020-12-16 14:14:38'
tags: [Searx, Docker, Centos]
permalink: /articles/2020/10/10/1602321509654.html
---
# Searx使用Docker部署

![image.png](https://b3logfile.com/file/2020/10/image-e6b956d4.png)

![image.png](https://b3logfile.com/file/2020/10/image-62b3179a.png)

> 一个基于`Python`的完全开源免费搜索引擎平台，为你提供来自`Google`、`Bing`、`Yahoo`等`70`多种各大视频、图片、搜索、磁力等网站结果展示，并对搜索结果进行优化，同时不会存储你的任何搜索信息，搭建也很方便，有兴趣的可以搭建给需要谷歌的同事或朋友用下。

> [官方Github](https://github.com/asciimoo/searx)

网上很多教程使用的dockerfile有点问题，提示Python2不支持，无法正常启动，所以我就自己修改了下，并记录下部署的过程记录。

> [项目Github](https://github.com/Jireh012/searx-docker)

* [ ] 搜索语言已经默认改成了中文
* [ ] 轻量配置，如需修改请查询 [相关文档](https://searx.github.io/searx/admin/settings.html)

## 安装环境

* [ ] Git
* [ ] Docker

如果已经安装，略过该步骤

---

### Docker

傻瓜式一键命令 ``` curl -sSL https://get.daocloud.io/docker | sh ```

### Git

```yum -y install git```

## 构建镜像

```
git clone https://github.com/Jireh012/searx-docker
cd searx-docker
docker build -t searx .
```

## 启动容器

`docker run -d --name searx -p 37012:8888 searx `

