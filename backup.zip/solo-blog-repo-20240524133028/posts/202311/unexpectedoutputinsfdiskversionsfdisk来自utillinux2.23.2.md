title: unexpected output in sfdisk --version [sfdisk,来自 util-linux 2.23.2]
date: '2023-11-07 14:18:00'
updated: '2023-11-07 14:18:00'
tags: [Linux, 腾讯云]
permalink: /articles/2023/11/07/1699337880766.html
---
最近公司的腾讯云服务器磁盘空间满了，在执行官方扩容硬盘步骤的时候出现了错误

在执行`growpart /dev/vda 1`的时候出现了如下报错

```
unexpected output in sfdisk --version [sfdisk,来自 util-linux 2.23.2]
```

## 解决办法

将系统当前的编码类型改成英文

```
export LANG=en_US.UTF-8export LANG=en_US.UTF-8
```

查询当前系统编码

```
echo $LANG
```

---

修改完成后在执行`growpart /dev/vda 1`的时候就不会报错了

