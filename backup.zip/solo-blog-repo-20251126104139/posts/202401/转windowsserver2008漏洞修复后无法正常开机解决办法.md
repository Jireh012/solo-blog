title: 【转】windows server 2008漏洞修复后无法正常开机解决办法
date: '2024-01-09 17:04:13'
updated: '2024-01-09 17:04:13'
tags: [Windows_Server]
permalink: /articles/2024/01/09/1704791053220.html
---
记录一次公司服务器Windows Server 2008 R2无法启动采用的修复方案

---

windows server 2008漏洞修复后无法正常开机解决办法
今天客户的一台服务器由于装了EDR杀毒软件，自动修复了漏洞，重启后无法正常进入windows界面，后来通过CMD编写代码+寻找合适阵列驱动，成功恢复。现在来讲下过程
1、无法进入系统目前的状态：
![image.png](https://b3logfile.com/file/2024/01/image-TPBwKvM.png)

只能进入这个界面，
插一句，必须提前知道阵列的型号，并且提前下载好驱动包。
我这台服务器是联想X3500的，进入BIOS查到型号是M5210，于是就去网上找对应的驱动并放到U盘里。
![image.png](https://b3logfile.com/file/2024/01/image-7ADF5IS.png)

下一步，选择第一个，使用工具
![image.png](https://b3logfile.com/file/2024/01/image-eHOUCBu.png)

然后插上带有驱动的U盘，系统会检测到，选择加载驱动程序，接着就能看到硬盘了，记住硬盘Windows的系统盘符（不一定是C盘），我这台是F盘，接下来进去CMD命令界面，如果盘符不对会这样
![image.png](https://b3logfile.com/file/2024/01/image-Va6uAqH.png)

输入`dism /image:f:\ / cleanup-image /revertpendingactions`
这边要特别注意，`/cleanup-image和 /revertpendingactions`前面都有一个空格，如果没有空格会出现
![image.png](https://b3logfile.com/file/2024/01/image-dOiuAa1.png)

不扯了，输入正确的命令后，会出现这个界面，需要等待大概15-30分钟，
![image.png](https://b3logfile.com/file/2024/01/image-KQgtMWq.png)

30分钟后就出现，操作成功的字样，这样关闭对话框，拔掉U盘，重启电脑
![image.png](https://b3logfile.com/file/2024/01/image-snit5u2.png)

如果进入这个界面，说明已经离成功不远了，大概等10分钟左右，电脑提示windows update 错误，没有关系，可能是网络的问题，这边有几种办法，要么干错把网线拔了（这样最快），要么插着网线等1个小时，自动更新漏洞，我果断选择了前者，系统提示windows update 错误后会自动还原，要做的就是等，其中服务器还会重启一次，再次出现这个界面，再等10分钟，惊喜出现了
![image.png](https://b3logfile.com/file/2024/01/image-fcXWD6p.png)

已经可以进入登入界面了，输入密码进去后，一切正常，果断把自动修复漏洞的关闭，至此，整个过程结束。。。。
————————————————
版权声明：本文为CSDN博主「口卡口察」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/qq_24374247/article/details/108120987

