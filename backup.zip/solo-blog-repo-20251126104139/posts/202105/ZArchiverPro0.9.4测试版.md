title: ZArchiverPro0.9.4测试版
date: '2021-05-06 10:28:37'
updated: '2021-05-06 10:28:37'
tags: [手机工具]
permalink: /articles/2021/05/06/1620268117693.html
---
> ZArchiver-是用于存档管理的程序。它具有简单实用的界面。该应用没有访问互联网的权限，因此无法将任何信息传输给其他服务或人员。
> 
> 专业版的优点：
> -光明与黑暗的主题；
> -密码存储；
> -存档中的图像预览；
> -编辑档案中的文件（请参见注释）；
> ZArchiver-是用于存档管理的程序。它具有简单实用的界面。该应用程序无权访问互联网，因此无法将任何信息传输给其他服务或人员。

> ZArchiver可让您：

> -创建以下归档类型：7z（7zip），zip，bzip2（bz2），gzip（gz），XZ，lz4，tar，zst（zstd）；
> -解压缩以下档案类型：7z（7zip），zip，rar，rar5，bzip2，gzip，XZ，iso，tar，arj，cab，lzh，lha，lzma，xar，tgz，tbz，Z，deb，rpm， zipx，mtz，chm，dmg，cpio，cramfs，img（fat，ntfs，ubf），wim，ecm，lzip，zst（zstd），egg，alz；
> -查看档案内容：7z（7zip），zip，rar，rar5，bzip2，gzip，XZ，iso，tar，arj，cab，lzh，lha，lzma，xar，tgz，tbz，Z，deb，rpm，zipx， mtz，chm，dmg，cpio，cramfs，img（fat，ntfs，ubf），wim，ecm，lzip，zst（zstd），egg，alz;
> -创建和解压缩受密码保护的档案；
> -编辑档案：在档案中添加文件或从中删除文件（zip，7zip，tar，apk，mtz）；
> -创建和解压缩多部分档案：7z，rar（仅解压缩）；
> -部分存档解压缩；
> -打开压缩文件；
> -从邮件应用程序中打开一个存档文件；
> -提取拆分的归档文件：7z，zip和rar（7z.001，zip.001，part1.rar，z01）；

> 特殊性能：
> -从小文件（<10MB）的Android 9开始。如果可能，请直接打开而不提取到临时文件夹；
> -多线程支持（适用于多核处理器）；
> -对文件名的UTF-8 / UTF-16支持允许您在文件名中使用国家符号。

### 下载地址

> 安卓手机下载arm，2017以后的手机下载v8a，v7a都可以，2017以前的下载v7a，安卓平板下载x86

[ZArchiverPro0.9.4_arm64_v8a_test.7z](https://b3logfile.com/file/2021/05/ZArchiverPro_0_9_4_arm64-v8a_test-b44d7eb4.7z)
[ZArchiverCloudPlugin0.1.apk.7z](https://b3logfile.com/file/2021/05/ZArchiver_Cloud_Plugin_0.1.apk-c399d142.7z)
[ZArchiverPro0.9.4_armeabi_v7a_test.7z](https://b3logfile.com/file/2021/05/ZArchiverPro_0_9_4_armeabi-v7a_test-71858dbb.7z)
[ZArchiverPro0.9.4_x86_test.7z](https://b3logfile.com/file/2021/05/ZArchiverPro_0_9_4_x86_test-7f7621cd.7z)

