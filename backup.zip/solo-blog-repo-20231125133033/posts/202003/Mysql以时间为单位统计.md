title: Mysql以时间为单位统计
date: '2020-03-21 15:16:57'
updated: '2020-03-21 15:16:57'
tags: [开发小记, Mysql]
permalink: /articles/2020/03/21/1584775016978.html
---
# Mysql以时间为单位统计

## 按年统计

```
SELECT
    count(*) countNum,
    YEAR(log_time) log_year
FROM
    face_log
GROUP BY
    YEAR(log_time)
ORDER BY
    YEAR(log_time) DESC;
```

## 按季度统计
```
SELECT
    count(*) countNum,
    QUARTER(log_time) log_time
FROM
    face_log
GROUP BY
    QUARTER(log_time)
ORDER BY
    QUARTER(log_time) DESC;
```

## 按月统计
```
SELECT
    count(*) countNum,
    MONTH(log_time) log_time
FROM
    face_log
GROUP BY
    MONTH(log_time)
ORDER BY
    MONTH(log_time) DESC;
```


## 按周统计
```
SELECT
    count(*) countNum,
    WEEK(log_time) log_time
FROM
    face_log
GROUP BY
    WEEK(log_time)
ORDER BY
    WEEK(log_time) DESC;
```


## 按天统计
```
SELECT
    count(*) countNum,
    DATE(log_time) log_time
FROM
    face_log
GROUP BY
    DATE(log_time)
ORDER BY
    DATE(log_time) DESC;
```

## 统计七天内数据

```
SELECT
count(*)
FROM
face_log
WHERE
DATE(log_time) > DATE_SUB(CURDATE(), INTERVAL 7 DAY);
```

## 统计七天前数据

```
SELECT
count(*)
FROM
face_log
WHERE
DATE(log_time) < DATE_SUB(CURDATE(), INTERVAL 7 DAY);
```

## 统计7个小时之前的数据

```
select * from face_log WHERE
        log_time< DATE_SUB(NOW(), INTERVAL 7 HOUR)
```
