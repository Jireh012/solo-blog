title: Maven打包时报错：程序包sun.java2d.cmm不存在
date: '2021-06-23 11:06:10'
updated: '2021-06-23 11:06:10'
tags: [Maven]
permalink: /articles/2021/06/23/1624417570714.html
---
Maven打包时报错：程序包sun.java2d.cmm不存在

### 解决方法（亲测有效）

再**pom**文件中的**build—plugins**下加入如下配置

```
<plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.1</version>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                    <encoding>UTF-8</encoding>
                    <compilerArgs>
                        <arg>-XDignore.symbol.file</arg>
                    </compilerArgs>
                    <fork>true</fork>
                </configuration>
            </plugin>
```
