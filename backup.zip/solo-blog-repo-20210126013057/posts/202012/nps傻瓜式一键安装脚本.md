title: nps傻瓜式一键安装脚本
date: '2020-12-16 14:00:00'
updated: '2020-12-16 14:16:29'
tags: [nps]
permalink: /articles/2020/12/16/1608098400665.html
---
## 简介

NPS 是一款轻量级、高性能、功能强大的**内网穿透**代理服务器。目前支持 **tcp、udp 流量转发**，可支持任何 **tcp、udp **上层协议（访问内网网站、本地支付接口调试、ssh 访问、远程桌面，内网dns解析等等……），此外还**支持内网 http 代理、内网 socks5 代理**、**p2p 等**，并带有功能强大的 web 管理端。

一键脚本:

```
bash <(curl -L -s https://opt.cn2qq.com/opt-script/nps.sh)
```

![image.png](https://b3logfile.com/file/2020/12/image-c5a4c855.png)

