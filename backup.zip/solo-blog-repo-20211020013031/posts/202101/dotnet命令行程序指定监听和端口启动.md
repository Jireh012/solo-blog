title: dotnet命令行程序指定监听和端口启动
date: '2021-01-27 11:24:14'
updated: '2021-01-27 11:24:14'
tags: [dotnet]
permalink: /articles/2021/01/27/1611717854384.html
---
服务器上需要一个远程执行cmd命令的工具，所以找到了以下的这个工具**WindowsRemoteCommandRunner**，它可以同web页面或者http请求，执行你所输入的命令。

项目地址：https://github.com/kejsardamberg/WindowsRemoteCommandRunner

但是这个应用默认只能通过localhost:5000来访问，像192.168.1.100这类的局域网IP就不能访问，所以就需要修改应用的监听地址。

启动的时候通过,以下命令来访问。

```
dotnet WindowsRemoteCommandRunner.dll urls http://*:5000
```

