title: Mybatis实现一对多的关联查询
date: '2020-03-30 11:26:13'
updated: '2020-03-30 11:26:13'
tags: [开发小记, Java, Mybatis]
permalink: /articles/2020/03/30/1585538773595.html
---
# Mybatis实现一对多的关联查询


## JavaVo视图类

添加所关联的实体列表到视图类中，在Mapper 接口中也返回 视图类 { 我这里是人员关联多张人脸数据 }

**private List< Face > faceList;**


```Java
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "PersonVO对象", description = "人员表")
public class PersonVO extends Person {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "人脸列表")
	private List<Face> faceList;

	@ApiModelProperty(value = "开始时间")
	private String createTime_gt;

	@ApiModelProperty(value = "结束时间")
	private String createTime_lt;

}
```

## Mapper
在resultMap中使用*collection*标签定义关联的集合类型的属性封装规则

```
    <!-- 通用查询映射结果 -->
    <resultMap id="personResultMap" type="org.project.fr.vo.PersonVO">
        <result column="id" property="id"/>
        <result column="create_user" property="createUser"/>
        <result column="create_dept" property="createDept"/>
        <result column="create_time" property="createTime"/>
        <result column="update_user" property="updateUser"/>
        <result column="update_time" property="updateTime"/>
        <result column="status" property="status"/>
        <result column="is_deleted" property="isDeleted"/>
        <result column="guid" property="guid"/>
        <result column="app_id" property="appId"/>
        <result column="name" property="name"/>
        <result column="phone" property="phone"/>
        <result column="id_card_no" property="idCardNo"/>
        <result column="card_no" property="cardNo"/>
        <result column="tag" property="tag"/>
        <result column="face_show_url" property="faceShowUrl"/>
        <result column="facial_url" property="facialUrl"/>
        <collection property="faceList" column="guid" select="selectFaceListByGuid"/>
    </resultMap>

    <select id="selectPersonPage" resultMap="personResultMap">
        select *
        from fr_person p
        where p.is_deleted = 0
        <if test="person.name!= null and person.name != ''">
            and
            p.name LIKE CONCAT(CONCAT('%', #{person.name}),'%')
        </if>
        <if test="person.phone!= null and person.phone != ''">
            and
            p.phone LIKE CONCAT(CONCAT('%', #{person.phone}),'%')
        </if>
        <if test="person.cardNo!= null and person.cardNo != ''">
            and
            p.card_no = #{person.cardNo}
        </if>
        <if test="person.tag!= null and person.tag != ''">
            and
            p.tag LIKE CONCAT(CONCAT('%', #{person.tag}),'%')
        </if>
        <if test="person.idCardNo!= null and person.idCardNo != ''">
            and
            p.id_card_no = #{person.idCardNo}
        </if>
        <if test="person.createTime_gt != null and person.createTime_gt != ''">
            and
            p.create_time >= #{person.createTime_gt}
        </if>
        <if test="person.createTime_lt != null and person.createTime_lt != ''">
            and
            #{person.createTime_lt} >= p.create_time
        </if>
        order by p.create_time DESC
    </select>

    <select id="selectFaceListByGuid" resultType="org.project.fr.entity.Face">
        SELECT *
        FROM fr_face
        WHERE is_deleted = 0
          and person_guid = #{guid}
    </select>
```

