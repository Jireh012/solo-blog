title: Linux BT 宝塔面板开心版 [一键脚本]
date: '2020-04-14 14:40:49'
updated: '2020-07-21 09:34:44'
tags: [Linux]
permalink: /articles/2020/04/14/1586846449806.html
---
# Linux BT 宝塔面板开心版 [一键脚本]

### 安装要求

内存：512M以上，推荐768M以上（纯面板约占系统60M内存）
硬盘：100M以上可用硬盘空间（纯面板约占20M磁盘空间）
系统：CentOS 7.1+ (Ubuntu16.04+.、Debian9.0+)，确保是干净的操作系统，没有安装过其它环境带的Apache/Nginx/php/MySQL（已有环境不可安装）

### **宝塔面板 开心版 安装命令**

**Centos安装命令：**

```
yum install -y wget && wget -O install.sh https://download.ccspump.com/ltd/install/install_6.0.sh && sh install.sh
```

**试验性Centos/Ubuntu/Debian安装命令支持ipv6，注意使用root权限执行此命令 (支持Centos8)**

```
curl -sSO https://download.ccspump.com/ltd/install/new_install.sh && bash new_install.sh
```

**Ubuntu/Deepin安装命令：**

```
wget -O install.sh https://download.ccspump.com/ltd/install/install-ubuntu_6.0.sh && sudo bash install.sh
```

**Debian安装命令：**

```
wget -O install.sh https://download.ccspump.com/ltd/install/install-ubuntu_6.0.sh && bash install.sh
```

**Fedora安装命令：**

```
wget -O install.sh https://download.ccspump.com/ltd/install/install_6.0.sh && bash install.sh
```

**Linux面板7.1.1升级命令：**

```
curl https://download.ccspump.com/ltd/install/update6.sh|bash
```

### **插件相关脚本**

**收费Nginx防火墙（面板先安装在执行脚本）：**

```
wget -O btwaf.sh https://download.ccspump.com/install/btwaf.sh && bash btwaf.sh install
```

**免费Nginx防火墙（无需面板安装）：**

```
wget -O free_btwaf.sh https://download.ccspump.com/ltd/install/free_btwaf.sh && bash free_btwaf.sh install
```

**收费Apache防火墙（面板先安装在执行脚本）：**

```
wget -O btwaf_httpd.sh https://download.ccspump.com/ltd/install/btwaf_httpd.sh && bash btwaf_httpd.sh install
```

**主机异常登录插件脚本**

```
wget -O host_login.sh https://download.ccspump.com/ltd/install/host_login.sh && bash host_login.sh install
```

**河马webshell查杀插件脚本**

```
wget -O hm_shell_san.sh https://download.ccspump.com/ltd/install/hm_shell_san.sh && bash hm_shell_san.sh install
```

**一键安装第三方插件脚本**

```
wget -O plugin3.sh https://52bt.cn/install/plugin3.sh &amp;&amp; bash plugin3.sh
```

### **修复工具**

**解除拉黑、解锁文件脚本：**

```
wget -O waf.sh https://download.ccspump.com/ltd/install/waf.sh && bash waf.sh
```

