title: Docker下部署SqlServer2019
date: '2021-02-05 11:24:50'
updated: '2021-02-05 11:24:50'
tags: [Docker, SqlServer]
permalink: /articles/2021/02/05/1612495490738.html
---
```
#拉取sqlserver2019镜像
docker pull mcr.microsoft.com/mssql/server:2019-latest
#创建主机映射目录
mkdir -p /docker_volume/mssql
#修改主机映射目录权限
chown -R 10001:0 /docker_volume/mssql
#否则会报以下错误
# /opt/mssql/bin/sqlservr: Error: Directory /var/opt/mssql/system/] could not be created.  Errno [13]
docker run --name mssql \
    --net=host \
    -e 'ACCEPT_EULA=Y' \
    -e 'MSSQL_PID=<产品序列号>' \
    -e 'SA_PASSWORD=<SA密码>' \
    -v /docker_volume/mssql:/var/opt/mssql \
    -d mcr.microsoft.com/mssql/server:2019-latest
```

