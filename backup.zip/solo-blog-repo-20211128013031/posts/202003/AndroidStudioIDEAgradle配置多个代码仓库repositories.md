title: (AndroidStudio|IDEA)gradle配置多个代码仓库repositories
date: '2020-03-10 10:03:27'
updated: '2020-03-10 10:03:27'
tags: [Android, 开发小记]
permalink: /articles/2020/03/10/1583805807200.html
---
推荐一批 Android Maven 仓库地址

<pre class="EnlighterJSRAW" data-enlighter-language="xml" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">repositories {  
    mavenCentral()  
    maven { url &#34;https://jitpack.io&#34; }  
    maven { url &#34;http://maven.aliyun.com/nexus/content/groups/public/&#34; }  
    maven { url &#39;http://maven.oschina.net/content/groups/public/&#39; }   
    maven { url &#39;https://oss.sonatype.org/content/repositories/snapshots/&#39; }   
    maven { url &#34;http://maven.springframework.org/release&#34; }   
    maven { url &#34;http://maven.restlet.org&#34; }   
    maven { url &#34;http://mirrors.ibiblio.org/maven2&#34; }  
    maven { url &#34;http://repo.baichuan-android.taobao.com/content/groups/BaichuanRepositories/&#34;  }  
    maven { url &#39;https://maven.fabric.io/public&#39; }  
    jcenter()  
    google()  
}</pre>
