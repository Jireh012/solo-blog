title: 将本地Maven仓库上传到私服或阿里云效
date: '2020-12-15 17:56:34'
updated: '2020-12-15 17:56:34'
tags: [Maven]
permalink: /articles/2020/12/15/1608026194112.html
---
## migrate-local-repo-tool上传工具

下载地址：[migratelocalrepotool.zip](https://b3logfile.com/file/2020/12/migratelocalrepotool-5be983f2.zip)

## 使用说明

进入powershell、cmd或ssh,cd定位到**migrate-local-repo-tool.jar**所在路径

```
java -jar migrate-local-repo-tool.jar -cd "E:\Develop\environment\maven\repository" -t "http://nexus_address/repository/releases/" -u admin -p 123456
```

### 启动参数:

> -cd   需要上传的本地仓库目录
> -t    目标仓库地址（可以是自建的nexus地址或者阿里云效地址）
> -u    用户名
> -p    密码

