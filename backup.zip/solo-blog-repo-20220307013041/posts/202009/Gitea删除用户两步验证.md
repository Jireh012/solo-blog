title: Gitea删除用户两步验证
date: '2020-09-18 15:16:08'
updated: '2020-09-18 15:24:28'
tags: [Gitea]
permalink: /articles/2020/09/18/1600413368833.html
---
![](https://b3logfile.com/bing/20200204.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Gitea删除用户两步验证

Gitea账户开启了两步验证，手机上身份验证器的数据丢失了,也没有存储恢复密钥，导致无法登录。

<div style="text-align: center;">

![image.png](https://b3logfile.com/file/2020/09/image-02b09e23.png)

</div>

## 解决方法

**进入数据库，在`user`表中查询你要删除两步验证用户的`uid`，在到`two_factor`这张表中删除这条`uid`的记录就可以了。再次登录你就会发现，两步验证已经没有了。**

## SQL

```sql
DELETE
FROM
	two_factor 
WHERE
	uid =(
	SELECT
		uid 
	FROM
		`user` 
	WHERE
	NAME = 'you_username' 
	)
```

### Tip

1. **操作数据库之前记得备份下**
2. **Gitea其实是Gogs的兄弟版本，所有Gogs中遇到这样的情况，可以按相同步骤进行处理**

