title: TeslaMate+宝塔Nginx反代配置
date: '2022-03-31 10:05:44'
updated: '2022-03-31 10:05:44'
tags: [Tesla, TeslaMate]
permalink: /articles/2022/03/31/1648692344568.html
---
关于安装的部份这里就不在做阐述了，详细的操作步骤可以参考https://zhuanlan.zhihu.com/p/437404623 这里的安装指南。

---

以下为关于Nginx反代的配置，默认的配置会导致websocket访问错误，页面无法正常加载

![image.png](https://b3logfile.com/file/2022/03/image-dfe61fe7.png)

在站点的配置中添加

```
map $http_upgrade $connection_upgrade { 
	default upgrade; 
	'' close; 
}
```

![image.png](https://b3logfile.com/file/2022/03/image-c984fbc5.png)

在反向代理配置中添加

```
location ^~ /
{
    proxy_pass https://127.0.0.1:12443;
    proxy_http_version 1.1;
	proxy_redirect off; 
	proxy_set_header Host $host; 
	proxy_set_header X-Real-IP $remote_addr; 
	proxy_read_timeout 3600s; 
	proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; 
	proxy_set_header Upgrade $http_upgrade; 
	proxy_set_header Connection $connection_upgrade; 
}
```

