title: HTC VIVE房产项目实战教程【完结】
date: '2020-03-09 20:41:14'
updated: '2020-03-09 21:08:18'
tags: [HTCVIVE, Vr, 实战, 房产]
permalink: /articles/2020/03/09/1583757673920.html
---
# HTC VIVE 房产项目实战教程

本教程价值 149RMB，如果觉得可以。可以给帅帅的站主一点 赞助哈。

### **资源汇总在这里** 链接：[http://pan.baidu.com/s/1o8dDoaY](http://pan.baidu.com/s/1o8dDoaY) 密码：57bj

S-视觉艺术用光.pdf  [http://pan.baidu.com/s/1qXLraEC](http://pan.baidu.com/s/1qXLraEC)

**课时六**

资源下载：链接：[http://pan.baidu.com/s/1gfjVUfT](http://pan.baidu.com/s/1gfjVUfT) 密码：rj7d

Substance Designer 4 Get Started 官方教学视频

Substance Designer 制作地砖材质.pdf

素材材质资源
Substance Designer 制作地砖材质 – HTC VIVE 房产项目实战教程

**课时七**

资源下载：链接：[http://pan.baidu.com/s/1o8PFdFG ](http://pan.baidu.com/s/1o8PFdFG) 密码：32ny
Substance Painter 制作椅子材质 – HTC VIVE 房产项目实战教程

**课时八 **(彩蛋)分享国外 Blender+Substance Painter 制作 Pok émon GO 道具一例（Timelapse）

**课时九**

资源下载：链接：[http://pan.baidu.com/s/1kVeyaN1](http://pan.baidu.com/s/1kVeyaN1) 密码：ck4i
光照系统（Enlighten）介绍 – HTC VIVE 房产项目实战教程

**课时十**

Lighting 参数讲解 – HTC VIVE 房产项目实战教程

**课时十一**

资源下载：链接：[http://pan.baidu.com/s/1jIbcsaq](http://pan.baidu.com/s/1jIbcsaq) 密码：zyw5
Light Probe 组件 – HTC VIVE 房产项目实战教程

**课时十二**

资源下载：链接：[http://pan.baidu.com/s/1jH8CbMe](http://pan.baidu.com/s/1jH8CbMe) 密码：5gmj
Reflection Probe 组件 – HTC VIVE 房产项目实战教程

课时十二资源下载：链接：[http://pan.baidu.com/s/1mijfHSc](http://pan.baidu.com/s/1dE0EIEd) 密码：sqfb

**课时十四**

HTC Vive 开发环境部署 – HTC VIVE 房产项目实战教程

课时十三资源下载：链接：[http://pan.baidu.com/s/1cbtKzO](http://pan.baidu.com/s/1cbtKzO) 密码：375j

**课时十五** Vive 手柄控制器输入(抓取物体实例)

**课时十六** Vive Teleport 功能

**课时十七** The Lab Renderer 渲染器

**课时十八** UGUI 概览

**课时十九**在 VR 中使用 UGUI 及案例分析

课时十九资源下载：链接：[http://pan.baidu.com/s/1bpIBhpX ](http://pan.baidu.com/s/1bpIBhpX) 密码：7wrl

**课时二十** Vive 射线选择功能

**课时二十一**实战开发——日夜循环

课时二十一资源下载：链接：[http://pan.baidu.com/s/1eSCzw3K](http://pan.baidu.com/s/1eSCzw3K) 密码：phis

**课时二十二**实战开发——欢迎页面 UI 及列表开发

**课时二十三**实战开发——手柄菜单开发

**课时二十四**实战开发——手柄震动、环形菜单、材质切换

**课时二十五** VR 脚本调试与优化

**课时二十六**总结
