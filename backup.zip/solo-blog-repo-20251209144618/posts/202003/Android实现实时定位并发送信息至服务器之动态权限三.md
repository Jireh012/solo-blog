title: Android实现实时定位并发送信息至服务器之动态权限（三）
date: '2020-03-10 09:53:29'
updated: '2020-03-10 09:53:29'
tags: [开发小记, Android]
permalink: /articles/2020/03/10/1583805209640.html
---
这篇讲下权限的动态申请，在 Android6.0 以后权限机制分为两类，Normal Permissions，这类权限是不需要用户授权，不会触及用户的隐私，只需要在 manefest 里面申请即可；还有一类是 Dangerous Permissions，即动态申请。

实现的方式也有很多，普通的或者更多的封装第三方库。

**权限申请的流程**

1.在 AndroidManifest 里面配置需要的权限，无论是普通的还是特殊的权限都需要在这里配置。

2.检查权限，如果没有权限则申请

3.给用户申请权限的解释，这个方法只会在第一次用户拒绝授权，再次去申请这个的权限时会用到

4.申请相应的权限

5.处理申请权限的回调，在这里获得哪些授权成功哪些失败，处理需要的逻辑

普通的方式[申请电话权限]

<pre class="EnlighterJSRAW" data-enlighter-language="java" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">public class Main2Activity extends AppCompatActivity {  
  
    @Override  
    protected void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.activity_main2);  
  
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)  
                != PackageManager.PERMISSION_GRANTED) {//未获取权限  
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CALL_PHONE)) {  
                //当用户第一次申请拒绝时，再次申请该权限调用  
                Toast.makeText(this, &#34;拨打电话权限&#34;, Toast.LENGTH_SHORT).show();  
            }  
            //申请权限  
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 0x01);  
        } else {//已经获得了权限  
            call();  
        }  
    }  
  
    private void call() {  
        Toast.makeText(this, &#34;打电话&#34;, Toast.LENGTH_SHORT).show();  
    }  
  
    @Override  
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {  
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);  
        if (requestCode == 0x01) {  
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {//授权成功  
                call();  
            } else {//授权失败  
                Toast.makeText(this, &#34;获取权限失败&#34;, Toast.LENGTH_SHORT).show();  
            }  
        }  
    }  
}</pre>

封装的第三方库，这里我用的是 **EasyPermissions**，调用也非常的方便

<pre class="EnlighterJSRAW" data-enlighter-language="java" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">compile &#39;pub.devrel:easypermissions:0.1.5&#39;</pre>

在 Activite 中调用

<pre class="EnlighterJSRAW" data-enlighter-language="java" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">public class MainActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks {  
  
    private static final String TAG = &#34;lzy&#34;;  
  
    @Override  
    protected void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.activity_main);  
        //所要申请的权限  
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CALL_PHONE};  
          
        if (EasyPermissions.hasPermissions(this, perms)) {//检查是否获取该权限  
            Log.i(TAG, &#34;已获取权限&#34;);  
        } else {  
            //第二个参数是被拒绝后再次申请该权限的解释  
            //第三个参数是请求码  
            //第四个参数是要申请的权限  
            EasyPermissions.requestPermissions(this, &#34;必要的权限&#34;, 0, perms);  
        }  
    }  
  
    @Override  
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {  
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);  
        //把申请权限的回调交由EasyPermissions处理  
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);  
    }  
  
    //下面两个方法是实现EasyPermissions的EasyPermissions.PermissionCallbacks接口  
    //分别返回授权成功和失败的权限  
    @Override  
    public void onPermissionsGranted(int requestCode, List&lt;String&gt; perms) {  
        Log.i(TAG, &#34;获取成功的权限&#34; + perms);  
    }  
  
    @Override  
    public void onPermissionsDenied(int requestCode, List&lt;String&gt; perms) {  
        Log.i(TAG, &#34;获取失败的权限&#34; + perms);  
    }  
}</pre>
