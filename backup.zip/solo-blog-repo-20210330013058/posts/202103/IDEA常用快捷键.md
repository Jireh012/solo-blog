title: IDEA常用快捷键
date: '2021-03-29 10:31:58'
updated: '2021-03-29 10:31:58'
tags: [idea, 转载]
permalink: /articles/2021/03/29/1616985117918.html
---
<div id="article_content" class="article_content clearfix">
        <link rel="stylesheet" href="https://csdnimg.cn/release/blogv2/dist/mdeditor/css/editerView/ck_htmledit_views-b5506197d8.css">
                <div id="content_views" class="markdown_views prism-tomorrow-night">
                    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                        <path stroke-linecap="round" d="M5,0 0,2.5 5,5z" id="raphael-marker-block" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                    </svg>
                    <p>IDEA 一款非常优秀的开发工具，本篇博客总结一些在 IDEA 中常用的快捷键，旨在提高开发效率，如果你想修改默认的快捷键，可以看我的这篇博客 <a href="https://blog.csdn.net/qq_42351033/article/details/107597707">IDEA 如何修改、移除快捷键</a> 。</p> 
<p>下面的 “关键字” 指的是在快捷键搜索框中输入的内容，演示语言为 Dart，当然其它语言同样适用。</p> 
<p id="aa"><font color="black" size="4"><strong>【1】 关键字：Rename... 、 快捷键：Shift + F6 </strong></font></p> 
<p>作用：可以重命名文件夹、文件、方法等，以重命名方法为例<br> <img src="https://img-blog.csdnimg.cn/20200726210914981.gif" alt="在这里插入图片描述"></p> 
<p id="bb"><font color="black" size="4"><strong>【2】 关键字：Show Context Actions 、 快捷键：Alt + Enter</strong></font></p> 
<p>作用：可以说是"万能键"，可以自动修复错误，如包的引入，补齐 override 等。以快速完成构造函数为例<img src="https://img-blog.csdnimg.cn/2020072621301654.gif" alt="在这里插入图片描述"></p> 
<p id="cc"><font color="black" size="4"><strong>【3】 关键字：Extend Selection 、 快捷键：Ctrl + W</strong></font></p> 
<p>作用：递进式选择代码块。可选中光标所在的单词或段落，连续按会在原有选中的基础上再扩展选中范围。<br> <img src="https://img-blog.csdnimg.cn/20200726214703783.gif" alt="在这里插入图片描述"><br> 这个也是我平常很喜欢的功能键，尤其是对于 Flutter 这种嵌套比较深的，选择最外层组件的时候，再也不用担心少选择或者多选择一个括号的问题了。</p> 
<p id="dd"><font color="black" size="4"><strong>【4】 关键字：Next Highlighted Error 、 快捷键： F2</strong></font></p> 
<p>作用：快速定位下一个错误。<br> <img src="https://img-blog.csdnimg.cn/20200727231949103.gif" alt="在这里插入图片描述"></p> 
<p>定位错误的时候，即使装了 CodeGlance 插件方便拖动到错误位置处，但有了这个快捷键之后，不需要拖动就可以快速定位某个错误了。如果有多个错误，修复一个错误后直接按 F2 就可以修改下一个错误了，很方便的有没有？</p> 
<p>与之相应的是快速定位到上一个错误，关键字：Previous Highlighted Error、 快捷键： Shift + F2，这里不再演示。</p> 
<p id="ee"><font color="black" size="4"><strong>【5】 关键字：Find Usages 、 快捷键：Alt + F7 </strong></font></p> 
<p>作用：查找引用，这里以某一方法在哪里引用了为例。<br> <img src="https://img-blog.csdnimg.cn/20200726231136151.gif" alt="在这里插入图片描述"></p> 
<p id="ff"><font color="black" size="4"><strong>【6】 关键字：Go to Declaration or Usages 、 快捷键：Ctrl + B、Ctrl +鼠标左键</strong></font></p> 
<p>作用：跳到声明（定义）或者引用。<br> <img src="https://img-blog.csdnimg.cn/20200726231707590.gif" alt="在这里插入图片描述"></p> 
<p id="gg"><font color="black" size="4"><strong>【7】 关键字：Reformat Code with dartfmt 、 快捷键： 无</strong></font></p> 
<p>作用：格式化代码。<br> <img src="https://img-blog.csdnimg.cn/20200726232135916.gif" alt="在这里插入图片描述"></p> 
<p id="hh"><font color="black" size="4"><strong>【8】 关键字：Go to Line/Column 、 快捷键：Ctrl + G</strong></font></p> 
<p>作用：定位到某一行。<br> <img src="https://img-blog.csdnimg.cn/20200726233840707.gif" alt="在这里插入图片描述"></p> 
<p id="ii"><font color="black" size="4"><strong>【9】 关键字：Find 、 快捷键：Ctrl + F </strong></font></p> 
<p>作用：搜索当前文件中的指定内容。<br> <img src="https://img-blog.csdnimg.cn/20200726234345711.gif" alt="在这里插入图片描述"><br> 如果你在搜索单词时希望区分大小写，可以点击 Aa 按钮。</p> 
<p id="jj"><font color="black" size="4"><strong>【10】 关键字：Find in Path 、 快捷键：Ctrl + Shift + F</strong></font></p> 
<p>作用：全局搜索。<br> <img src="https://img-blog.csdnimg.cn/20200726234937154.gif" alt="在这里插入图片描述"></p> 
<p id="kk"><font color="black" size="4"><strong>【11】 快捷键：Shift + Shift</strong></font></p> 
<p>作用：综合搜索，可以搜索所有文件、根据类型搜索、搜索文件、模糊搜索。<br> <img src="https://img-blog.csdnimg.cn/20200728215828177.gif" alt="在这里插入图片描述"></p> 
<p id="ll"><font color="black" size="4"><strong>【12】 关键字：Recent Files 、 快捷键：Ctrl + E</strong></font></p> 
<p>作用：显示最近编辑的文件列表。<br> <img src="https://img-blog.csdnimg.cn/20200726235303760.gif" alt="在这里插入图片描述"><br> 可点击文件，跳转到该文件，还是很方便的。</p> 
<p id="mm"><font color="black" size="4"><strong>【13】 关键字：Surround With... 、 快捷键：Ctrl + Alt +T</strong></font></p> 
<p>作用：将代码包在一块内，如 try…catch、if else 等。<br> <img src="https://img-blog.csdnimg.cn/20200727000119946.gif" alt="在这里插入图片描述"><br> 选中需要加进块内的代码，按快捷键 Ctrl + Alt +T 即可。</p> 
<p id="nn"><font color="black" size="4"><strong>【14】 关键字：File Path 、 快捷键：Ctrl + Alt + F12 </strong></font></p> 
<p>作用：文件路径。<br> <img src="https://img-blog.csdnimg.cn/2020072700073146.gif" alt="在这里插入图片描述"></p> 
<p id="oo"><font color="black" size="4"><strong>【15】 关键字：File Structure 、 快捷键：Ctrl + F12</strong></font></p> 
<p>作用：显示当前文件结构。<br> <img src="https://img-blog.csdnimg.cn/20200727001100483.gif" alt="在这里插入图片描述"><br> 该功能可以把你当前文件的结构（有哪些类、类中有哪些属性、方法等信息给列举出来），个人日常使用。</p> 
<p id="pp"><font color="black" size="4"><strong>【16】 关键字：Back 、 快捷键：Ctrl + Alt + ← </strong></font></p> 
<p>作用：跳回上一个操作。<br> <img src="https://img-blog.csdnimg.cn/20200728220439584.gif" alt="在这里插入图片描述"><br> 示例中先跳到定义 china 方法的位置，然后按快捷键跳回跳到定义 china 方法前的那一步，这个很实用，可以省下不少时间。</p> 
<p>与之相对应的是 关键字：Forward、快捷键：Ctrl + Alt + →，作用是跳到下一个操作。</p> 
<p id="qq"><font color="black" size="4"><strong>【17】 关键字：Undo 、 快捷键：Ctrl + Z</strong></font></p> 
<p>作用：撤销修改。<br> <img src="https://img-blog.csdnimg.cn/20200728221133443.gif" alt="在这里插入图片描述"><br> Undo 操作可以撤销你的修改，如果你想反撤销，即还想要撤销前的内容，就要用到与 Undo 相反的功能 Redo 了，关键字：Redo、快捷键：Ctrl + Shift + Z。</p> 
<p id="rr"><font color="black" size="4"><strong>【18】 关键字：Replace 、 快捷键：Ctrl + R</strong></font></p> 
<p>作用：批量替换内容。<br> <img src="https://img-blog.csdnimg.cn/20200728222606772.gif" alt="在这里插入图片描述"></p> 
<p id="ss"><font color="black" size="4"><strong>【19】 关键字：Debug 、 快捷键：Shift + F9 </strong></font></p> 
<p>作用：开启 Debug 调试模式。<br> <img src="https://img-blog.csdnimg.cn/20200728223131766.gif" alt="在这里插入图片描述"><br> 工作一天用 Debug 调试还是比较多的，个人并不喜欢去找按钮然后点击按钮，用快捷键感觉舒服多了。关闭 Debug 调试模式的关键字：Stop、快捷键：Shift + F2。</p> 
<p id="tt"><font color="black" size="4"><strong>【20】 关键字： Clear All、 快捷键：无 </strong></font></p> 
<p>作用：清空控制台输出日志。<br> <img src="https://img-blog.csdnimg.cn/20200728223605246.gif" alt="在这里插入图片描述"><br> 如果每次清空控制台日志都是右键控制台，然后找到 Clear All 按钮，再去点，那就太麻烦了，还好有这个快捷键。</p> 
<p id="zz"><font color="black" size="4"><strong>【21】 关键字：with Mnemonic 快捷键：Ctrl + F11 </strong></font></p> 
<p>作用：使用助记符设定 / 取消书签，根据设置的书签值快速跳转到被标记的文件。<br> <img src="https://img-blog.csdnimg.cn/20200729005020660.gif" alt="在这里插入图片描述"><br> 设置好书签后，按 Ctrl + 你设置的数字 就可以跳转了，注意数字是主键盘区的，不是右侧数字键区的。</p> 
<p>你不仅可以对文件设置书签，也可以对文件夹设置书签，操作过程是一样的，这里就不再演示了。</p> 
<p>书签功能可谓实用性非常强了，当你在多个文件之间来回切换，或者某一个文件夹路径比较深时，书签功能就太香了。</p> 
<hr> 
<p>以下的效果演示图，是关于快速移动光标、快速选择文字的功能，前期用了一点时间记这些快捷键，但时间久了，就像你去打一个字一样，不会去想这个字的拼音是什么了，换回来的是减少了来回切换鼠标、键盘的频率，个人觉得还是很值得一用的。</p> 
<p id="uu"><font color="black" size="4"><strong>【22】 关键字：Down 、 Up、Left、Right</strong></font></p> 
<p>作用：上下左右移动光标。<img src="https://img-blog.csdnimg.cn/20200726232605398.gif" alt="在这里插入图片描述"><br> 按箭头移动光标的话，因为箭头距右手还是有点远的，所以我给改了键，如下表格。</p> 
<div class="table-box"><table><thead><tr><th>关键字</th><th>默认快捷键</th><th>自定义快捷键</th></tr></thead><tbody><tr><td>Up</td><td>上箭头 ↑</td><td>Alt + I</td></tr><tr><td>Down</td><td>下箭头 ↓</td><td>Alt + K</td></tr><tr><td>Left</td><td>左箭头 ←</td><td>Alt + J</td></tr><tr><td>Right</td><td>右箭头 →</td><td>Alt + L</td></tr></tbody></table></div>
<p>这样设置后，极大程度的减少了鼠标的使用次数，还是很爽的。这里的自定义快捷键是根据我个人习惯设置的，你可以改成让自己敲着舒服的快捷键。</p> 
<p id="vv"><font color="black" size="4"><strong>【23】 关键字： Move Caret to Line Start、Move Caret to Line End</strong></font></p> 
<p>作用：移动光标到行首、移动光标到行尾。分别对应快捷键 Home、End。<br> <img src="https://img-blog.csdnimg.cn/20200728225054922.gif" alt="在这里插入图片描述"><br> 一般我经常移动光标到行尾，然后按 Enter 键换行，还是很不错的。</p> 
<p id="ww"><font color="black" size="4"><strong>【24】 关键字：Move Caret to Line Start with Selection 、 Move Caret to Line End with Selection</strong></font></p> 
<p>作用：从光标处选中到行首、从光标处选中到行尾。分别对应快捷键 Shift + Home、Shift + End。<br> <img src="https://img-blog.csdnimg.cn/20200728225746201.gif" alt="在这里插入图片描述"><br> 一般选中内容后会剪切到其它地方，配合移动光标到行首或者行尾、然后再从光标处选中到行首或行尾，谁用谁香，当然，喜欢用鼠标的咱们也不互掐，哈哈。</p> 
<p id="xx"><font color="black" size="4"><strong>【25】 关键字： Move Caret to Previous Word、Move Caret to Next Word </strong></font></p> 
<p>作用：光标移动到上一个词汇、光标移动到下一个词汇。分别对应快捷键 Ctrl + ←、Ctrl + →。<br> <img src="https://img-blog.csdnimg.cn/20200728230454202.gif" alt="在这里插入图片描述"></p> 
<p id="yy"><font color="black" size="4"><strong>【26】 关键字：Up with Selection、Down with Selection、Left with Selection、Right with Selection</strong></font></p> 
<p>作用：上下左右移动光标并选中内容。分别对应快捷键 Shift + ↑、Shift + ↓、Shift + ←、Shift + →。<br> <img src="https://img-blog.csdnimg.cn/20200728230938244.gif" alt="在这里插入图片描述"></p> 
<p>上面的快捷键如果你掌握了，你很多时候都不需要用到鼠标去完成了，敲代码都能让你愉悦，哈哈。</p> 
<p>不过 IDEA 的快捷键远不止这些，下面是我整理的一些其它快捷键，方便回头查看。</p> 
<center>
 <h5>IDEA 快捷键</h5>
</center> 
<p>Ctrl+N ： 根据输入的"类名"查找类文件<br> Ctrl+Shift+E：显示最近更改的文件<br> Ctrl + O：选择可重写的方法<br> Ctrl + Home：跳到文件头<br> Ctrl + End：跳到文件尾<br> Ctrl + Alt + Space：类名自动完成<br> Ctrl + Shift + Backspace：退回到上次修改的地方<br> Ctrl + Shift + F12：编辑器最大化<br> Ctrl + J：插入自定义动态代码模板<br> Ctrl + /：注释光标所在行代码<br> Ctrl + F4 ：关闭当前编辑文件<br> Ctrl + F8：在 Debug 模式下，设置光标当前行为断点<br> Ctrl + Enter：智能分隔行<br> Ctrl + Shift + J：将下一行合并到当前行末尾<br> Ctrl + Shift + U：对选中的代码进行大 / 小写相互转换<br> Ctrl + Shift + T：对当前类生成单元测试类，如果已经存在的单元测试类则可以进行选择<br> Ctrl + Shift + +：展开所有代码<br> Ctrl + Shift + - ：折叠所有代码<br> Ctrl + Shift + F7 高亮显示所有该选中文本，按 Esc 取消高亮<br> Ctrl + Shift + Enter：自动结束代码，行末自动添加分号<br> Ctrl + Shift + 前方向键：光标放在方法名上，将方法移动到上一个方法前面<br> Ctrl + Shift + 后方向键：光标放在方法名上，将方法移动到下一个方法前面<br> Shift + F9：执行 Run 功能<br> Shift + F11：弹出书签显示层<br> Shift + Tab：取消缩进</p> 
<p>以上是我觉得会用上的，还有很多快捷键就不再整理了。每一个快捷键我都亲测了，大家放心使用。</p>

---

> 转自：https://blog.csdn.net/qq_42351033/article/details/107599118

