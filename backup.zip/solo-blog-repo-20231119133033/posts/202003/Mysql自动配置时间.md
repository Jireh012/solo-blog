title: Mysql自动配置时间
date: '2020-03-20 16:41:51'
updated: '2020-03-21 15:01:48'
tags: [开发小记]
permalink: /articles/2020/03/20/1584693710997.html
---
# Mysql自动配置时间

创建时间：在Navicat 字段默认值中配置 CURRENT_TIMESTAMP

更新时间：在Navicat 字段默认值中配置 CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
