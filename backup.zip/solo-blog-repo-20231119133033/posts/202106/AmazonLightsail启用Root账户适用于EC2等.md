title: Amazon Lightsail启用Root账户(适用于EC2等)
date: '2021-06-22 17:24:40'
updated: '2021-06-22 17:24:40'
tags: [aws]
permalink: /articles/2021/06/22/1624353880163.html
---
进入服务器shell，执行如下命令
**注意修改如下命令当中密码(password)**,为root密码

```
echo root:(password) |sudo chpasswd root
sudo sed -i 's/^.*PermitRootLogin.*/PermitRootLogin yes/g' /etc/ssh/sshd_config;
sudo sed -i 's/^.*PasswordAuthentication.*/PasswordAuthentication yes/g' /etc/ssh/sshd_config;
sudo reboot
```

