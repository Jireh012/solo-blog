title: Debian升级OpenSSH至最新版本
date: '2021-05-06 16:49:13'
updated: '2021-05-06 16:49:13'
tags: [Debian, OpenSSH]
permalink: /articles/2021/05/06/1620290953522.html
---
# Debian升级OpenSSH至最新版本

## 1.安装编译环境

```
apt install -y gcc g++ libssl-dev  build-essential libtool automake zlib*
```

## 2.下载安装包

可以先访问https://cdn.openbsd.org./pub/OpenBSD/OpenSSH/portable/ 查询最新版本

```
cd /tmp/
wget https://cdn.openbsd.org./pub/OpenBSD/OpenSSH/portable/openssh-8.6p1.tar.gz
```

## 3.配置安装环境

### 3.1配置sshd权限

修改/etc/passwd文件，在其中加入如下配置即可

```
sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin
```

### 3.2创建安装目录

```
mkdir /usr/local/ssh
```

## 4.编译安装

```
tar xvf openssh-8.6p1.tar.gz
cd openssh-8.6p1/
./configure --prefix=/usr/local/ssh --sysconfdir=/usr/local/ssh
make && make install
```

如果在 ./configure的时候出现如下错误提示

![image.png](https://b3logfile.com/file/2021/05/image-98d4d25a.png)

就使用如下命令来执行 ./configure，其他不变

```
./configure --prefix=/usr/local/ssh --sysconfdir=/usr/local/ssh --without-openssl-header-check
```

## 5.更新启动脚本

```
vim /lib/systemd/system/ssh.service
```

修改启动脚本当中sshd的路径 `/usr/sbin/sshd`为 `/usr/local/ssh/sbin/sshd`

```
[Unit]
Description=OpenBSD Secure Shell server
Documentation=man:sshd(8) man:sshd_config(5)
After=network.target auditd.service
ConditionPathExists=!/etc/ssh/sshd_not_to_be_run

[Service]
EnvironmentFile=-/etc/default/ssh
ExecStartPre=/usr/local/ssh/sbin/sshd -ti
ExecStart=/usr/local/ssh/sbin/sshd -D $SSHD_OPTS
ExecReload=/usr/local/ssh/sbin/sshd -t
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
Restart=on-failure
RestartPreventExitStatus=255
Type=notify
RuntimeDirectory=sshd
RuntimeDirectoryMode=0755

[Install]
WantedBy=multi-user.target
Alias=sshd.service
```

### 重载并重启sshd

```
systemctl daemon-reload
systemctl restart sshd.service
```

## 6.更新执行文件

```
cp /usr/local/ssh/bin/ssh /usr/bin/ssh
```

### 检查ssh版本

```
ssh -V
```

