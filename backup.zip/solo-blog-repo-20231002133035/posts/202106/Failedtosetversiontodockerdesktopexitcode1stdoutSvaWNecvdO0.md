title: !!binary |-
  RmFpbGVkIHRvIHNldCB2ZXJzaW9uIHRvIGRvY2tlci1kZXNrdG9wOiBleGl0IGNvZGU6IC0xICBzdGRvdXQ6IO+/vVMD77+977+9du+/vVth77+9e3zvv71XIE4vZQFjHVzVi++/vXbvv71kXE8CMA==
date: '2021-06-17 16:21:34'
updated: '2021-06-17 16:21:34'
tags: [Docker]
permalink: /articles/2021/06/17/1623918094777.html
---
Windows Docker Desktop 报错

```
Failed to set version to docker-desktop: exit code: -1  stdout: �S��v�[a�{|�W N/ec\Ջ�v�d\O0```
```

### 解决方法

用管理员启动 cmd,执行

```
netsh winsock reset
```

