title: Jenkins内存占用过大优化
date: '2021-07-30 15:45:32'
updated: '2021-07-30 15:45:32'
tags: [jenkins]
permalink: /articles/2021/07/30/1627631132270.html
---
![image.png](https://b3logfile.com/file/2021/07/image-c9f00c05.png)

Jenkins内存占用过高，居然跟mysql占用一样的高内存

### 解决方法

编辑  `**/etc/sysconfig/jenkins** 配置文件，找到 **JENKINS_JAVA_OPTIONS**这项配置

![image.png](https://b3logfile.com/file/2021/07/image-891ec503.png)

修改为

```
-Xms512m -Xmx1024m -XX:MaxNewSize=512m -XX:PermSize=256m -XX:MaxPermSize=512m -Djava.awt.headless=true
```

![image.png](https://b3logfile.com/file/2021/07/image-85f8dd6a.png)

最后在 ` service jenkins restart` 重启服务生效

---

我们看下优化后的内存占用

![image.png](https://b3logfile.com/file/2021/07/image-1b396ffe.png)

比优化前少占用一半左右的内存



