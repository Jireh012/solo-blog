title: Feign：Method has too many Body parameters
date: '2020-04-17 11:20:49'
updated: '2020-04-17 11:20:49'
tags: [开发小记]
permalink: /articles/2020/04/17/1587093649689.html
---
# Feign：Method has too many Body parameters

调用feign client的时候报了一个这个错误，发现因为用了`PostMapping`,然后在feign中有多个`@RequestBody`造成的。

---
feign中可以有多个@RequestParam，但只能有不超过一个@RequestBody。

