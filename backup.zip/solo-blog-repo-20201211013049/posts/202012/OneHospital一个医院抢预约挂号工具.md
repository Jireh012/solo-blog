title: OneHospital一个医院抢预约挂号工具
date: '2020-12-10 11:10:52'
updated: '2020-12-10 11:10:52'
tags: [开源]
permalink: /articles/2020/12/10/1607569851989.html
---
![image.png](https://b3logfile.com/file/2020/12/image-db7da5cf.png)

## 前言

最近肠胃不是特别好，有慢性胃炎+一丢丢的糜烂😑 ，估计跟小时候没按时吃饭也有点关系。老妈让我去约这个中医的医生看下，但是这家伙一直挂不到号（能挂到的都是150的名医馆专家门诊），受不了只能自己写个工具来帮自己去挂号了。

<center>
<img src="https://b3logfile.com/file/2020/12/image-5231fb49.png" width=300 />
</center><br/>

嗯？至于为什么起名叫OneHospital？简单啊，两个意思。*一个医院预约挂号工具*，*一医的预约挂号工具*

## 抓包

这个页面是在微信里面的，也做了限制不能在PC端打开。所以是在手机上安装**HttpCanary**这个工具来抓取http请求，因为ssl证书的原因，直接抓包是不行的。需要安装HTTPCanary的根证书，所以就需要另外一个工具**SysLock**，这个工具是用来解锁system目录的，因为HTTPCanary需要将根证书添加至系统，当然是用这两款工具都是需要Root手机的。

## 开发

程序是用Java开发的，采用Maven对包管理。自己封装了个HttpUtil方便post请求，如果token过期了，会再次请求授权接口重新获取授权，然后再次请求业务接口。然后加入Server酱通知功能，因为医院的通知偶尔会抽风。程序轮询执行，如果没有符合条件并没有预约成功的话，会自己休眠10秒，然后在开启一波的检测。

![image.png](https://b3logfile.com/file/2020/12/image-942f3c4b.png)


## 地址

Github：https://github.com/Jireh012/OneHospital

下载地址：https://github.com/Jireh012/OneHospital/releases/download/v1.0/1.0.7z

## 使用方法

根据自己的需求对example.properties进行修改

```
token=s4aw5d4SasdQwjeiqFdSalasdurugncmvaks.Auol-jdCF3mLeKxKx6fwoJNuh2BJjdwvFnCB25nEHa4
phone=13586132561
#门诊卡号
card=3315629-73555510
#医生Id
doctor-id=5340
#01老院 02新院
hospital-area=01
#费用
fee=30
ftqq-on=false
SCKEY=SCU107667Tea350es78cda451e713ef48f0b5f123df227585s6339d
```

配置完成后通过命令行启动，如下：

`java -jar .\OneHospital-1.0-SNAPSHOT.jar C:\Users\Administrator\Desktop\config.properties`

