title: 'Gitea迁移后，Push时报错remote: hooks/pre-receive问题'
date: '2020-06-29 17:12:29'
updated: '2020-06-29 17:12:29'
tags: [Gitea]
permalink: /articles/2020/06/29/1593421949680.html
---
# Gitea迁移后，Push时报错remote: hooks/pre-receive问题

Gitea迁移文件夹后，Push时报错remote: hooks/pre-receive

详细报错如下：
` remote: hooks/pre-receive: line 2: <path>: No such file or directory`

## 解决方法

###### 登陆Gitea管理面板 http://youdomain/admin 在维护操作中执行 

* [ ] 使用 Gitea SSH 密钥更新'.ssh/authorized_keys' 文件。
(内置的 SSH 服务器不需要。)
* [ ] 重新同步所有仓库的 pre-receive、update 和 post-receive 钩子

![image.png](https://b3logfile.com/file/2020/06/image-fb5635af.png)

