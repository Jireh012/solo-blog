title: Mac下清除SSH密钥缓存
date: '2020-03-10 09:56:00'
updated: '2020-03-10 09:56:00'
tags: [Shell]
permalink: /articles/2020/03/10/1583805360362.html
---
下午连 SSH 的时候发现连接不上了

<pre class="EnlighterJSRAW" data-enlighter-language="null" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">JirehdeMacBook-Pro:~ jireh$ ssh root@xxx.xxx.xxx.xxx
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@    WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!     @
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!
Someone could be eavesdropping on you right now (man-in-the-middle attack)!
It is also possible that a host key has just been changed.
The fingerprint for the ECDSA key sent by the remote host is
SHA256:6X749AzRgZtBAG2ftdGaf0BAhdpqZoRhnevPJhXR1z0.
Please contact your system administrator.
Add correct host key in /Users/jireh/.ssh/known_hosts to get rid of this message.
Offending ECDSA key in /Users/jireh/.ssh/known_hosts:2
ECDSA host key for xxx.xxx.xxx.xxx has changed and you have requested strict checking.
Host key verification failed.</pre>

想想可能是根据自己刚才，重装了系统导致，结果 SSH 使用旧密钥连接，但是服务器已经更新了所以连接不上。

查了下资料可以在终端中输入

ssh-keygen -R xxx.xxx.xxx.xxx    |  这里 xxx.xxx.xxx.xxx 就是你服务器的 IP 地址

这样就可以清除啦。
