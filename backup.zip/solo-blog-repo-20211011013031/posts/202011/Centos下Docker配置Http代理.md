title: Centos下Docker配置Http代理
date: '2020-11-02 17:02:45'
updated: '2020-11-02 17:23:46'
tags: [docker, Centos]
permalink: /articles/2020/11/02/1604307765651.html
---
# Centos下Docker配置Http代理

> 其他系统版本同理

### 创建文件夹以及配置文件

```
mkdir -p /etc/systemd/system/docker.service.d
vim /etc/systemd/system/docker.service.d/http-proxy.conf
```

### 配置文件内容

```
[Service]
Environment="HTTP_PROXY=http://10.10.10.100:808" "HTTPS_PROXY=http://10.10.10.100:808"
```

#### 可选配置

**不代理的地址：**`"NO_PROXY=localhost,127.0.0.1,docker-registry.lyile.cn" `

完整配置如下：

```
[Service]
Environment="HTTP_PROXY=http://10.10.10.100:808" "HTTPS_PROXY=http://10.10.10.100:808" "NO_PROXY=localhost,127.0.0.1,docker-registry.lyile.cn"
```

### 重启Docker

配置完成后需要重启Docker服务才会生效

`systemctl daemon-reload && systemctl restart docker `

