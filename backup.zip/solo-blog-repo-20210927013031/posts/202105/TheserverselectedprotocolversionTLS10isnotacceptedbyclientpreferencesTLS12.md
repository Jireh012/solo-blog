title: The server selected protocol version TLS10 is not accepted by client preferences
  [TLS12]
date: '2021-05-13 16:54:23'
updated: '2021-05-13 16:54:23'
tags: [Java, JDK]
permalink: /articles/2021/05/13/1620896063074.html
---
升级了下JDK版本到**jdk1.8.0_291**后，程序执行在连接数据库的时候报错

```
The server selected protocol version TLS10 is not accepted by client preferences [TLS12]
```

上谷歌查了下，因为新版的JDK不推荐使用旧的TLSV1.0的协议，所以默认删除TLS10的支持

## 解决方法

根据环境变量配置中jre的地址，在 **jre\lib\security**文件夹下，编辑**java.security**文件
在文件中找到 **jdk.tls.disabledAlgorithms**配置项，将**TLSv1, TLSv1.1, 3DES_EDE_CBC**删除即可。

```
#after
jdk.tls.disabledAlgorithms=SSLv3,RC4, DES, MD5withRSA, \
    DH keySize < 1024, EC keySize < 224, anon, NULL, \
    include jdk.disabled.namedCurves

#before	
#jdk.tls.disabledAlgorithms=SSLv3, TLSv1, TLSv1.1, RC4, DES, MD5withRSA, \
#    DH keySize < 1024, EC keySize < 224, 3DES_EDE_CBC, anon, NULL, \
#    include jdk.disabled.namedCurves
```

