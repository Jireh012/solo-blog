title: AspNetZero官方代码生成器破解版5.0
date: '2020-03-19 14:17:52'
updated: '2020-03-19 14:18:05'
tags: [工具]
permalink: /articles/2020/03/19/1584598672047.html
---
[AspNetZeroRadToolVisualStudioExtension.7z](https://img.hacpai.com/file/2020/03/AspNetZeroRadToolVisualStudioExtension-4cb74361.7z)

注意需配合关闭组件自动更新使用
