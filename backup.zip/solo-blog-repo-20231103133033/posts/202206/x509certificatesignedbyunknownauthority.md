title: 'x509: certificate signed by unknown authority'
date: '2022-06-17 15:21:41'
updated: '2022-06-17 15:21:41'
tags: [SSL]
permalink: /articles/2022/06/17/1655450501367.html
---
将文中**jireh.xyz**替换成自己的地址

## 方式一

```
echo -n | openssl s_client -showcerts -connect jireh.xyz:443 2>/dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > /usr/local/share/ca-certificates/jireh.xyz.crt
update-ca-certificates
```

## 方式二

```
$ echo -n | openssl s_client -showcerts -connect jireh.xyz:443 2>/dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' >> /etc/ssl/certs/ca-certificates.crt
```



