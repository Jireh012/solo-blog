title: 美剧 The Chosen《拣选》第一季 IMDB9.7分
date: '2020-11-13 10:07:57'
updated: '2021-05-31 15:46:19'
tags: [美剧]
permalink: /articles/2020/11/13/1605233276889.html
---
# 美剧 The Chosen《拣选》第一季 IMDB9.7分

* 第一部关于耶稣生平的多季电视剧集
* 众筹一千万美元，创造了娱乐类众筹项目的最高纪录
* 首季IMDB评分高达9.7分，其人物塑造水准不输《王冠》、《纸牌屋》
  
  ![](https://b3logfile.com/file/2020/11/solofetchupload5804467397407878299-531814a5.jpeg)

## 第一集

> I Have Called You By Name / 我点名呼召了你
> Two brothers struggle with their tax debts to Rome while a woman in the Red Quarter wrestles with her demons
> 两兄弟为欠罗马的应税债务而挣扎，而红区的一名妇女与她的恶魔搏斗（Google Translate）

## 第二集

> Shabbat / 安息日
> MATTHEW VALIDATES SIMON'S CLAIMS WITH PRAETOR QUINTUS, NICODEMUS INVESTIGATES THE MIRACLE REPORTED IN THE RED QUARTER, AND MARY RECEIVES SURPRISE GUESTS AT HER SHABBAT DINNER.
> 马修与执政官昆图斯证实了西蒙的说法，尼哥底母调查了红区报道的奇迹，玛丽在安息日晚宴上接待了惊喜客人。（Google Translate）

## 第三集

> Jesus Loves The Little Children / 耶稣喜爱小孩
> JESUS BEFRIENDS AND TEACHES THE GROUP OF CHILDREN WHO DISCOVER HIS CAMP ON THE OUTSKIRTS OF CAPERNAUM.
> 耶稣与在迦百农郊外发现祂的营地的那群孩子交朋友并教导他们。（Google Translate）

## 第四集

> The Rock On Which It Is Built / 建造在这磐石上
> WITH HIS LIFE AND FAMILY UNDER THREAT FROM ROME, SIMON SPENDS ONE LAST NIGHT FISHING IN A DESPERATE ATTEMPT TO SQUARE HIS DEBTS. ANDREW SPOTS A FAMILIAR FACE WAITING FOR THEM ON THE SHORES OF GALILEE.
> 由于他的生命和家人受到罗马的威胁，西蒙昨晚花了一个晚上钓鱼，绝望地试图偿还债务。安德鲁发现一张熟悉的面孔在加利利海岸等着他们。（Google Translate）

## 第五集

> The Wedding Gift / 结婚礼物（Google Translate）
> NICODEMUS INTERROGATES JOHN THE BAPTIZER WHILE JESUS AND HIS STUDENTS MAKE THEIR WAY TO A WEDDING CELEBRATION IN CANA. WHEN THE WINE RUNS LOW, MARY ASKS HER SON TO INTERVENE ON BEHALF OF THE BRIDEGROOM'S FAMILY.
> 尼哥底母审问施洗约翰，而耶稣和他的学生则前往迦拿参加婚礼。当酒快喝光时，玛丽让她的儿子代表新郎的家人进行干预。（Google Translate）

## 第六集

> Indescribable Compassion / 难以形容的同情心（Google Translate）
> AFTER WITNESSING THE HEALING OF A LEPER ON THE ROAD TO CAPERNAUM, A WOMAN FORCES HER PARALYTIC FRIEND THROUGH THE CROWD TO MEET JESUS.
> 一位妇女在前往迦百农的路上目睹麻风病人痊愈后，强迫她瘫痪的朋友穿过人群去见耶稣。（Google Translate）

## 第七集

> Invitations / 邀请
> MATTHEW STRUGGLES TO RECONCILE THE MIRACLES HE HAS WITNESSED WITH REALITY. NICODEMUS MEETS WITH JESUS BY NIGHT.
> 马修努力将他亲眼目睹的奇迹与现实调和起来。尼哥底母在夜间与耶稣会面。（Google Translate）

## 第八集

> I Am He / 我就是
> JESUS AND HIS STUDENTS COMPLETE THEIR PREPARATIONS AND LEAVE CAPERNAUM FOR SAMARIA. JESUS MEETS WITH A SUFFERING WOMAN AT JACOB'S WELL AND ANNOUNCES THAT HE IS THE MESSIAH.
> 耶稣和他的学生完成准备工作，离开迦百农去撒玛利亚。 耶稣在雅各布之井与一位受苦的妇女会面，并宣布他是弥赛亚。（Google Translate）

## 下载地址：

> 链接：https://pan.baidu.com/s/1Ot-cQQgCpZ6tKK1HV_74yQ
> 提取码：r3p5

