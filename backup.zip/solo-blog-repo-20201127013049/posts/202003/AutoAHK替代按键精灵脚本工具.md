title: AutoAHK替代按键精灵脚本工具
date: '2020-03-20 15:09:42'
updated: '2020-03-20 15:09:42'
tags: [工具]
permalink: /articles/2020/03/20/1584688182831.html
---
[AutoAHKv3.1.7z](https://img.hacpai.com/file/2020/03/AutoAHKv3.1-8284017f.7z)
