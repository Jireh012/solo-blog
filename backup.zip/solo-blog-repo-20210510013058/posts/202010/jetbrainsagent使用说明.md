title: jetbrains-agent使用说明
date: '2020-10-29 17:32:26'
updated: '2020-11-17 15:23:34'
tags: [JetBrains, Crack]
permalink: /articles/2020/10/29/1603963946649.html
---
# jetbrains-agent使用说明

jetbrains-agent是jetbrains产品全家桶激活工具

> 安装参数不会提供，大家自行在公众号中获取
> 希望大家支持正版 支持正版 支持正版（重要的事情说3遍）

## 相关前提

* [ ] **安装参数**
* [ ] jetbrains-agent本体
* [ ] idea/webstorm/……需要激活的IDE

## 获取安装参数

<center>

![image.png](https://b3logfile.com/file/2020/10/image-33fc059f.png)</center>

安装参数需要到**读书成诗**公众号中**关注并发送**`安装参数`来获取，首次获取需要一定时间
**温馨提示首次获取需要较长时间，过段时间再回复**`安装参数`来获取

![image.png](https://b3logfile.com/file/2020/10/image-d6e6f087.png)

## 激活

> 以下为沙箱环境，因为已经激活正版了
> 前面的安装步骤就不用说了
> 本地激活以IDEA为例

![image.png](https://b3logfile.com/file/2020/10/image-31fcfdc6.png)

打开IDEA，首次打开会提示选择激活IDEA或者试用，这里我们先选择试用（如果过期可以使用reset_eval文件夹内的脚本重置一下）

![image.png](https://b3logfile.com/file/2020/10/image-e7f46cbd.png)

接下来IDEA将会重启，重启完成后，将文件夹下lib文件夹中的`jetbrains-agent.jar`拖入IDEA程序中 | 如下

![image.png](https://b3logfile.com/file/2020/10/image-2c829688.png)

拖入后会提示IDEA需要重启，这里我们点击Restart，立即重启

![image.png](https://b3logfile.com/file/2020/10/image-b91a8842.png)

重启后将会自动打开激活工具

![image.png](https://b3logfile.com/file/2020/10/image-9e794b94.png)

这里将我们从公众号中获取的**安装参数**复制到，安装参数这一行中（默认选择Activation code）激活方式，再点击`为IDEA安装`，在出现的弹框中点击`是`

![image.png](https://b3logfile.com/file/2020/10/image-4985f817.png)

重启后，点击 Get Help — About，就会发现IDEA已经成功激活至2089年了

![image.png](https://b3logfile.com/file/2020/10/image-61c408af.png)

## 其他说明 Readme

```
========================================================================
 =======    Jetbrains Activation Code And License Server Crack    =======
 =======                     https://zhile.io                     =======
 =======              v3.2.0, Build Date: 2020-04-11              =======
 ========================================================================

 *** 如果你下载的jetbrains-agent.jar小于2M，肯定是没有下载完全（可对照sha1sum.txt）。***
 *** 请保留压缩包内的important.txt和jetbrains-agent.jar放在同一个目录，且不要改动内容！***

 *** 传统的vmoptions配置需要技巧，我推荐你还是按照本文档的方式配置！***

 Usage:
 0. Download the zip package and get jetbrains-agent.jar first.
    Download page: https://zhile.io/2018/08/17/jetbrains-license-server-crack.html
 1. Run the IDE and evalutate for free.
    You can reset eval by using: reset_eval script.
 2. Drag the jetbrains-agent.jar into the IDE window (Or install it as an IDE plugin).
    (Actually you can drag jetbrains-agent-latest.zip too)
    Click "Restart" button to restart your IDE.
 3. You will see the JetbrainsAgent Helper dialog.
    Select license type, enter arguments  and click install button.
 4. Restart IDE, and all done.
 x. Support "License server" and "Activation code":
    1). Entry license server address: https://fls.jetbrains-agent.com (Or http, if failed see no.2 [below])
    2). Active offline with the activation code file: ACTIVATION_CODE.txt
        License key is in legacy format == Key invalid，check your agent's config again
        If you need a custom license name, visit: https://zhile.io/custom-license.html
    3). Now you can activate jetbrains paid plugin with jetbrains-agent + activation code/license server!
        Jetbrains paid plugins activation code: https://zhile.io/jetbrains-paid-plugins-license.html
        All paid plugins: https://plugins.jetbrains.com/search?isPaid=true

 使用方法:
 0. 先下载压缩包解压后得到jetbrains-agent.jar。
    下载页面：https://zhile.io/2018/08/17/jetbrains-license-server-crack.html
 1. 启动你的IDE，如果上来就需要注册，选择：试用（Evaluate for free）进入IDE。
    如果你的IDE试用已过期可以使用reset_eval文件夹内的脚本重置一下。
 2. 将 jetbrains-agent.jar 拖进IDE窗口（或者当作IDE插件安装），点 "Restart" 按钮重启IDE。
    （事实上你拖 jetbrains-agent-latest.zip 进去IDE窗口也没问题）
 3. 在弹出的JetbrainsAgent Helper对话框中，输入安装参数，选择激活方式，点击安装按钮。
 4. 重启IDE，搞定。
 x. 支持两种注册方式：License server 和 Activation code:
    1). 选择License server方式，地址填入：https://fls.jetbrains-agent.com （HTTP也可用，网络不佳用第2种方式）
    2). 选择Activation code方式离线激活，请使用：ACTIVATION_CODE.txt 内的注册码激活
        License key is in legacy format == Key invalid，表示agent配置未生效。
        如果你需要自定义License name，请访问：https://zhile.io/custom-license.html
    3). 现在你可以使用jetbrains-agent + activation code/license server激活jetbrains平台的付费插件了！
        现有Jetbrains付费插件Activation code: https://zhile.io/jetbrains-paid-plugins-license.html
        现在有这些付费插件：https://plugins.jetbrains.com/search?isPaid=true

 本项目在最新2020.1.x上测试通过。
 理论上适用于目前Jetbrains全系列所有新老版本（这句话是瞎说的，如有问题请给我issue或进QQ群：30347511讨论）。
 IDE升级会从旧版本导入以上设置，导入配置后可能提示未注册（因为刚导入的vmoptions未生效），直接重启IDE即可，无需其他操作。


 本项目只做学习研究之用，不得用于商业用途！
 若资金允许，请点击 [https://www.jetbrains.com/idea/buy/] 购买正版，谢谢合作！
 学生凭学生证可免费申请 [https://sales.jetbrains.com/hc/zh-cn/articles/207154369-学生授权申请方式] 正版授权！
 创业公司可5折购买 [https://www.jetbrains.com/shop/eform/startup] 正版授权！
```

