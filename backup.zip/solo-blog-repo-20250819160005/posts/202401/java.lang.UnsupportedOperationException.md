title: java.lang.UnsupportedOperationException
date: '2024-01-22 17:20:56'
updated: '2024-01-22 17:20:56'
tags: [Java]
permalink: /articles/2024/01/22/1705915256003.html
---
# java.lang.UnsupportedOperationException异常

```
java.lang.UnsupportedOperationException
	at java.util.AbstractList.remove(AbstractList.java:161)
	at java.util.AbstractList$Itr.remove(AbstractList.java:374)
	at java.util.AbstractCollection.remove(AbstractCollection.java:293)
```

## 问题代码

```
List<Long> roleList = Func.toLongList(user.getRoleId());
roleList.remove(1625302726146387969L);
```

功能是将逗号分隔的字符串转换成long列表

## 分析

看下Func.toLongList

```
public static List<Long> toLongList(String str) {
        return Arrays.asList(toLongArray(str));
}
```

发现这个 Arrays.asList()返回的是ArrayList是Arrays类的静态内部类，并不是java.util下的ArrayList类，里面也没有没有实现remove、add等方法，所以调用remove方法会报错。

## 解决方法

```
List<Long> roleList = new ArrayList<>(Func.toLongList(user.getRoleId()));
```


