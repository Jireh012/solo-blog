title: 通过stunnel转发ssh实例
date: '2025-09-01 16:49:22'
updated: '2025-09-01 16:51:31'
tags: [stunnel, ssh, Linux]
permalink: /articles/2025/09/01/1756716561951.html
---
## 目的

为要在一台私有网络当中服务器，将局域网内的业务端口(Mysql)通过SSH反向隧道的方式转发到公网服务器一个端口上，但是这一台私网服务器所有的SSH出口被防火墙拦截无法连接远程SSH服务器，但是一些端口例如80、443是开放的，这是采用了stunnel封装的方式，把 SSH 流量封装在 HTTPS 流量里，看起来就像普通的 HTTPS，通过防火墙的拦截过滤

### 前提：

* 你有一台 **远程服务器（Server）** 的 root 权限。
* 你在本地（Client）可以安装 `stunnel` 和 `ssh`。
* 服务器允许外部访问 ​**443 端口**​。

### 🔹 服务端配置（CentOS 服务器）

#### 1.安装stunnel

```
# Debian/Ubuntu
sudo apt update
sudo apt install stunnel4 -y

# CentOS/RHEL
sudo yum install stunnel -y
```

#### 2.生成自签名证书（示例用，生产可用 Let's Encrypt）

```
openssl req -new -x509 -days 365 -nodes -out /etc/stunnel/stunnel.pem -keyout /etc/stunnel/stunnel.pem
chmod 600 /etc/stunnel/stunnel.pem
```

#### 3.编辑服务端配置 `/etc/stunnel/stunnel.conf`

```
pid = /var/run/stunnel/stunnel.pid
setuid = nobody
setgid = nobody
cert = /etc/stunnel/stunnel.pem

[ssh-over-443]
accept = 443 #stunnel监听公网地址
connect = 127.0.0.1:22 #服务端的SSH端口
```

#### 4.创建PID环境

```
mkdir -p /var/run/stunnel
chown nobody:nobody /var/run/stunnel
```

#### 5.启用stunnel

```
systemctl enable stunnel
systemctl start stunnel
```

### 🔹 客户端配置（CentOS 客户机）

#### 1.安装stunnel

```
yum install -y stunnel
```

#### 2.编辑客户端配置 `~/stunnel-client.conf`

```
client = yes
foreground = yes

[ssh-tunnel]
accept = 127.0.0.1:2222
connect = your.server.ip:443
verify = 0
```

👉 说明：

* `accept = 127.0.0.1:2222` → 本地监听 2222 端口
* `connect = your.server.ip:443` → 连接远程服务器的 stunnel 443
* `verify = 0` → 忽略证书校验（自签名证书时需要）

#### 3.运行客户端 stunnel

```
stunnel ~/stunnel-client.conf
```

#### 4.通过隧道登录 SSH

```
ssh -p 2222 root@127.0.0.1
```

### 🔹 流程示意

```
SSH 客户端 → 本地 stunnel(2222) → TLS → 远程 stunnel(443) → SSH 服务(22)
```

这样，你就可以在防火墙只开放 **443 端口** 的情况下，正常通过 stunnel 使用 SSH。

