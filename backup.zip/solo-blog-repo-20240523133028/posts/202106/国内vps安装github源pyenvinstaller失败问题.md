title: 国内vps安装github源pyenv-installer失败问题
date: '2021-06-20 14:57:17'
updated: '2021-06-20 15:00:46'
tags: [pyenv]
permalink: /articles/2021/06/20/1624172237672.html
---
因为国内网络环境的原因，Github经常连不上或者仓库clone不下来，导致使用

```
curl -L https://github.com/pyenv/pyenv-installer/raw/master/bin/pyenv-installer | bash
```

无法安装**pyenv**环境，搜了下国内好像也没人弄国内的源（可能没搜到），所以自己用Gitee码云镜像了一份，修改了几个仓库的地址。最后安装成功

**Gitee码云源：**

```
curl -L https://gitee.com/lastle/pyenv-installer/raw/master/bin/pyenv-installer | bash
```

