title: VttConvertSrt | 字幕格式转化器
date: '2020-11-13 17:32:24'
updated: '2020-12-01 14:12:21'
tags: [开源]
permalink: /articles/2020/11/13/1605259944087.html
---
![image.png](https://b3logfile.com/file/2020/11/image-106d5a4c.png)

### 说明

该项目基于B站 `小之悠悠`中提供的源码`https://www.bilibili.com/video/av68717229`上进行修改

修复了**中文乱码**，和部分符号 `♪`乱码的问题，以及添加转换完成后的提示。

项目地址：[https://github.com/Jireh012/VttConvertSrt]([https://github.com/Jireh012/VttConvertSrt]())

### 主要功能

对vtt或者srt字幕格式进行相互转换（支持批量操作）

### 下载地址

[https://github.com/Jireh012/VttConvertSrt/releases](https://github.com/Jireh012/VttConvertSrt/releases)

[VttConvertSrt.7z](https://b3logfile.com/file/2020/12/VttConvertSrt-b9756cc8.7z)



