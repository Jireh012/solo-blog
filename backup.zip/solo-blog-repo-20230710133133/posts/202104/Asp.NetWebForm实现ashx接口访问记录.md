title: Asp.Net WebForm实现ashx接口访问记录
date: '2021-04-01 15:59:14'
updated: '2021-04-01 15:59:14'
tags: [asp.net, webform, C#]
permalink: /articles/2021/04/01/1617263953910.html
---
基于 **IHttpModule** 接口来实现

```C#
using Common;
using ControlClass;
using DataClass;
using Newtonsoft.Json;
using System;
using System.Web;

/// <summary>
/// LogAshxModule 的摘要说明
/// </summary>
public class LogAshxModule : IHttpModule
{
    public void Dispose()
    {
    }

    public void Init(HttpApplication context)
    {
        HttpContext.Current.ApplicationInstance.PreRequestHandlerExecute += new EventHandler(this.log);
    }

    public void log(object sender, EventArgs e)
    {
        string url = ((System.Web.HttpApplication)(sender)).Request.RawUrl;
        if (url.Contains("ashx"))
        {
            var logBLL = new cs_request_log();
            var entity = new request_log();
            entity.AddTime = DateTime.Now;
            entity.Path = ((System.Web.HttpApplication)(sender)).Request.Path;
            entity.RawUrl = url;
            entity.QueryString = JsonConvert.SerializeObject(NVCExtender.ToDictionary(((System.Web.HttpApplication)(sender)).Request.QueryString));
            entity.Form = JsonConvert.SerializeObject(NVCExtender.ToDictionary(((System.Web.HttpApplication)(sender)).Request.Form));
            entity.BrowserInfo = ((System.Web.HttpApplication)(sender)).Request.UserAgent;
            entity.ClientIpAddress = ((System.Web.HttpApplication)(sender)).Request.UserHostAddress;
            entity.ClientName = ((System.Web.HttpApplication)(sender)).Request.UserHostName;

            var userModel = Ctrl_Users.GetModel();
            if (userModel != null)
            {
                entity.Uid = userModel.id;
            }
            logBLL.Add(entity);
        }   
        
    }
}
```

### Web.config

还需要再web.config中配置**modules**

```
<system.webServer>
    <modules>
      <add name="LogAshxModule" type="LogAshxModule" />
    </modules>
  </system.webServer>
```

