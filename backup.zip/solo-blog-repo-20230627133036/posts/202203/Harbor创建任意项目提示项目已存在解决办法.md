title: Harbor创建任意项目提示项目已存在解决办法
date: '2022-03-04 11:06:08'
updated: '2022-03-04 11:06:08'
tags: [harbor, nginx]
permalink: /articles/2022/03/04/1646363168512.html
---
Harbor用nginx反代后出现创建任意项目提示项目已存在，使用端口访问正常

> https://github.com/goharbor/harbor/issues/8408#issuecomment-820289392
> 外部nginx默认会将head请求转换为get再发送到harbor的nginx中, 导致harbor一直返回200状态码
> harbor根据200状态码认为项目存在, 所以不管输入什么总是提示项目已经存在了

## 解决办法

> nginx添加proxy_cache_convert_head off;
> ![image.png](https://b3logfile.com/file/2022/03/image-128d2284.png)
> 禁用head请求自动转换之后, harbor就可以正常添加项目了



