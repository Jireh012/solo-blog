title: logstash重载配置
date: '2021-02-18 16:30:23'
updated: '2021-02-18 17:31:21'
tags: [logstash]
permalink: /articles/2021/02/18/1613637023024.html
---
在启动命令后加入

```
--config.reload.automatic
```

> 如果在命令行指定了`-e`选项，则`--config.reload.automatic`选项不可用。

默认为3（秒）检查一次，使用以下命令选项指定间隔多少秒检查一次

```
--config.reload.interval <second>
```

示例

```
nohup ./logstash -f ./jdbcconfig/jdbc.conf --path.data=/jdbcconfig/ --config.reload.automatic &
```

如果logstash已经使用没有自动重载选项的命令启动，可使用如下命令
发送一个挂起指令给logstash重新加载配置文件

```
ps -ef | grep logstas

kill -1 <pid>
```

