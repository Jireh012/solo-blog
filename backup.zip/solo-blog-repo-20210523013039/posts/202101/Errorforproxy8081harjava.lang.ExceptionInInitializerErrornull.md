title: 'Error for /proxy/8081/har java.lang.ExceptionInInitializerError: null'
date: '2021-01-19 14:44:26'
updated: '2021-01-19 14:44:26'
tags: [browsermob-proxy, selenium]
permalink: /articles/2021/01/19/1611038666638.html
---
在Selenium中使用BrowserMobProxy，在启动的时候报`Error for /proxy/8081/har java.lang.ExceptionInInitializerError: null`错误，导致无法正常抓取请求

```
WARNING: Use --illegal-access=warn to enable warnings of further illegal reflective access operations
WARNING: All illegal access operations will be denied in a future release
[INFO 2020-03-06T13:20:18,883 net.lightbody.bmp.proxy.Main] (main) Starting BrowserMob Proxy version 2.1.4
[INFO 2020-03-06T13:20:18,901 org.eclipse.jetty.util.log] (main) jetty-7.x.y-SNAPSHOT
[INFO 2020-03-06T13:20:18,921 org.eclipse.jetty.util.log] (main) started o.e.j.s.ServletContextHandler{/,null}
[INFO 2020-03-06T13:20:18,986 org.eclipse.jetty.util.log] (main) Started SelectChannelConnector@0.0.0.0:7667
[INFO 2020-03-06T13:20:19,641 org.littleshoot.proxy.impl.DefaultHttpProxyServer] (qtp173060252-20) Starting proxy at address: 0.0.0.0/0.0.0.0:8081
[INFO 2020-03-06T13:20:19,678 org.littleshoot.proxy.impl.DefaultHttpProxyServer] (qtp173060252-20) Proxy listening with TCP transport
[INFO 2020-03-06T13:20:19,713 org.littleshoot.proxy.impl.DefaultHttpProxyServer] (qtp173060252-20) Proxy started at address: /0:0:0:0:0:0:0:0:8081
[WARN 2020-03-06T13:20:19,741 org.eclipse.jetty.util.log] (qtp173060252-21) Error for /proxy/8081/har java.lang.ExceptionInInitializerError: null
at org.mvel2.PropertyAccessor.set(PropertyAccessor.java:249) ~[browsermob-dist-2.1.4.jar:?]
at org.mvel2.PropertyAccessor.set(PropertyAccessor.java:135) ~[browsermob-dist-2.1.4.jar:?]
at org.mvel2.MVEL.setProperty(MVEL.java:1088) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.MvelEvaluator.write(MvelEvaluator.java:64) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.binding.MvelRequestBinder.bind(MvelRequestBinder.java:79) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.routing.WidgetRoutingDispatcher.bindAndReply(WidgetRoutingDispatcher.java:97) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.routing.WidgetRoutingDispatcher.dispatch(WidgetRoutingDispatcher.java:88) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.DebugModeRoutingDispatcher.dispatch(DebugModeRoutingDispatcher.java:56) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.SitebricksFilter.doFilter(SitebricksFilter.java:62) ~[browsermob-dist-2.1.4.jar:?]
at com.google.inject.servlet.FilterDefinition.doFilter(FilterDefinition.java:163) ~[browsermob-dist-2.1.4.jar:?]
at com.google.inject.servlet.FilterChainInvocation.doFilter(FilterChainInvocation.java:58) ~[browsermob-dist-2.1.4.jar:?]
at com.google.sitebricks.HiddenMethodFilter.doFilter(HiddenMethodFilter.java:70) ~[browsermob-dist-2.1.4.jar:?]
at com.google.inject.servlet.FilterDefinition.doFilter(FilterDefinition.java:163) ~[browsermob-dist-2.1.4.jar:?]
at com.google.inject.servlet.FilterChainInvocation.doFilter(FilterChainInvocation.java:58) ~[browsermob-dist-2.1.4.jar:?]
at com.google.inject.servlet.ManagedFilterPipeline.dispatch(ManagedFilterPipeline.java:118) ~[browsermob-dist-2.1.4.jar:?]
at com.google.inject.servlet.GuiceFilter.doFilter(GuiceFilter.java:113) ~[browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1323) ~[browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.servlet.ServletHandler.doHandle(ServletHandler.java:474) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.session.SessionHandler.doHandle(SessionHandler.java:224) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.handler.ContextHandler.doHandle(ContextHandler.java:935) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.servlet.ServletHandler.doScope(ServletHandler.java:404) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.session.SessionHandler.doScope(SessionHandler.java:184) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.handler.ContextHandler.doScope(ContextHandler.java:870) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.handler.ScopedHandler.handle(ScopedHandler.java:117) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.handler.HandlerWrapper.handle(HandlerWrapper.java:116) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.Server.handle(Server.java:346) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.HttpConnection.handleRequest(HttpConnection.java:596) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.HttpConnection$RequestHandler.content(HttpConnection.java:1068) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.http.HttpParser.parseNext(HttpParser.java:807) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.http.HttpParser.parseAvailable(HttpParser.java:220) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.server.HttpConnection.handle(HttpConnection.java:426) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.io.nio.SelectChannelEndPoint.handle(SelectChannelEndPoint.java:520) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.io.nio.SelectChannelEndPoint$1.run(SelectChannelEndPoint.java:40) [browsermob-dist-2.1.4.jar:?]
at org.eclipse.jetty.util.thread.QueuedThreadPool$3.run(QueuedThreadPool.java:528) [browsermob-dist-2.1.4.jar:?]
at java.lang.Thread.run(Thread.java:834) [?:?]
Caused by: java.lang.StringIndexOutOfBoundsException: begin 0, end 3, length 2
at java.lang.String.checkBoundsBeginEnd(String.java:3319) ~[?:?]
at java.lang.String.substring(String.java:1874) ~[?:?]
at org.mvel2.util.ParseTools.(ParseTools.java:62) ~[browsermob-dist-2.1.4.jar:?]
... 35 more
```

### 解决方法

看了下环境变量之前是用的1.9，**browsermob**是的一个17年的项目，可能在1.9的环境下可能出问题。
browsermob项目地址：https://github.com/lightbody/browsermob-proxy/

随后将Java环境变量，修改至1.8的环境，再次运行，成功抓取

