title: ' [ERROR FileContent--proc-sys-net-ipv4-ip_forward]: /proc/sys/net/ipv4/ip_forward
  contents are not set to 1'
date: '2021-11-24 16:06:34'
updated: '2021-11-24 16:06:34'
tags: [k8s]
permalink: /articles/2021/11/24/1637741194224.html
---
https://kuboard.cn/install/install-k8s.html#%E7%A7%BB%E9%99%A4worker%E8%8A%82%E7%82%B9%E5%B9%B6%E9%87%8D%E8%AF%95
初始化master节点的时候报错

```
error execution phase preflight: [preflight] Some fatal errors occurred:
        [ERROR FileContent--proc-sys-net-ipv4-ip_forward]: /proc/sys/net/ipv4/ip_forward contents are not set to 1
[preflight] If you know what you are doing, you can make a check non-fatal with `--ignore-preflight-errors=...`
To see the stack trace of this error execute with --v=5 or higher
```

### 解决

使用 `sysctl -w net.ipv4.ip_forward=1` 命令解决

