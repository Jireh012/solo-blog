title: 'Git SSL certificate problem: unable to get local issuer certificate'
date: '2021-09-01 12:51:06'
updated: '2021-09-01 12:51:06'
tags: [git]
permalink: /articles/2021/09/01/1630471866064.html
---
Git在Clone项目时报错，无法获取仓库内容

错误提示 ：`SSL certificate problem: unable to get local issuer certificate`

看了下这是因为所配置的Https证书不可信导致的

![image.png](https://b3logfile.com/file/2021/09/image-ed023827.png)

Git默认会对证书进行校验，如果证书不可信，就会提示以上错误

#### 解决方法

关闭git的证书验证即可

在控制台或命令行程序输入以下命令 ：`git config --global http.sslVerify false`

