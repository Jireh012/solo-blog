title: navicat oracle library is not loaded
date: '2021-05-19 09:38:10'
updated: '2021-05-19 09:38:10'
tags: [navicat, oracle]
permalink: /articles/2021/05/19/1621388290009.html
---
Navicat连接oracle数据库报错**navicat oracle library is not loaded**

原因是可能是没有配置oci.dll或者配置错了。

需要根据自己系统版本去下载oci.dll文件，下载地址：https://www.oracle.com/database/technologies/instant-client/downloads.html

![image.png](https://b3logfile.com/file/2021/05/image-e1f852d2.png)

![image.png](https://b3logfile.com/file/2021/05/image-94eb85dc.png)

下载 **Basic Package**基础包就可以了。

然后在Navicat Premium程序中，打开“工具 - 选项 - 环境

![image.png](https://b3logfile.com/file/2021/05/image-d47f218a.png)

在OCI环境 - OCI library (oci.dll)选项下，将刚才下载的压缩包解压后文件夹中oci.dll的地址填入

![image.png](https://b3logfile.com/file/2021/05/image-95b048ee.png)

最后重启Navicat Premium就可以了（**必须重启**）

