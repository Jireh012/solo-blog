title: Intellij IDEA运行报Command line is too long
date: '2020-03-23 13:49:34'
updated: '2020-03-23 13:49:34'
tags: [开发小记]
permalink: /articles/2020/03/23/1584942574529.html
---
# Intellij IDEA运行报Command line is too long



详细报错内容：

Error running 'XXXApplication': Command line is too long. Shorten command line for XXXApplication or also for Spring Boot default configuration. (moments ago)




解决方法:

修改项目下 .idea\workspace.xml 文件，找到标签
```
<component name="PropertiesComponent">
```
在标签里加一行  
```
<property name="dynamic.classpath" value="true" />
```
