title: Temporary failure resolving 'archive.ubuntu.com'
date: '2021-06-09 10:36:38'
updated: '2021-06-09 10:36:38'
tags: [Docker]
permalink: /articles/2021/06/09/1623206198123.html
---
在docker build的时候出现 ` dockerfile Temporary failure resolving 'archive.ubuntu.com'`错误

### 解决方法

在Docker daemon配置文件当中添加如下代码

```
"dns": [
    "8.8.8.8",
    "8.8.4.4",
    "2001:4860:4860::8888",
    "2001:4860:4860::8844"
  ],
```

完整代码：

```
{
  "registry-mirrors": [
    "http://f1361db2.m.daocloud.io"
  ],
  "insecure-registries": [
    "harbor.ouhaihr.com:32780",
    "192.168.5.101:19820"
  ],
  "debug": false,
  "experimental": false,
  "dns": [
    "8.8.8.8",
    "8.8.4.4",
    "2001:4860:4860::8888",
    "2001:4860:4860::8844"
  ],
  "features": {
    "buildkit": true
  },
  "builder": {
    "gc": {
      "enabled": true,
      "defaultKeepStorage": "20GB"
    }
  }
}
```

