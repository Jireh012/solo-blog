title: Java正则表达式正确食用方式
date: '2020-11-26 16:36:38'
updated: '2020-11-26 16:36:38'
tags: [Java]
permalink: /articles/2020/11/26/1606379798134.html
---
> 在使用正则表达式时,利用好其预编译功能,可以有效加快正则匹配速度。

需要把**Pattern**定义为static final静态变量

不正确的食用：

```
String data = Pattern.compile("\t|\r|\n|").matcher(str).replaceAll("")
```

正确的食用：

```
private static final Pattern pattern = Pattern.compile("\t|\r|\n|");
 
private void func() {
    String data = pattern.matcher(str).replaceAll("")
}
```

