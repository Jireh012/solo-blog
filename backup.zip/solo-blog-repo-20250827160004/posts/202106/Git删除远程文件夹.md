title: Git删除远程文件夹
date: '2021-06-28 09:54:08'
updated: '2021-06-28 09:54:08'
tags: [Git]
permalink: /articles/2021/06/28/1624845248344.html
---
Git删除远程文件夹，例如logs、.idea、target这些非代码的文件夹。

使用如下命令即可删除

```
git rm -r --cached 文件/文件夹
```

删除前可以使用 `-n` 参数，预览文件删除列表

```
git rm -r -n --cached 文件/文件夹
```

