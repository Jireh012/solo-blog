title: Netty实现pem证书格式的wss协议
date: '2021-08-16 09:36:32'
updated: '2021-08-16 09:36:32'
tags: [netty, websocket, wss]
permalink: /articles/2021/08/16/1629077792469.html
---
如果你的项目是通过`https`链接websocket时就需要配置wss的支持

### 相关引用

```
<!-- Netty -->
        <dependency>
            <groupId>io.netty</groupId>
            <artifactId>netty-all</artifactId>
            <version>4.1.32.Final</version>
        </dependency>
	<!-- pem证书工具类 -->	
        <dependency>
            <groupId>io.github.hakky54</groupId>
            <artifactId>sslcontext-kickstart-for-pem</artifactId>
            <version>6.8.0</version>
        </dependency>
```

在

websocket连接初始化Channel时加入如下代码

```
X509ExtendedKeyManager keyManager = PemUtils.loadIdentityMaterial(Paths.get("/www/server/panel/vhost/cert/pioneer.ouhaihr.com/fullchain.pem"),
				Paths.get("/www/server/panel/vhost/cert/pioneer.ouhaihr.com/privkey.pem"));

			SSLFactory sslFactory = SSLFactory.builder()
				.withIdentityMaterial(keyManager)
				.build();

			SSLEngine engine = sslFactory.getSslContext().createSSLEngine();
			engine.setUseClientMode(false);
			engine.setNeedClientAuth(false);
			pipeline.addLast(new SslHandler(engine));
```

### 完整实例

```
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.stream.ChunkedWriteHandler;
import nl.altindag.ssl.SSLFactory;
import nl.altindag.ssl.util.PemUtils;
import org.springblade.modules.customer.netty.codec.WebSocketPacketCodec;
import org.springblade.modules.customer.netty.config.NettyProperties;
import org.springblade.modules.customer.netty.handler.MyIdleStateHandler;
import org.springblade.modules.customer.netty.utils.PipelineUtil;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.X509ExtendedKeyManager;
import java.nio.file.Paths;

/**
 * websocket连接初始化Channel，给Channel关联的pipeline添加handler
 *
 * @author Jireh
 * @date 2021-08-10
 */
@Component
public class WebSocketServerInitializer extends ChannelInitializer<NioSocketChannel> {

	private final PipelineUtil pipelineUtil;

	private final WebSocketPacketCodec webSocketPacketCodec;

	/**
	 * websocket路径
	 */
	private final String websocketPath;

	/**
	 * 最大内容长度
	 */
	private final int maxContentLength;

	private final Boolean isWss;

	public WebSocketServerInitializer(NettyProperties nettyProperties, PipelineUtil pipelineUtil, WebSocketPacketCodec webSocketPacketCodec) {
		this.websocketPath = nettyProperties.getWebsocket().getPath();
		this.maxContentLength = nettyProperties.getWebsocket().getHttpObjectArrgregator().getMaxContentLength();
		this.isWss = nettyProperties.getWebsocket().getIsWss();
		this.pipelineUtil = pipelineUtil;
		this.webSocketPacketCodec = webSocketPacketCodec;
	}

	@Override
	protected void initChannel(NioSocketChannel ch) {
		ChannelPipeline pipeline = ch.pipeline();

		if (isWss) {
			X509ExtendedKeyManager keyManager = PemUtils.loadIdentityMaterial(Paths.get("/www/server/panel/vhost/cert/pioneer.ouhaihr.com/fullchain.pem"),
				Paths.get("/www/server/panel/vhost/cert/pioneer.ouhaihr.com/privkey.pem"));

			SSLFactory sslFactory = SSLFactory.builder()
				.withIdentityMaterial(keyManager)
				.build();

			SSLEngine engine = sslFactory.getSslContext().createSSLEngine();
			engine.setUseClientMode(false);
			engine.setNeedClientAuth(false);
			pipeline.addLast(new SslHandler(engine));
		}

		// 处理第一次连接http的握手请求
		pipeline.addLast(new HttpServerCodec());
		// 写文件内容
		pipeline.addLast(new ChunkedWriteHandler());
		// 保证接收的http请求的完整性
		pipeline.addLast(new HttpObjectAggregator(maxContentLength));
		// 处理其他的WebSocketFrame
		pipeline.addLast(new WebSocketServerProtocolHandler(websocketPath));
		// 空闲检测
		ch.pipeline().addLast(new MyIdleStateHandler());
		// WebSocket数据包编解码器
		ch.pipeline().addLast(webSocketPacketCodec);
		// 添加tcp/websocket通用handler
		pipelineUtil.addHandler(pipeline);
	}
}
```

