title: 'Spring循环引用报错 in its raw version as part of a circular reference, but has eventually
  been wrapped. '
date: '2020-04-10 15:06:31'
updated: '2021-01-27 13:35:41'
tags: [开发小记, Spring, Java]
permalink: /articles/2020/04/10/1586502391529.html
---
# Spring循环引用报错 in its raw version as part of a circular reference, but has eventually been wrapped.

解决方案：

取消`@AllArgsConstructor`注解

使用`@Autowired`注解，并且在`@Autowired`注解下再加上`@Lazy`注解

例如

```
@Service
public class DeviceServiceImpl implements IDeviceService {

	@Autowired
	@Lazy
	private IDeviceBaseService deviceBaseService;

}
```

---

`@Lazy`注解的功能是，在Spring 在启动的时候延迟加载这个bean，然后在他即调用这个bean的时候再去初始化，这样就避免了Spring循环引用的异常。

还有一种xml的方式这里就不写了，有兴趣的可以去查一下

**但其实更好的解决办法是，对两个bean耦合的部份进行解耦，对公共部份抽离出来单独新建service。**

