title: 'error: resource android:attr/fontVariationSettings not found'
date: '2021-01-25 16:35:52'
updated: '2021-01-25 16:35:52'
tags: [Android, Bug]
permalink: /articles/2021/01/25/1611563752671.html
---
Android项目编译运行时报错 `# error: resource android:attr/fontVariationSettings not found`

### 解决方法

是 编译版本 的问题，在`build.gradle`中修改至正确的版本。

