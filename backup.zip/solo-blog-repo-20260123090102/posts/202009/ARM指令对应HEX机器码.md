title: ARM指令对应HEX机器码
date: '2020-09-26 14:00:00'
updated: '2020-09-26 14:12:16'
tags: [逆向, IDA, Arm]
permalink: /articles/2020/09/26/1601100000721.html
---
<center>

| ARM | HEX | Description |
| --- | --- | --- |
| BNE | D1 | 相等（或为0）跳转 |
| BEQ | D0 | 不相等（或不为0）跳转 |
| CBZ | B1 |  比较，为零则跳转 |
| CBNZ | B9 | 比较，为非零则跳转 |
| BEQ.W | **00** F0 {X} **80/81** | 同BEQ，32位指令 |
| BNE.W | **40** F0 {X} **80/81** | 同BNE，32位指令 |

