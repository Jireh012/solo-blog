title: UDP/TCP通信测试工具推荐
date: '2021-02-09 09:09:15'
updated: '2021-02-18 10:23:17'
tags: [开发工具]
permalink: /articles/2021/02/09/1612832955201.html
---
### SocketTest

> 一个 java 写的 socket 测试工具，所以还需要jre相应环境。它可以创建 TCP 和 UDP 客户端或服务器。它可以用来测试的任何使用 TCP 或 UDP 协议进行通信的服务器或客户端。
> 由于是 java 写的所以可以跨平台使用。注意：如果是在 MacOS 下使用，开启的监听端口要大于 1024。否则会报 Permission denied 错误。

![image.png](https://b3logfile.com/file/2021/02/image-43fcb1fe.png)

#### 下载地址

[SocketTest3.7z](https://b3logfile.com/file/2021/02/SocketTest3-f6cfb57c.7z)

### Sokit

> sokit 是一个在 windows 平台下免费的 TCP/UDP 测试（调试）工具， 可以用来接收，发送或转发 TCP/UDP 数据包。
> 它有三种工作模式： 服务器模式、客户端模式、转发器模式。
> 支持发送 ascii 字符串数据，以及十六进制表示的原始字节，单次发送的字符数目没有限制；收到的数据会同时以这两种形式显示。

![image.png](https://b3logfile.com/file/2021/02/image-73c61793.png)

#### 下载地址

[sokit.7z](https://b3logfile.com/file/2021/02/sokit-8325a7b8.7z)

