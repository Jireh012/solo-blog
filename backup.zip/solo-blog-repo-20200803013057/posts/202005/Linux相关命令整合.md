title: Linux相关命令整合
date: '2020-05-06 16:43:57'
updated: '2020-05-28 10:45:53'
tags: [Linux]
permalink: /articles/2020/05/06/1588754636951.html
---
# Linux相关命令整合

### 删除docker中停止的容器
`docker rm $(sudo docker ps -a -q)`

### 删除docker镜像（已经创建容器的删除不了）
`docker rmi -f $(docker images -qa)`

### 查看当前系统版本
`cat /etc/redhat-release`

### 查询当前活动用户
`w`

### Centos6 查询防火墙状态
`service iptables status`

### 查看系统各分区使用情况
`df -h`

### 查询指定文件夹下文件大小
`du -sm /*`

