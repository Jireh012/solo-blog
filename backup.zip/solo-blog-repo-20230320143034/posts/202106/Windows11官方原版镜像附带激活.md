title: Windows 11官方原版镜像（附带激活）
date: '2021-06-25 09:32:44'
updated: '2021-06-25 09:32:44'
tags: [Windows, Win11]
permalink: /articles/2021/06/25/1624584764498.html
---
微软正式推出 Windows 11系统啦，想要尝鲜的可以升级安装试试看。

![](https://b3logfile.com/file/2021/06/solo-fetchupload-3630606702368674671-657eefe3.jpeg)

### 下载地址

> 官方地址：[Win11](https://media-tjbh-person.tjoss.xstore.ctyun.cn/PERSONCLOUD/2d4c13a4-ca6b-45c7-b8e5-281146a60271.iso?x-amz-CLIENTTYPEIN=UNKNOWN&AWSAccessKeyId=B12spNbFIkHcJjk5MvKN&x-amz-UID=556044640&x-amz-APPID=828221&response-content-disposition=attachment%3Bfilename%3D21996.1.210529-1541.co_release_CLIENT_CONSUMER_x64FRE_en-us.iso&x-amz-CLIENTNETWORK=UNKNOWN&x-amz-CLOUDTYPEIN=PERSON&x-amz-limit=rate%3D25600%2Cconcurrency%3D10&Signature=B23NbuBnaJabUHqXCUaycXB9Zhg%3D&x-amz-SHID=114031568411&Expires=1623788811&x-amz-FSIZE=4874553344&x-amz-UFID=41382113556864728)（已限流）

> SHA-1 值：
> 3B6DA9194BA303AC7DBBF2E521716C809500919C

> 谷歌云：
> https://drive.google.com/file/d/1sH0cBI9hwh8EdlVRVn-69xcviA-jZRmk/view?usp=sharing

> 度盘：
> https://pan.baidu.com/s/12rp63ewc99W1vGBK8CmeYg
> 提取码：2wmz

> 天翼云：
> https://cloud.189.cn/web/share?code=InQ3637BvEbu

> 阿里网盘
> aliyunpan://utf-8”21996.1.210529-1541.co_release_CLIENT_CONSUMER_x64FRE_en-us.iso|3B6DA9194BA303AC7DBBF2E521716C809500919C|4874553344|application/oct-stream

### 专业版激活代码

```
slmgr /ipk W269N-WFGWX-YVC9B-4J6C9-T83GX

slmgr /skms kms.03k.org

slmgr /ato
```

