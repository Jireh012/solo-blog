title: Gitfork分支与源分支同步代码
date: '2020-03-19 11:00:20'
updated: '2020-03-19 11:00:20'
tags: [Git, 开发小记]
permalink: /articles/2020/03/19/1584586820560.html
---
首先查看自己是否配置了upstream地址：

```
git remote -v
```

![image.png](https://img.hacpai.com/file/2020/03/image-89009199.png)

以上就是没有添加的状态。使用以下命令添加upstream地址：

```
git remote add upstream URL

```

URL替换成源分支的地址

然后利用fetch和merge合并upstream的master分支：

```
git fetch upstream
git merge upstream/master
```

然后本地的master分支就更新至upstream的master版本。

然后利用push将本地分支覆盖到git远程分支上：

```
git push origin master:master

```

OK，这就已经完成fork后保持对源项目的更新。
