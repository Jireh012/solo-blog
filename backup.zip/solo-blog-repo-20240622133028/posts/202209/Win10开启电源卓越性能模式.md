title: Win10开启电源卓越性能模式
date: '2022-09-09 13:39:59'
updated: '2022-09-09 13:39:59'
tags: [Win10]
permalink: /articles/2022/09/09/1662701998967.html
---
在cmd或powershell中执行命令

```
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
```

![image.png](https://b3logfile.com/file/2022/09/image-h1lnzeD.png)

