title: Docker部署Superset
date: '2020-11-03 10:55:29'
updated: '2020-11-03 13:46:33'
tags: [Docker, Superset]
permalink: /articles/2020/11/03/1604372129177.html
---
# Docker部署Superset

> 本次Superset镜像采用的是 amancevice/superset
> 该镜像为精简版，无数据Demo

![image.png](https://b3logfile.com/file/2020/11/image-81ceb3dc.png)

### 创建文件夹

`mkdir -p /data/superset `

这个文件夹存放的是## **superset_config.py**配置文件，详情请[查询
https://preset.io/blog/2020-06-08-first-chart/](https://preset.io/blog/2020-06-08-first-chart/)

### 创建容器

`docker run -d --name superset -p 8088:8088 -v /data/superset:/etc/superset amancevice/superset`

### Superset初始化

`docker exec -it superset superset-init`

会提示如下：
这里就按自己的需求填写就好了，依次是用户名，名字，姓，邮箱，密码

```
[root@localhost data]# docker exec -it superset superset-init
Username [admin]: 
User first name [admin]: 
User last name [user]: 
Email [admin@fab.org]: 
Password:
```

### 升级

```
docker exec superset superset db upgrade
```

