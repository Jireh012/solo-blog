title: MT一键搭建白名单模式
date: '2022-01-10 10:36:04'
updated: '2022-01-10 10:36:04'
tags: [proxy]
permalink: /articles/2022/01/10/1641782164468.html
---
一键安装代码：

```
bash <(curl -sSL "https://raw.githubusercontent.com/xb0or/nginx-mtproxy/main/mtp.sh")
```

### Tips:

* 某些服务器初始环节需要安装xxd ` yum install vim-common`


