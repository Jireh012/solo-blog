title: Fastjson 1.2.80及以下存在Throwable 反序列化漏洞
date: '2022-05-24 10:52:50'
updated: '2022-05-24 10:53:29'
tags: [漏洞]
permalink: /articles/2022/05/24/1653360770593.html
---
![image.png](https://b3logfile.com/file/2022/05/image-e247a253.png)

近日，Fastjson Develop Team 发布修复了 Fastjson 1.2.80 及之前版本存在的安全风险，该安全风险可能导致反序列化漏洞。

## 漏洞描述

Fastjson 是阿里巴巴开源的 Java 对象和 JSON 格式字符串的快速转换的工具库。

Fastjson 1.2.80 及之前版本使用黑白名单用于防御反序列化漏洞，经研究该防御策略在特定条件下可绕过默认 autoType 关闭限制，攻击远程服务器，风险影响较大。建议 Fastjson 用户尽快采取安全措施保障系统安全。

## 影响范围

```
Fastjson <= 1.2.80
```

## 修复建议

参考漏洞影响范围，目前 Fastjson Develop Team 已公布漏洞修复方案，请参考以下修复建议或官方文档进行修复：[https://github.com/alibaba/fastjson/wiki/security_update_20220523](https://github.com/alibaba/fastjson/wiki/security_update_20220523)

### 升级到最新版本1.2.83

升级到最新版本1.2.83 [https://github.com/alibaba/fastjson/releases/tag/1.2.83](https://github.com/alibaba/fastjson/releases/tag/1.2.83)

该版本涉及autotype行为变更，在某些场景会出现不兼容的情况，如遇遇到问题可以到 [https://github.com/alibaba/fastjson/issues](https://github.com/alibaba/fastjson/issues) 寻求帮助。

### safeMode 加固

Fastjson 在1.2.68及之后的版本中引入了 safeMode，配置 safeMode 后，无论白名单和黑名单，都不支持 autoType，可杜绝反序列化Gadgets类变种攻击（关闭 autoType 注意评估对业务的影响），可参考 [https://github.com/alibaba/fastjson/wiki/fastjson_safemode](https://github.com/alibaba/fastjson/wiki/fastjson_safemode) 查看开启方法。

### 升级到 Fastjson v2

Fastjson v2地址 [https://github.com/alibaba/fastjson2/releases](https://github.com/alibaba/fastjson2/releases)

Fastjson 已经开源2.0版本，在2.0版本中，不再为了兼容提供白名单，提升了安全性。Fastjson v2 代码已经重写，性能有了很大提升，不完全兼容1.x，升级需要做认真的兼容测试。升级遇到问题，可以在 [https://github.com/alibaba/fastjson2/issues](https://github.com/alibaba/fastjson2/issues) 寻求帮助。

## 参考

[1] [https://github.com/alibaba/fastjson/wiki/security_update_20220523](https://github.com/alibaba/fastjson/wiki/security_update_20220523)

