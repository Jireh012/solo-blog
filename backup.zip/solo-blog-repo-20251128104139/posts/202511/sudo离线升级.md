title: sudo离线升级
date: '2025-11-04 16:10:33'
updated: '2025-11-04 16:10:33'
tags: [Centos, Sudo]
permalink: /articles/2025/11/04/1762243833499.html
---
## 前言

服务器检测到CVE-2021-3156，CNVD-2021-07130，CWE-193，CNNVD-202101-2221漏洞需要Sudo升级至1.9.5p2 及以上版本。

## 步骤

1、去官网下载新版本Sudo https://www.sudo.ws
1、安装所需要的编译环境

```
# 安装基础的编译工具链，包括gcc, make等[citation:6]
sudo yum groupinstall "Development Tools" -y

# 安装sudo可能依赖的一些开发库[citation:6]
sudo yum install openssl-devel zlib-devel pam-devel -y
```

## 2. 下载并解压sudo源码

```
# 下载源码包 (请替换为你需要的实际版本号)
wget https://www.sudo.ws/dist/sudo-1.9.18b1.tar.gz

# 解压源码包
tar -zxvf sudo-1.9.18b1.tar.gz

# 进入解压后的目录
cd sudo-1.9.18b1
```

## 3. 配置、编译与安装

```
# 1. 配置编译选项。`--prefix=/usr` 指定安装路径，确保替换系统自带sudo[citation:7]
./configure --prefix=/usr

# 2. 编译源码。使用 `-j` 选项可并行编译以加快速度，如 `make -j$(nproc)`
make

# 3. 安装到系统。此命令会覆盖现有sudo[citation:2]
sudo make install
```

## ✅ 安装后验证

```
# 检查新版sudo版本信息
sudo --version

# 测试sudo基本功能是否正常
sudo -h
```

## 遇见的问题记录

在make编译的时候遇到因为openssl导致的问题

```
make[1]: Entering directory `/usr/local/src/sudo-1.9.18b1/logsrvd'
gcc -std=gnu11 -c -I../include -I.. -I. -I. -D_PATH_SUDO_LOGSRVD_CONF=\"/etc/sudo_logsrvd.conf\" -DLOCALEDIR=\"/usr/share/locale\" -DZLIB_CONST -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=3 -g -O2 -fvisibility=hidden  -fPIE -fstack-protector-strong -fstack-clash-protection -fno-delete-null-pointer-checks -fno-strict-overflow -fno-strict-aliasing ./logsrvd.c
In file included from ./tls_common.h:30:0,
                 from ./logsrvd.h:38,
                 from ./logsrvd.c:70:
./logsrvd.c: In function ‘verify_peer_identity’:
../include/sudo_ssl_compat.h:29:47: error: dereferencing pointer to incomplete type
 #    define X509_STORE_CTX_get0_cert(x)   ((x)->cert)
                                               ^
./logsrvd.c:1306:17: note: in expansion of macro ‘X509_STORE_CTX_get0_cert’
     peer_cert = X509_STORE_CTX_get0_cert(ctx);
                 ^
make[1]: *** [logsrvd.o] Error 1
make[1]: Leaving directory `/usr/local/src/sudo-1.9.18b1/logsrvd'
make: *** [all] Error 2
```

后重新安装openssl3.0.8版本并指定openssl版本后问题仍然存在

```
./configure --prefix=/usr --with-openssl=/usr/local/openssl-3.0.18
```

发现可能​是**编译时仍然可能链接到了系统旧版本的 OpenSSL 头文件或库**​，导致结构体定义不一致，从而触发同样的错误

### ✅ 解决思路：确保 **头文件** 和 **库** 都使用的是 OpenSSL 3.0.18

#### 🔍 步骤 1：确认你用的是 OpenSSL 3.0.18 的 **头文件**

运行：

```bash
grep -r "openssl/x509_vfy.h" /usr/local/openssl-3.0.18/include/
```

应该能看到：

`/usr/local/openssl-3.0.18/include/openssl/x509_vfy.h`

然后确认编译时 include 路径是否优先指向这个目录：

**bash**复制

```bash
make V=1 2>&1 | grep -E "(^-I|openssl)"
```

如果你看到 `-I/usr/include` 在 `-I/usr/local/openssl-3.0.18/include` 之前，​**系统头文件会覆盖你指定的版本**​，就会出错。

---

#### ✅ 步骤 2：清理缓存，重新配置并强制指定路径

```bash
make distclean  # 清理旧配置
```

然后重新配置，​**显式指定头文件和库路径**​：


```bash
export CPPFLAGS="-I/usr/local/openssl-3.0.18/include"
export LDFLAGS="-L/usr/local/openssl-3.0.18/lib64"
export PKG_CONFIG_PATH="/usr/local/openssl-3.0.18/lib64/pkgconfig"

./configure --prefix=/usr \
            --with-openssl=/usr/local/openssl-3.0.18 \
            --disable-openssl-default

make clean
make -j$(nproc)
```

---

#### ✅ 步骤 3：确认链接的是 OpenSSL 3.0.18 的库

编译完后检查：

```bash
ldd logsrvd/logsrvd | grep ssl
```





