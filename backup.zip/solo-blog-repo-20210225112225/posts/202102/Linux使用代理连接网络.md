title: Linux使用代理连接网络
date: '2021-02-25 11:05:09'
updated: '2021-02-25 11:05:50'
tags: [Linux, proxy, 代理]
permalink: /articles/2021/02/25/1614222309571.html
---
> 现在基本上内部网络都是无法连上外网的，主机之间通过跳板机相互链接。所以内网主机安装一些软件会比较麻烦。
> 虽然可以通过 **/etc/profile** 配置文件可以配置http代理，但是其他一些例如 wget、yum、curl、telnet这些一个个配置起来就会比较繁琐，而且对socks5可能还不支持。
> 所以推荐一个工具 **proxychains-ng**，也是proxychains的加强版
> 项目地址： https://github.com/rofl0r/proxychains-ng
> 主要有以下功能：>
> 
> 1. 支持http/https/socks4/socks5
> 2. 支持认证
> 3. 远端dns查询
> 4. 多种代理模式
> 
> 不足：
> 
> 1. 不支持udp/icmp转发
> 2. 少部分程序和在后台运行的可能无法代理

### 安装

一键安装脚本（支持centos | debian | ubuntu） ：

```
wget --no-check-certificate https://raw.githubusercontent.com/Jireh012/One-click-Script/main/tools/install-proxychains-ng.sh && chmod +x install-proxychains-ng.sh && sh install-proxychains-ng.sh
```

或者手动获取源码进行编译安装

```
git clone https://github.com/rofl0r/proxychains-ng

#编译步骤
cd proxychains-ng
./configure --prefix=/usr --sysconfdir=/etc
make 
make install
make install-config
cd .. && rm -rf proxychains-ng
```

如果出现 `checking whether $CC defines __APPLE__ ... ./configure: 32: cc: not found ` 相关的错误，表示没有安装gcc编译环境，需要安装gcc环境

ubuntu : `apt install gcc -y`
debian : `apt-get install gcc -y`
centos: `yum install gcc -y`

安装完成后再次执行编译步骤即可。

### 使用说明

#### 配置文件

安装完成后，需要对 **/etc/proxychains.conf** 配置文件进行修改

```
#  Examples:
#
#               socks5  192.168.67.78   1080    lamer   secret
#               http    192.168.89.3    8080    justu   hidden
#               socks4  192.168.1.49    1080
#               http    192.168.39.93   8080
```

依次是 协议/地址/端口号/用户（如果有的话）/密码（如果有的话）

根据配置文件中Examples对文件进行修改，在 **[ProxyList]** 下载加入你的代理服务器配置，例：

```
[ProxyList]
# add proxy here ...
socks5  192.168.5.102 8000 private 123456..
```

#### 使用

`proxychains4 程序 参数 `

测试

`proxychains4 curl ip.cn  `

##### 示例

```
proxychains telnet baidu.com
```

也可以指定配置文件

```
proxychains -f /etc/proxychains-other.conf telnet baidu.com
```

还可以使用**proxyresolv**通过代理来解析地址

```
proxyresolv baidu.com
```

还可以通过proxychains4代理一个shell，在shell中执行的命令就会自动使用代理，这样就实现了类似全局代理的功能

```
proxychains4  -q /bin/bash
```

