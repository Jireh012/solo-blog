title: SymantecEndpointProtection(诺顿)卸载工具
date: '2020-06-11 09:58:55'
updated: '2020-06-11 09:58:55'
tags: [资源分享]
permalink: /articles/2020/06/11/1591840735258.html
---
# SymantecEndpointProtection(诺顿)卸载工具
之前公司有在做移动的项目，因为有接入DCN网速，所以有要求要安装SymantecEndpointProtection(诺顿)。

不过这个软件真的是太恶心了，比卡巴斯基还会误杀，加了排除也没用，还不能禁用还得输入管理密码，只好卸载了。

但是发现卸载的时候，发现需要卸载密码，百度了下都好几年的方法，现在都失效了。

最后找了个工具成功卸载了。

## CleanWipe

![image.png](https://b3logfile.com/file/2020/06/image-dcc52409.png)

1、使用CleanWipe卸载Symantec Endpoint Protection
2、提取您为CleanWipe下载的.zip文件的内容。
3、将包含Cleanwipe.exe的文件夹复制到要在其上运行它的计算机。
4、双击Cleanwipe.exe，然后单击下一步。
5、接受许可协议，然后单击“ 下一步”。
6、选择要删除的Symantec产品，然后单击两次“ 下一步”。
该工具完成运行后，可能会提示您重新启动计算机。
重新启动计算机后，CleanWipe重新打开并继续运行。
7、单击下一步。
8、点击完成。
您选择的Symantec产品现在已被卸载。

[1588698740387CleanWipe14.3.558.1000.zip](https://b3logfile.com/file/2020/06/1588698740387CleanWipe14.3.558.1000-03b87396.zip)

