title: 基于Chrome内核浏览器自带下载器开启多线程下载
date: '2021-02-08 17:32:34'
updated: '2021-02-08 17:32:34'
tags: [技巧, 黑科技]
permalink: /articles/2021/02/08/1612776754780.html
---
> 基于Chrome内核浏览器自带下载器开启多线程下载的方法，就像IDM一样就可以分区块多线程下载

### 开启方法

在地址栏中访问以下地址

```text
chrome://flags/#enable-parallel-downloading
```

![image.png](https://b3logfile.com/file/2021/02/image-3be8c41c.png)

将**Parallel downloading**设置为**Enable**，重启浏览器即可

