title: Property with 'retain(or strong) attribute must be of object type 问题
date: '2020-03-09 21:45:46'
updated: '2020-04-10 15:08:09'
tags: [开发小记]
permalink: /articles/2020/03/09/1583761546153.html
---
看原话翻译的理解，在使用 retain 或者 strong 修饰属性时，属性类型必须是对象类型。

然后发现在使用 int、float、double 等，并不能使用 strong 或者 retain 修饰。

所以需要吧 retain 改成 assign。

<pre class="EnlighterJSRAW" data-enlighter-language="null"> @property (retain,nonatomic) NSInteger* mRate;//错误代码</pre>

修改后：

<pre class="EnlighterJSRAW" data-enlighter-language="null">@property (assign,nonatomic) NSInteger* mRate;//修改后</pre>
