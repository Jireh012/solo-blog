title: maven国内镜像仓库速度飞起
date: '2020-03-10 10:05:06'
updated: '2020-03-10 10:05:06'
tags: [Java, 开发小记, Maven]
permalink: /articles/2020/03/10/1583805906664.html
---
最近重启 SSM项目，装 Maven 的时候发现 jar 包一直下载不下来，连接丢失。发现之前用的 oschina 的库居然关闭，网上搜了下还有一个阿里云的，配置完速度不是一般的快，分分钟下完了。

 

在 conf 下 settings.xml 中 <mirrors> 下面加入

<pre class="EnlighterJSRAW" data-enlighter-language="xml" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">&lt;!-- 阿里云仓库 --&gt;
        &lt;mirror&gt;
            &lt;id&gt;alimaven&lt;/id&gt;
            &lt;mirrorOf&gt;central&lt;/mirrorOf&gt;
            &lt;name&gt;aliyun maven&lt;/name&gt;
            &lt;url&gt;http://maven.aliyun.com/nexus/content/repositories/central/&lt;/url&gt;
        &lt;/mirror&gt;
    
        &lt;!-- 中央仓库1 --&gt;
        &lt;mirror&gt;
            &lt;id&gt;repo1&lt;/id&gt;
            &lt;mirrorOf&gt;central&lt;/mirrorOf&gt;
            &lt;name&gt;Human Readable Name for this Mirror.&lt;/name&gt;
            &lt;url&gt;http://repo1.maven.org/maven2/&lt;/url&gt;
        &lt;/mirror&gt;
    
        &lt;!-- 中央仓库2 --&gt;
        &lt;mirror&gt;
            &lt;id&gt;repo2&lt;/id&gt;
            &lt;mirrorOf&gt;central&lt;/mirrorOf&gt;
            &lt;name&gt;Human Readable Name for this Mirror.&lt;/name&gt;
            &lt;url&gt;http://repo2.maven.org/maven2/&lt;/url&gt;
        &lt;/mirror&gt;</pre>
