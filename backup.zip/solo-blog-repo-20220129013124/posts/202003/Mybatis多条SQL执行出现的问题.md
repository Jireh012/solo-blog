title: Mybatis多条SQL执行出现的问题
date: '2020-03-10 10:06:46'
updated: '2020-03-10 10:06:46'
tags: [Mybatis, Java, 开发小记]
permalink: /articles/2020/03/10/1583806005977.html
---
之前写的一个关联删除的功能报错了，Log 中提示

Cause: com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ‘delete from baseface.ATT_USERPICTURE where STAFF_ID=’0f2cb73ba69c4bbbbb73ffe88e7’ at line 8

语句一看没毛病，怎会还会报错呢。查询了相关资料，MySQL 驱动默认没有开启批量执行 SQL 的开关，需要我们在配置文件中添加 allowMultiQueries 参数，设置为 true

<pre class="wp-block-preformatted" style="padding: 8px; color: rgb(68, 68, 68); border-radius: 2px; font-family: Consolas, &#34;Bitstream Vera Sans Mono&#34;, &#34;Courier New&#34;, Courier, monospace !important; display: block; margin: 0px 0px 10px; font-size: 14px; line-height: 20px; word-break: break-all; overflow-wrap: break-word; white-space: pre-wrap; background-color: rgb(248, 248, 248); border: 1px solid rgb(238, 238, 238); overflow: hidden; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 30px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">url2:jdbc:mysql://localhost:3306/database?useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;allowMultiQueries=true
</pre>
