title: SqlServer获取某个日期当前所在周
date: '2021-02-07 16:01:26'
updated: '2021-02-07 16:01:26'
tags: [SqlServer]
permalink: /articles/2021/02/07/1612684886764.html
---
可以通过 **datepart()** 函数来获取

如下：

```
SELECT datepart( wk, GETDATE())
```

