title: Nginx配置SSL（Let‘s Encrypt）
date: '2021-12-14 17:44:34'
updated: '2021-12-14 17:44:34'
tags: [nginx]
permalink: /articles/2021/12/14/1639475074600.html
---
```
curl  https://get.acme.sh | sh
```

```
cd ~/.acme.sh/
```

```
./acme.sh --issue  -d level2.domain.com   --nginx
```

```
mkdir /etc/nginx/ssl/level2.domain.com
```

```
./acme.sh --install-cert -d level2.domain.com \
--key-file       /etc/nginx/ssl/level2.domain.com/key.pem  \
--fullchain-file /etc/nginx/ssl/level2.domain.com/cert.pem \
--reloadcmd     "service nginx force-reload"
```

修改nginx配置文件

```
server {
    listen 443 ssl;
    server_name level2.domain.com;

    ssl_certificate /etc/nginx/ssl/level2.domain.com/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/level2.domain.com/key.pem;

    location / {
       
    }
}

# 以下部分表示重定向 HTTP 请求到 HTTPS
server {
    listen 80;
    server_name level2.domain.com;
    return 301 https://$host$request_uri;
}
```

