title: Gitea解决Git推送失败：the remote end hung up unexpectedly
date: '2023-07-07 14:17:10'
updated: '2023-07-07 14:17:10'
tags: [nginx, Gitea, git]
permalink: /articles/2023/07/07/1688710630734.html
---
最近项目Git在推送的时候突然报错，发现是提交了大文件的提交就会报错，小文件的就不会出现

错误提示如下

```
error: RPC failed; curl 56 HTTP/2 stream 5 was reset
send-pack: unexpected disconnect while reading sideband packet
fatal: the remote end hung up unexpectedly
Everything up-to-date
```

## 解决过程

在百度上搜了各种方法均无效

1、~~修改git缓存大小~~

```
git config --global http.postBuffer 524288000
```

2、~~配置git的最低速度和最低速度时间~~

```
git config --global http.lowSpeedLimit 0
git config --global http.lowSpeedTime 999999
```

3、~~尝试使用强制推送~~

`git push origin master --force`

4、~~尝试升级git和gitea版本~~

## 解决方案

在尝试以上方法均无效后，考虑到Gitea是用nginx反代出来的，就考虑是不是nginx的配置问题
最后在查询了一些资料后，解决了，在Gitea的网站下配置如下参数解决

```
proxy_request_buffering off
```

如果之前没有配置过client_max_body_size的需要配置下

允许用户上传任意大小的文件：`client_max_body_size 0;`

