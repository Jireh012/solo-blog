title: Solo博客Casper主题添加文章过期提醒
date: '2021-03-17 22:36:29'
updated: '2021-03-17 22:36:29'
tags: [Solo]
permalink: /articles/2021/03/17/1615991789226.html
---
> 基于社区的 https://ld246.com/article/1585590610308 修改版本
> 因为不同主题，div标签等各不相同，如果你不是**Casper**主题，本文的代码可能对你无效

![image.png](https://b3logfile.com/file/2021/03/image-5af3b356.png)

先上效果图，接下来上代码，直接在文章的签名档中加入以下代码（至于为什么加到签名档，而不是其他地方，请到最上方文章中查询）

```
<script>
(function() {
  try {
    var days = parseInt((new Date().getTime() - new Date(document.querySelector('div time').innerText.replace(/ /g, '').replace(/-/g, '/')).getTime())/1000/60/60/24);
console.log(days);
    if (days > 90) {
      document.querySelector('section.item__content.item__content--article.vditor-reset').insertAdjacentHTML('afterBegin', ['<blockquote style="border: 1px solid #6a737d;border-left: 5px solid #6a737d;line-height: 36px;">本文最后更新于 <code style="color: #FF5722;vertical-align: middle;">', days, '</code> 天前，其中的信息可能已经不够准确，请您酌情参考！</blockquote>'].join(''));
    }
  } catch(e) {
console.log(e);
}
})();
</script>
```



