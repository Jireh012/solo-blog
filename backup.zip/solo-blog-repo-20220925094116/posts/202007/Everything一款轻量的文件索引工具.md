title: Everything一款轻量的文件索引工具
date: '2020-07-06 16:41:57'
updated: '2020-08-04 20:01:12'
tags: [软件分享, Windows]
permalink: /articles/2020/07/06/1594024917042.html
---
# Everything

推荐一个工具Everything，他能快速帮你找到你电脑上想要查询的文件。

可以作为关闭Windows Search服务后，文件搜索的解决方案

---

基于名称快速定位文件和文件夹。

[![Everything](https://b3logfile.com/file/2020/07/solofetchupload3715940113625769735-fa774bb8.gif)](https://www.voidtools.com/zh-cn/support/everything)

---

* 轻量安装文件
* 干净简洁的用户界面
* 快速文件索引
* 快速搜索
* 最小资源使用
* 便于文件分享
* 实时更新
* [更多...](https://www.voidtools.com/zh-cn/faq)

---

## 下载地址

包含 32、64位（安装文件、便携式压缩包）

[Everything1.4.1.969.7z](https://b3logfile.com/file/2020/07/Everything1.4.1.969-8b83f3ee.7z)

