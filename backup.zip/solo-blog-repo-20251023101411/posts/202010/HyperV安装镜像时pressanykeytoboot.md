title: Hyper-V安装镜像时press any key to boot
date: '2020-10-28 15:53:43'
updated: '2020-10-28 15:55:34'
tags: [Hyper-V]
permalink: /articles/2020/10/28/1603871623547.html
---
# Hyper-V安装镜像时Press any key to boot

![image.png](https://b3logfile.com/file/2020/10/image-0fb7361a.png)

`Press any key to boot from CD for DVD ……`

最近在Hyper中安装Windows Server 2019时出现以上提示，按任意键无法进行下一步操作。

这是因为在创建时，**虚拟机代数**手动选择了第2代。在使用快速创建时，默认会使用第二代虚拟机。

## 解决方法

关闭虚拟机——启动虚拟机——在点击启动按钮后，马上按住任意键，需要一直按住，直至进入引导。

![image.png](https://b3logfile.com/file/2020/10/image-5c492b4c.png)

