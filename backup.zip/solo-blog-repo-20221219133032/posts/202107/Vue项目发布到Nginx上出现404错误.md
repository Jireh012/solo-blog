title: Vue项目发布到Nginx上出现404错误
date: '2021-07-23 14:38:20'
updated: '2021-07-23 14:38:20'
tags: [nginx, Vue]
permalink: /articles/2021/07/23/1627022300007.html
---
Vue项目发布到Nginx上出现404错误

### 解决方法

在配置文件当中加入

```
try_files $uri $uri/ /index.html;
```

#### 完整实例：

```
server
{
    listen 80;
    index index.php index.html index.htm default.php default.htm default.html;
    root /www/wwwroot/website;
    try_files $uri $uri/ /index.html;
}
```

