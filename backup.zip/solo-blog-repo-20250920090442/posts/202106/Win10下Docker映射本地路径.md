title: Win10下Docker映射本地路径
date: '2021-06-08 10:02:14'
updated: '2021-06-08 10:02:14'
tags: [Docker]
permalink: /articles/2021/06/08/1623117734013.html
---
Win10下跟Linux版本不一样，Linux中可以直接使用 -v参数来直接映射，但是Win10上面需要先在配置项中添加共享文件夹才可以。

1. 打开 Docker Desktop - Settings - Resource - File sharing
2. 添加你需要映射的文件夹地址 例：**E:\Docker**
3. 在启动参数当中添加映射
   ```
   docker run --detach --name xxx --volume /E/Docker/jexus/www:/var/www xxx
   ```

