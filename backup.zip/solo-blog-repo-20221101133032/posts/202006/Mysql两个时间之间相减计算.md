title: Mysql两个时间之间相减计算
date: '2020-06-05 14:12:11'
updated: '2020-06-05 14:12:11'
tags: [Mysql]
permalink: /articles/2020/06/05/1591337531855.html
---
**两个日期之间间隔秒数**

selec t (UNIX_TIMESTAMP(endTime) - UNIX_TIMESTAMP(startTime)) second from tbName

**分钟**

(UNIX_TIMESTAMP(endDateTime) - UNIX_TIMESTAMP(beginDateTime))/60 

**天数**

(UNIX_TIMESTAMP(endDateTime) - UNIX_TIMESTAMP(beginDateTime))/(60*60*24)
