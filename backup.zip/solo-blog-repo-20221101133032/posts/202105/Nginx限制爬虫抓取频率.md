title: Nginx限制爬虫抓取频率
date: '2021-05-10 09:39:16'
updated: '2021-05-10 09:39:16'
tags: [nginx]
permalink: /articles/2021/05/10/1620610756852.html
---
在 http中配置

```
http {
      limit_req_zone $anti_spider zone=grab_limit:10m** rate=15r/m;
      ……
}
```

然后在某个server当中配置

```
limit_req zone=grab_limit burst=5 nodelay;

if ($http_user_agent ~* "xxxBot") {
    set $anti_spider $http_user_agent;
}
```

