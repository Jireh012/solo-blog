title: 【转】el-table遍历循环表头和表体数据
date: '2021-10-09 18:36:02'
updated: '2021-10-09 18:36:02'
tags: [转载记录]
permalink: /articles/2021/10/09/1633775762481.html
---
vue使用el-table遍历循环表头和表体数据

![在这里插入图片描述](https://b3logfile.com/file/2021/10/solo-fetchupload-9111356765810270514-54e2af52.png)

这是表头数据

![在这里插入图片描述](https://b3logfile.com/file/2021/10/solo-fetchupload-3465530129236503533-cf576840.png)

这是表体数据

![在这里插入图片描述](https://b3logfile.com/file/2021/10/solo-fetchupload-5802366721784344121-49b809dc.png)

最终循环出来的结果

![在这里插入图片描述](https://b3logfile.com/file/2021/10/solo-fetchupload-6027548345553001435-e8f2156e.png)

最后的合计使用的是el-table的原始合计功能，这个数据循环出来的时候在nos的最后一行也进行了总和，但是表格中是不希望有这样的数据出现的，所以在这里我有加了一个判断

![在这里插入图片描述](https://b3logfile.com/file/2021/10/solo-fetchupload-5761179892972043750-ba082ad1.png)

当他的index为0的时候让他的总和为空。
————————————————
版权声明：本文为CSDN博主「jasmine0178」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/jasmine0178/article/details/88720427

